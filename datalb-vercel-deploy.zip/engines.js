/* DataLB Analytics Engines — all 10 engines compiled for browser use */
/* Generated for DataLB KAVOX Predictive Engine™ */

/* ═══ parserEngine.js ═══ */
/* ═══ DataLB Parser Engine v1 — ES Module ═══ */

const ct = el => (el?.textContent || '').replace(/\u00a0/g, ' ').trim()

const pn = s => {
  if (!s || s === '' || s === '-') return null
  const c = s.replace(/\s/g, '').replace(/,/g, '.')
  const p = c.split('.')
  if (p.length > 2) { const d = p.pop(); return parseFloat(p.join('') + '.' + d) }
  const n = parseFloat(c)
  return isNaN(n) ? null : n
}

const pd = s => {
  if (!s || !s.trim() || s.trim() === '-') return null
  let m = s.match(/(\d{4})\.(\d{2})\.(\d{2})\s*(\d{2}:\d{2}(?::\d{2})?)?/)
  if (m) return `${m[1]}-${m[2]}-${m[3]}` + (m[4] ? ' ' + m[4] : '')
  m = s.match(/(\d{2})\.(\d{2})\.(\d{4})\s*(\d{2}:\d{2}(?::\d{2})?)?/)
  if (m) return `${m[3]}-${m[2]}-${m[1]}` + (m[4] ? ' ' + m[4] : '')
  return /\d{4}-\d{2}-\d{2}/.test(s) ? s : null
}

const BAL_T = ['balance','credit','deposit','withdrawal','adjustment','rebate','correction']
const isBal = s => BAL_T.some(t => s.toLowerCase().includes(t))

function mapCols(cells) {
  const cols = {}, tx = cells.map((c, i) => ({ i, t: ct(c).toLowerCase() }))
  let pn2 = 0
  tx.forEach(({ i, t }) => {
    if (cols.ticket == null && (t === 'ticket' || t === '#' || t === 'deal')) cols.ticket = i
    if (cols.openTime == null && (t.includes('open time') || t.includes('time open') || t === 'time')) cols.openTime = i
    if (cols.closeTime == null && (t.includes('close time') || t.includes('time close'))) cols.closeTime = i
    if (cols.type == null && (t === 'type' || t === 'direction')) cols.type = i
    if (cols.lots == null && (t === 'size' || t === 'volume' || t === 'lots' || t === 'lot')) cols.lots = i
    if (cols.symbol == null && (t === 'item' || t === 'symbol' || t === 'instrument' || t === 'pair')) cols.symbol = i
    if (cols.sl == null && (t.includes('s / l') || t.includes('s/l') || t === 'sl' || t.includes('stop loss'))) cols.sl = i
    if (cols.tp == null && (t.includes('t / p') || t.includes('t/p') || t === 'tp' || t.includes('take profit'))) cols.tp = i
    if (cols.commission == null && (t.includes('commission') || t === 'comm')) cols.commission = i
    if (cols.taxes == null && (t.includes('taxes') || t.includes('fee'))) cols.taxes = i
    if (cols.swap == null && (t.includes('swap') || t.includes('storage'))) cols.swap = i
    if (cols.profit == null && (t.includes('profit') || t.includes('p&l') || t.includes('gain'))) cols.profit = i
    if (cols.balance == null && t === 'balance') cols.balance = i
    if (cols.comment == null && t.includes('comment')) cols.comment = i
    if (t === 'price') { pn2++; if (pn2 === 1) cols.openPrice = i; else if (pn2 === 2) cols.closePrice = i }
  })
  return cols
}

function exRow(cells, cols) {
  const g = k => cols[k] != null ? ct(cells[cols[k]]) : ''
  return {
    ticket: g('ticket'), openTime: pd(g('openTime')), closeTime: pd(g('closeTime')),
    type: g('type').toLowerCase(), lots: pn(g('lots')),
    symbol: g('symbol').replace(/[mM]$/, '').toUpperCase(),
    openPrice: pn(g('openPrice')), closePrice: pn(g('closePrice')),
    sl: pn(g('sl')), tp: pn(g('tp')),
    commission: pn(g('commission')), taxes: pn(g('taxes')),
    swap: pn(g('swap')), profit: pn(g('profit') || g('balance')), comment: g('comment'),
  }
}

function exAcct(table) {
  const info = {}, rows = Array.from(table.querySelectorAll('tr'))
  const LBLS = {
    account: ['account','login'], name: ['name','client'], currency: ['currency'],
    leverage: ['leverage'], broker: ['broker','company'], from: ['from','period from'],
    to: [' to ','period to'], balance: ['balance'], equity: ['equity'],
  }
  rows.forEach(row => {
    const cells = Array.from(row.querySelectorAll('td,th'))
    for (let i = 0; i + 1 < cells.length; i++) {
      const lbl = ct(cells[i]).toLowerCase().replace(/[:\s]+$/, '')
      const val = ct(cells[i + 1])
      if (!lbl || !val) continue
      for (const [key, pats] of Object.entries(LBLS)) {
        if (!info[key] && pats.some(p => lbl.includes(p.trim()))) { info[key] = val; break }
      }
    }
  })
  return info
}

function parseStatement(htmlString, fileName = '') {
  const doc = new DOMParser().parseFromString(htmlString, 'text/html')
  const log = [], L = m => log.push(m)
  const R = { platform: 'Unknown', fileName, accountInfo: {}, closedTrades: [], openTrades: [], deposits: [], withdrawals: [], balanceOps: [], parseLog: log }

  const body = doc.body?.textContent?.toLowerCase() || ''
  const bodyHtml = doc.body?.innerHTML?.toLowerCase() || ''
  if (bodyHtml.includes('metatrader 5') || body.includes('deal #')) R.platform = 'MT5'
  else if (bodyHtml.includes('metatrader 4')) R.platform = 'MT4'
  else if (body.includes('open time') && body.includes('close time') && body.includes('ticket')) R.platform = 'MT4 (inferred)'
  L(`Platform: ${R.platform}`)

  const tables = Array.from(doc.querySelectorAll('table'))
  L(`Tables: ${tables.length}`)
  let acctF = false

  tables.forEach((tbl, ti) => {
    const rows = Array.from(tbl.querySelectorAll('tr'))
    if (rows.length < 2) return
    const prev = rows.slice(0, 6).flatMap(r => Array.from(r.querySelectorAll('td,th')).map(c => ct(c).toLowerCase())).join(' ')

    if (!acctF && (prev.includes('account') || prev.includes('login')) && (prev.includes('currency') || prev.includes('leverage')) && !prev.includes('open time')) {
      L(`Table ${ti}: Account`); R.accountInfo = exAcct(tbl); acctF = true; return
    }
    if (!(prev.includes('ticket') || (prev.includes('open time') && prev.includes('type')))) return

    let hi = -1, cols = {}
    for (let ri = 0; ri < Math.min(rows.length, 10); ri++) {
      const cells = Array.from(rows[ri].querySelectorAll('td,th'))
      if (cells.length < 5) continue
      const s = cells.map(c => ct(c).toLowerCase()).join(' ')
      if ((s.includes('ticket') || s.includes('open time')) && s.includes('type')) { hi = ri; cols = mapCols(cells); break }
    }
    if (hi === -1) return
    L(`Table ${ti}: Trade table (hdr row ${hi})`)

    let sect = 'closed', openSeen = false
    for (let ri = 0; ri < rows.length; ri++) {
      if (ri <= hi) continue
      const cells = Array.from(rows[ri].querySelectorAll('td,th'))
      if (!cells.length) continue
      if (cells.length === 1 || (cells[0].colSpan && cells[0].colSpan > 5)) {
        const txt = ct(cells[0]).toLowerCase()
        if (txt.includes('open trade') || txt.includes('open position')) { sect = 'open'; openSeen = true; continue }
        if (txt.includes('closed') || txt.includes('history')) { sect = 'closed'; continue }
        if (txt.includes('summary') || txt.includes('total')) continue
        const inh = cells.map(c => ct(c).toLowerCase())
        if (inh.some(h => h === 'ticket') && inh.some(h => h.includes('time'))) { cols = mapCols(cells); sect = openSeen ? 'open' : 'closed'; continue }
        continue
      }
      const nonE = cells.filter(c => ct(c) !== '' && ct(c) !== '-').length
      if (nonE < 3) continue
      const tktV = cols.ticket != null ? ct(cells[cols.ticket]) : ''
      const typV = cols.type != null ? ct(cells[cols.type]) : ''
      if (!tktV && !typV) continue
      const trade = exRow(cells, cols)
      if (isBal(trade.type)) {
        const op = { ...trade, amount: trade.profit ?? 0 }
        R.balanceOps.push(op)
        if (trade.type.includes('deposit') || (trade.type === 'balance' && (trade.profit ?? 0) > 0)) R.deposits.push(op)
        else if (trade.type.includes('withdrawal') || (trade.type === 'balance' && (trade.profit ?? 0) < 0)) R.withdrawals.push(op)
      } else if (sect === 'open') {
        R.openTrades.push(trade)
      } else if (trade.closeTime || trade.closePrice != null) {
        R.closedTrades.push(trade)
      } else {
        R.openTrades.push(trade)
      }
    }
  })
  L(`Parsed: ${R.closedTrades.length} closed, ${R.openTrades.length} open, ${R.deposits.length} deposits`)
  return R
}

/* ═══ metricsEngine.js ═══ */
/* ═══════════════════════════════════════════════════════════
   DataLB Metrics Engine v2
   Extends v1 with: Drawdown · Streaks · Frequency · Equity Curve
   Input:  parsedData from datalb_parser_v1
   Output: MetricsResult object (all v1 + v2 fields)
═══════════════════════════════════════════════════════════ */

function durMs(openT, closeT) {
  if (!openT || !closeT) return null;
  const a = new Date(openT.replace(' ', 'T')).getTime();
  const b = new Date(closeT.replace(' ', 'T')).getTime();
  return (!isNaN(a) && !isNaN(b) && b > a) ? b - a : null;
}

function fmtDuration(ms) {
  if (ms == null || ms < 0) return null;
  const s = Math.floor(ms / 1000), m = Math.floor(s/60), h = Math.floor(m/60), d = Math.floor(h/24);
  if (s < 60)  return `${s}s`;
  if (m < 60)  return `${m}m ${s%60}s`;
  if (h < 24)  return `${h}h ${m%60}m`;
  return `${d}d ${h%24}h`;
}

function toTs(dt) {
  if (!dt) return null;
  const t = new Date(dt.replace(' ', 'T')).getTime();
  return isNaN(t) ? null : t;
}

function dayKey(ts) {
  const d = new Date(ts);
  return `${d.getUTCFullYear()}-${String(d.getUTCMonth()+1).padStart(2,'0')}-${String(d.getUTCDate()).padStart(2,'0')}`;
}

function calculateMetrics(parsedData) {

  // ── 1. Prepare trades: market orders only, sorted by close time ──
  const trades = parsedData.closedTrades
    .filter(t => t.type && (t.type.includes('buy') || t.type.includes('sell')))
    .map(t => ({
      ...t,
      // True net P&L: price movement + all broker costs
      netPL:   (t.profit ?? 0) + (t.commission ?? 0) + (t.swap ?? 0) + (t.taxes ?? 0),
      durMs:   durMs(t.openTime, t.closeTime),
      closeTs: toTs(t.closeTime),
      openTs:  toTs(t.openTime),
    }))
    .sort((a, b) => {
      const ta = a.closeTs ?? a.openTs ?? 0;
      const tb = b.closeTs ?? b.openTs ?? 0;
      return ta - tb;
    });

  if (!trades.length) return null;

  // ── 2. Base account metrics (v1) ─────────────────────────────────
  const winners = trades.filter(t => t.netPL > 0);
  const losers  = trades.filter(t => t.netPL < 0);
  const beArr   = trades.filter(t => t.netPL === 0);

  const grossProfit  = winners.reduce((s, t) => s + t.netPL, 0);
  const grossLossAbs = Math.abs(losers.reduce((s, t) => s + t.netPL, 0));
  const netProfit    = trades.reduce((s, t) => s + t.netPL, 0);
  const profitFactor = grossLossAbs > 0
    ? grossProfit / grossLossAbs
    : grossProfit > 0 ? Infinity : 0;

  const avgWin    = winners.length ? grossProfit / winners.length : null;
  const avgLoss   = losers.length  ? grossLossAbs / losers.length : null;
  const largestWin  = winners.length ? Math.max(...winners.map(t => t.netPL)) : null;
  const largestLoss = losers.length  ? Math.abs(Math.min(...losers.map(t => t.netPL))) : null;

  const withDur   = trades.filter(t => t.durMs != null && t.durMs > 0);
  const avgHoldMs = withDur.length ? withDur.reduce((s, t) => s + t.durMs, 0) / withDur.length : null;
  const longest   = withDur.length ? withDur.reduce((a, t) => t.durMs > a.durMs ? t : a) : null;
  const shortest  = withDur.length ? withDur.reduce((a, t) => t.durMs < a.durMs ? t : a) : null;

  // ── 3. Equity Curve ───────────────────────────────────────────────
  // Relative: starts at 0, each point represents cumulative P&L after
  // closing a trade. Sorted chronologically (by closeTime).
  let cumPL = 0;
  const equityCurve = [
    { idx: 0, cumPL: 0, netPL: 0, tradeIdx: -1, date: 'Start', symbol: null, ticket: null }
  ];
  trades.forEach((t, i) => {
    cumPL += t.netPL;
    equityCurve.push({
      idx:      i + 1,
      cumPL,
      netPL:    t.netPL,
      tradeIdx: i,
      date:     t.closeTime || t.openTime || null,
      symbol:   t.symbol,
      ticket:   t.ticket,
      type:     t.type,
      lots:     t.lots,
    });
  });

  // ── 4. Drawdown Metrics ───────────────────────────────────────────
  // Walk the equity curve to compute running drawdown at every point.
  // Definitions:
  //   Absolute Drawdown  = max excursion below the STARTING point (0)
  //   Max Absolute DD    = largest (peak - trough) in currency terms
  //   Relative DD        = Max Absolute DD / peak (as %)

  let peak = 0;
  let maxAbsDD = 0;      // largest absolute drop from any running peak
  let maxRelDD = 0;      // corresponding percentage
  let absoluteDD = 0;    // max drop below starting balance (0)
  let peakIdx = 0;

  const ddCurve = equityCurve.map((pt, i) => {
    if (pt.cumPL > peak) { peak = pt.cumPL; peakIdx = i; }
    const absDD = peak - pt.cumPL;
    // relDD is absDD as % of the peak — avoids division by zero when peak=0
    const relDD = peak !== 0 ? (absDD / Math.abs(peak)) * 100 : 0;

    if (absDD > maxAbsDD) maxAbsDD = absDD;
    if (relDD > maxRelDD) maxRelDD = relDD;
    if (pt.cumPL < 0 && Math.abs(pt.cumPL) > absoluteDD) {
      absoluteDD = Math.abs(pt.cumPL);
    }

    return { idx: i, cumPL: pt.cumPL, absDD, relDD };
  });

  // ── 5. Streak Metrics ─────────────────────────────────────────────
  let maxWinStreak = 0, maxLossStreak = 0;
  let curWin = 0, curLoss = 0;

  trades.forEach(t => {
    if (t.netPL > 0) {
      curWin++; curLoss = 0;
      if (curWin > maxWinStreak) maxWinStreak = curWin;
    } else if (t.netPL < 0) {
      curLoss++; curWin = 0;
      if (curLoss > maxLossStreak) maxLossStreak = curLoss;
    } else {
      curWin = 0; curLoss = 0;
    }
  });

  // Current streak: unbroken sequence from the end of the trade list
  const lastNetPL = trades[trades.length - 1]?.netPL ?? 0;
  const lastType  = lastNetPL > 0 ? 'win' : lastNetPL < 0 ? 'loss' : 'breakeven';
  let currentStreak = 0;
  for (let i = trades.length - 1; i >= 0; i--) {
    const type = trades[i].netPL > 0 ? 'win' : trades[i].netPL < 0 ? 'loss' : 'breakeven';
    if (type === lastType) currentStreak++;
    else break;
  }

  // ── 6. Frequency Metrics ─────────────────────────────────────────
  // Calendar range: from first close (or open) to last close
  const allTs = trades.map(t => t.closeTs ?? t.openTs).filter(Boolean);
  const minTs  = Math.min(...allTs);
  const maxTs  = Math.max(...allTs);

  // Calendar days = inclusive day count
  const calDays  = allTs.length > 1
    ? Math.max(1, Math.round((maxTs - minTs) / (1000 * 60 * 60 * 24)) + 1)
    : 1;
  const calWeeks = Math.max(1, calDays / 7);

  // Unique calendar days that had at least one trade closed
  const tradingDaySet = new Set(
    trades.map(t => { const ts = t.closeTs ?? t.openTs; return ts ? dayKey(ts) : null; }).filter(Boolean)
  );
  const uniqueTradingDays = tradingDaySet.size || 1;

  const tradesPerDay      = trades.length / calDays;
  const tradesPerWeek     = trades.length / calWeeks;
  const avgPerTradingDay  = trades.length / uniqueTradingDays;

  // ── 7. Symbol Metrics ─────────────────────────────────────────────
  const symMap = {};
  trades.forEach(t => {
    const s = t.symbol || 'Unknown';
    if (!symMap[s]) symMap[s] = { sym: s, trades: [], pls: [] };
    symMap[s].trades.push(t);
    symMap[s].pls.push(t.netPL);
  });

  const symbolStats = Object.values(symMap).map(({ sym, trades: st, pls }) => {
    const wins   = pls.filter(p => p > 0).length;
    const total  = pls.reduce((s, p) => s + p, 0);
    const gp     = pls.filter(p => p > 0).reduce((s, p) => s + p, 0);
    const glAbs  = Math.abs(pls.filter(p => p < 0).reduce((s, p) => s + p, 0));
    return {
      symbol:       sym,
      count:        st.length,
      wins,
      losses:       pls.filter(p => p < 0).length,
      winRate:      st.length ? (wins / st.length * 100) : 0,
      totalNetPL:   total,
      avgNetPL:     st.length ? total / st.length : 0,
      bestTrade:    Math.max(...pls),
      worstTrade:   Math.min(...pls),
      profitFactor: glAbs > 0 ? gp / glAbs : gp > 0 ? Infinity : 0,
      totalLots:    st.reduce((s, t) => s + (t.lots ?? 0), 0),
    };
  }).sort((a, b) => b.count - a.count);

  const byPL = [...symbolStats].sort((a, b) => b.totalNetPL - a.totalNetPL);

  // ── Return complete MetricsResult ─────────────────────────────────
  return {
    // V1 — Account
    totalTrades:      trades.length,
    winningTrades:    winners.length,
    losingTrades:     losers.length,
    breakEvenTrades:  beArr.length,
    winRate:          trades.length ? (winners.length / trades.length * 100) : 0,
    grossProfit,
    grossLossAbs,
    netProfit,
    profitFactor,
    avgWin,
    avgLoss,
    largestWin,
    largestLoss,

    // V1 — Time
    avgHoldMs,
    avgHoldFormatted:      fmtDuration(avgHoldMs),
    longestTrade:          longest,
    longestTradeFormatted: longest ? fmtDuration(longest.durMs) : null,
    shortestTrade:         shortest,
    shortestTradeFormatted:shortest ? fmtDuration(shortest.durMs) : null,
    tradesWithDuration:    withDur.length,

    // V1 — Symbol
    symbolStats,
    mostTradedSymbol:     symbolStats[0]?.symbol || null,
    mostProfitableSymbol: byPL[0]?.symbol        || null,
    mostLosingSymbol:     byPL[byPL.length-1]?.symbol || null,

    // V2 — Equity Curve
    equityCurve,       // [{idx, cumPL, netPL, date, symbol, ticket, type, lots}]

    // V2 — Drawdown
    maxAbsDD,          // largest currency drop from any running peak
    maxRelDD,          // largest % drop from peak
    absoluteDD,        // max drop below starting balance (0)
    ddCurve,           // [{idx, cumPL, absDD, relDD}] — same length as equityCurve

    // V2 — Streaks
    maxWinStreak,
    maxLossStreak,
    currentStreak,
    currentStreakType: lastType,   // 'win' | 'loss' | 'breakeven'

    // V2 — Frequency
    tradesPerDay,
    tradesPerWeek,
    avgPerTradingDay,
    calDays,
    calWeeks,
    uniqueTradingDays,

    // Meta
    currency:    parsedData.accountInfo?.currency || '',
    accountInfo: parsedData.accountInfo,
    rawTrades:   trades,
  };
}

/* ═══ sessionEngine.js ═══ */
/* ═══════════════════════════════════════════════════════════
   DataLB Session Engine v1
   Input:  parsedData from datalb_parser_v1
           tzOffset  — broker UTC offset (e.g. 2 for UTC+2)
   Output: SessionAnalytics object
   ─────────────────────────────────────────────────────────
   Sessions (UTC):
     Asia     00:00 – 08:00
     London   08:00 – 13:00
     New York 13:00 – 22:00
     After    22:00 – 00:00  (off-hours / Sydney pre-open)
═══════════════════════════════════════════════════════════ */

const SESSION_DEFS = [
  { key: 'Asia',    label: 'Asia',      start: 0,  end: 8,  hex: '#a78bfa' },
  { key: 'London',  label: 'London',    start: 8,  end: 13, hex: '#00d2ff' },
  { key: 'NewYork', label: 'New York',  start: 13, end: 22, hex: '#f59e0b' },
  { key: 'After',   label: 'Off-Hours', start: 22, end: 24, hex: '#5a7090' },
];

/**
 * Classify a trade's entry session.
 *
 * @param {string|null} openTime - "YYYY-MM-DD HH:MM:SS" (broker local time)
 * @param {number}      tzOffset - broker UTC offset in hours (e.g. 2 = UTC+2)
 * @returns {string} session key: 'Asia' | 'London' | 'NewYork' | 'After' | 'Unknown'
 */
function getSession(openTime, tzOffset = 0) {
  if (!openTime) return 'Unknown';

  // Extract date/time components from broker time string
  const parts = openTime.match(/(\d{4})-(\d{2})-(\d{2})\s+(\d{2}):(\d{2})/);
  if (!parts) return 'Unknown';

  // Build broker-time UTC milliseconds, then subtract the offset to get true UTC
  const brokerMs = Date.UTC(+parts[1], +parts[2] - 1, +parts[3], +parts[4], +parts[5]);
  const utcMs    = brokerMs - tzOffset * 3_600_000;
  const utcHour  = new Date(utcMs).getUTCHours();

  for (const s of SESSION_DEFS) {
    if (utcHour >= s.start && utcHour < s.end) return s.key;
  }
  return 'After'; // 22-23:59 covered by After, but safe fallback
}

/**
 * Compute all statistics for a set of trades within one session.
 *
 * @param {Array} trades - trade objects with .netPL field
 * @returns {SessionStats}
 */
function sessionStats(trades) {
  if (!trades.length) {
    return {
      count: 0, wins: 0, losses: 0, breakEven: 0,
      winRate: null, netProfit: 0,
      grossProfit: 0, grossLoss: 0, profitFactor: null,
      avgWin: null, avgLoss: null,
      largestWin: null, largestLoss: null,
      trades: [],
    };
  }

  const winners = trades.filter(t => t.netPL > 0);
  const losers  = trades.filter(t => t.netPL < 0);
  const beArr   = trades.filter(t => t.netPL === 0);

  const grossProfit  = winners.reduce((s, t) => s + t.netPL, 0);
  const grossLossAbs = Math.abs(losers.reduce((s, t) => s + t.netPL, 0));
  const netProfit    = trades.reduce((s, t) => s + t.netPL, 0);

  const profitFactor = grossLossAbs > 0
    ? grossProfit / grossLossAbs
    : grossProfit > 0 ? Infinity : 0;

  return {
    count:     trades.length,
    wins:      winners.length,
    losses:    losers.length,
    breakEven: beArr.length,
    winRate:   winners.length / trades.length * 100,
    netProfit,
    grossProfit,
    grossLoss: grossLossAbs,
    profitFactor,
    avgWin:    winners.length ? grossProfit  / winners.length : null,
    avgLoss:   losers.length  ? grossLossAbs / losers.length  : null,
    largestWin:  winners.length ? Math.max(...winners.map(t => t.netPL)) : null,
    largestLoss: losers.length  ? Math.abs(Math.min(...losers.map(t => t.netPL))) : null,
    trades,
  };
}

/**
 * Main session analysis function.
 *
 * @param {object} parsedData - output of parseStatement()
 * @param {number} tzOffset   - broker UTC offset in hours
 * @returns {SessionAnalytics|null}
 */
function calculateSessions(parsedData, tzOffset = 0) {
  // Prepare market trades with true net P&L and session classification
  const trades = parsedData.closedTrades
    .filter(t => t.type && (t.type.includes('buy') || t.type.includes('sell')))
    .map(t => {
      const netPL = (t.profit ?? 0)
                  + (t.commission ?? 0)
                  + (t.swap ?? 0)
                  + (t.taxes ?? 0);

      // UTC hour for heatmap
      let utcHour = null;
      if (t.openTime) {
        const p = t.openTime.match(/(\d{4})-(\d{2})-(\d{2})\s+(\d{2})/);
        if (p) {
          const bMs = Date.UTC(+p[1], +p[2]-1, +p[3], +p[4], 0);
          utcHour = new Date(bMs - tzOffset * 3_600_000).getUTCHours();
        }
      }

      return { ...t, netPL, session: getSession(t.openTime, tzOffset), utcHour };
    });

  if (!trades.length) return null;

  // Group trades by session
  const groups = Object.fromEntries(SESSION_DEFS.map(s => [s.key, []]));
  trades.forEach(t => {
    if (groups[t.session]) groups[t.session].push(t);
    else groups['After'].push(t);
  });

  // Compute per-session statistics
  const sessions = Object.fromEntries(
    SESSION_DEFS.map(sd => [sd.key, { ...sd, ...sessionStats(groups[sd.key]) }])
  );

  const totalNetPL   = trades.reduce((s, t) => s + t.netPL, 0);
  const totalTrades  = trades.length;

  // Session contribution to total net P&L (signed %)
  const contributions = Object.fromEntries(
    SESSION_DEFS.map(sd => [
      sd.key,
      totalNetPL !== 0 ? (sessions[sd.key].netProfit / Math.abs(totalNetPL)) * 100 : 0,
    ])
  );

  // Trade share (% of all trades)
  const tradeShare = Object.fromEntries(
    SESSION_DEFS.map(sd => [
      sd.key,
      totalTrades ? (sessions[sd.key].count / totalTrades) * 100 : 0,
    ])
  );

  // Best / Worst: determined by net profit among sessions with >= 3 trades
  const eligibleKeys = SESSION_DEFS.map(s => s.key).filter(k => sessions[k].count >= 3);
  const bestKey = eligibleKeys.length
    ? eligibleKeys.reduce((a, b) => sessions[a].netProfit >= sessions[b].netProfit ? a : b)
    : null;
  const worstKey = eligibleKeys.length
    ? eligibleKeys.reduce((a, b) => sessions[a].netProfit <= sessions[b].netProfit ? a : b)
    : null;

  // 24-hour trade distribution (using UTC entry hour)
  const hourDistribution = Array.from({ length: 24 }, (_, h) => ({
    hour: h, count: 0, wins: 0, losses: 0, netPL: 0,
  }));
  trades.forEach(t => {
    if (t.utcHour != null) {
      hourDistribution[t.utcHour].count++;
      hourDistribution[t.utcHour].netPL += t.netPL;
      if (t.netPL > 0) hourDistribution[t.utcHour].wins++;
      else if (t.netPL < 0) hourDistribution[t.utcHour].losses++;
    }
  });

  return {
    // Per-session objects (each contains all sessionStats fields + session metadata)
    sessions,

    // Summary keys
    bestKey,    // key of best session by net profit
    worstKey,   // key of worst session by net profit

    // Aggregates
    totalNetPL,
    totalTrades,
    contributions,   // { Asia: 23.4, London: 45.1, NewYork: -12.5, After: 0 } — signed %
    tradeShare,      // { Asia: 18.0, London: 42.0, NewYork: 38.0, After: 2.0 } — unsigned %

    // Distributions
    hourDistribution,  // array[24] with count, wins, losses, netPL per UTC hour
    trades,            // all classified trades with .session and .utcHour fields

    // Meta
    tzOffset,
    currency:    parsedData.accountInfo?.currency || '',
    accountInfo: parsedData.accountInfo,
    sessionDefs: SESSION_DEFS,
  };
}

/* ═══ behaviourEngine.js ═══ */
/* ═══════════════════════════════════════════════════════════
   DataLB Behaviour Engine v1
   Input:  parsedData from datalb_parser_v1
   Output: BehaviourAnalytics object
   ─────────────────────────────────────────────────────────
   Modules:
     1. Lot Escalation      — post-loss lot increase detection
     2. Holding Behaviour   — winner vs loser hold time asymmetry
     3. Overtrading         — frequency score, overtrading days
     4. Recovery Behaviour  — post-loss re-entry and revenge detection
     5. Concentration       — symbol dominance and loss clustering
═══════════════════════════════════════════════════════════ */

const toTs = dt => {
  if (!dt) return null;
  const t = new Date(dt.replace(' ', 'T')).getTime();
  return isNaN(t) ? null : t;
};
const durMs = (o, c) => {
  if (!o || !c) return null;
  const a = new Date(o.replace(' ', 'T')).getTime();
  const b = new Date(c.replace(' ', 'T')).getTime();
  return (!isNaN(a) && !isNaN(b) && b > a) ? b - a : null;
};
const fmtDuration = ms => {
  if (!ms || ms < 0) return null;
  const s = Math.floor(ms / 1000), m = Math.floor(s/60), h = Math.floor(m/60), d = Math.floor(h/24);
  if (s < 60) return `${s}s`;
  if (m < 60) return `${m}m ${s%60}s`;
  if (h < 24) return `${h}h ${m%60}m`;
  return `${d}d ${h%24}h`;
};
const mean   = arr => arr.length ? arr.reduce((s,v)=>s+v,0)/arr.length : 0;
const stdDev = arr => {
  if (arr.length < 2) return 0;
  const m = mean(arr);
  return Math.sqrt(arr.reduce((s,v)=>s+(v-m)**2,0)/arr.length);
};
const dayKey = ts => {
  const d = new Date(ts);
  return `${d.getUTCFullYear()}-${String(d.getUTCMonth()+1).padStart(2,'0')}-${String(d.getUTCDate()).padStart(2,'0')}`;
};

function calculateBehaviour(parsedData) {

  // Prepare trades: market orders only, sorted by close time
  const trades = parsedData.closedTrades
    .filter(t => t.type && (t.type.includes('buy') || t.type.includes('sell')))
    .map(t => ({
      ...t,
      netPL:   (t.profit ?? 0) + (t.commission ?? 0) + (t.swap ?? 0) + (t.taxes ?? 0),
      durMs:   durMs(t.openTime, t.closeTime),
      openTs:  toTs(t.openTime),
      closeTs: toTs(t.closeTime),
    }))
    .sort((a, b) => (a.closeTs ?? a.openTs ?? 0) - (b.closeTs ?? b.openTs ?? 0));

  if (!trades.length) return null;
  const n = trades.length;

  /* ── 1. LOT ESCALATION ────────────────────────────────── */
  const lots = trades.map(t => t.lots ?? 0).filter(l => l > 0);
  const avgLot = mean(lots);
  const sdLot  = stdDev(lots);
  const lotCV  = avgLot > 0 ? sdLot / avgLot : 0;  // coefficient of variation
  const maxLot = lots.length ? Math.max(...lots) : 0;

  const escalationEvents = [];
  let escalationCount = 0;
  const losses = trades.filter(t => t.netPL < 0 && t.lots);

  for (let i = 1; i < n; i++) {
    const prev = trades[i - 1], curr = trades[i];
    if (prev.netPL < 0 && prev.lots && curr.lots && curr.lots > prev.lots) {
      escalationCount++;
      escalationEvents.push({
        index:        i,
        lossTicket:   prev.ticket,
        lossLots:     prev.lots,
        lossNetPL:    prev.netPL,
        lossSymbol:   prev.symbol,
        nextTicket:   curr.ticket,
        nextLots:     curr.lots,
        multiplier:   curr.lots / prev.lots,
        nextNetPL:    curr.netPL,
        nextSymbol:   curr.symbol,
      });
    }
  }

  const escalationRate   = losses.length ? escalationCount / losses.length * 100 : 0;
  const avgMultiplier    = escalationEvents.length ? mean(escalationEvents.map(e => e.multiplier)) : null;
  const maxMultiplier    = escalationEvents.length ? Math.max(...escalationEvents.map(e => e.multiplier)) : null;

  // Martingale confidence score 0-100
  let martingaleConf = 0;
  if (escalationRate > 30)    martingaleConf += 30;
  if (escalationRate > 50)    martingaleConf += 20;
  if (avgMultiplier > 1.5)    martingaleConf += 25;
  if (avgMultiplier > 1.8)    martingaleConf += 15;
  if (maxMultiplier > 3)      martingaleConf += 10;
  martingaleConf = Math.min(martingaleConf, 100);

  /* ── 2. HOLDING BEHAVIOUR ─────────────────────────────── */
  const winWithDur  = trades.filter(t => t.netPL > 0 && t.durMs && t.durMs > 0);
  const lossWithDur = trades.filter(t => t.netPL < 0 && t.durMs && t.durMs > 0);

  const avgHoldWin  = winWithDur.length  ? mean(winWithDur.map(t => t.durMs))  : null;
  const avgHoldLoss = lossWithDur.length ? mean(lossWithDur.map(t => t.durMs)) : null;

  // Ratio > 1: holds winners longer than losers (good discipline)
  // Ratio < 1: cuts winners short, holds losers (bad — "let losers run, cut winners")
  const holdRatio = avgHoldWin && avgHoldLoss ? avgHoldWin / avgHoldLoss : null;
  const cutsWinnersShort = holdRatio !== null && holdRatio < 1.0;
  const holdsLosersLong  = holdRatio !== null && holdRatio > 2.0;

  // TP proximity: winner closed within 85% of the TP distance → "hit TP"
  const tradesWithTP = trades.filter(t => t.tp && t.tp > 0 && t.openPrice && t.closePrice && t.netPL > 0);
  const tpHits = tradesWithTP.filter(t => {
    const tpDist    = Math.abs(t.tp - t.openPrice);
    const closeDist = Math.abs(t.closePrice - t.openPrice);
    return tpDist > 0 && closeDist / tpDist >= 0.85;
  });
  const tpHitRate = tradesWithTP.length ? tpHits.length / tradesWithTP.length * 100 : null;

  // SL proximity: loser closed within 85% of the SL distance → "hit SL"
  const tradesWithSL = trades.filter(t => t.sl && t.sl > 0 && t.openPrice && t.closePrice && t.netPL < 0);
  const slHits = tradesWithSL.filter(t => {
    const slDist    = Math.abs(t.sl - t.openPrice);
    const closeDist = Math.abs(t.closePrice - t.openPrice);
    return slDist > 0 && closeDist / slDist >= 0.85;
  });
  const slHitRate = tradesWithSL.length ? slHits.length / tradesWithSL.length * 100 : null;

  /* ── 3. OVERTRADING ───────────────────────────────────── */
  const dayMap = {};
  trades.forEach(t => {
    const ts = t.openTs ?? t.closeTs;
    if (!ts) return;
    const dk = dayKey(ts);
    if (!dayMap[dk]) dayMap[dk] = { date: dk, count: 0, wins: 0, losses: 0, netPL: 0, trades: [] };
    dayMap[dk].count++;
    if (t.netPL > 0) dayMap[dk].wins++;
    else if (t.netPL < 0) dayMap[dk].losses++;
    dayMap[dk].netPL += t.netPL;
    dayMap[dk].trades.push(t);
  });
  const dayStats = Object.values(dayMap).sort((a, b) => a.date.localeCompare(b.date));
  const uniqueTradingDays = dayStats.length || 1;
  const avgPerTradingDay  = n / uniqueTradingDays;

  const allTs = trades.map(t => t.openTs ?? t.closeTs).filter(Boolean);
  const calDays = allTs.length > 1
    ? Math.max(1, Math.round((Math.max(...allTs) - Math.min(...allTs)) / 86400000) + 1)
    : 1;
  const tradesPerCalDay = n / calDays;

  // Overtrading days: any day where count exceeds 2× the average
  const overtradingDays = dayStats.filter(d => d.count > avgPerTradingDay * 2);
  const maxInDay = dayStats.length ? Math.max(...dayStats.map(d => d.count)) : 0;

  // Frequency score (0-100): composite indicator
  let frequencyScore = 0;
  if (avgPerTradingDay > 20)      frequencyScore = 90;
  else if (avgPerTradingDay > 10) frequencyScore = 70;
  else if (avgPerTradingDay > 5)  frequencyScore = 45;
  else if (avgPerTradingDay > 3)  frequencyScore = 25;
  else                            frequencyScore = 10;
  if (overtradingDays.length / uniqueTradingDays > 0.3) frequencyScore = Math.min(frequencyScore + 15, 100);

  /* ── 4. RECOVERY BEHAVIOUR ────────────────────────────── */
  const baselineWinRate  = trades.filter(t => t.netPL > 0).length / n * 100;
  const reentryDelays    = [];
  const postLossResults  = [];
  const sameSymbolFlags  = [];
  const immediateReentries = []; // < 5 min re-entry
  const consLossEvents   = { after2: [], after3: [], after4: [] };
  let consLoss = 0;

  for (let i = 0; i < n; i++) {
    const t = trades[i];
    if (t.netPL < 0) { consLoss++; } else { consLoss = 0; }

    if (t.netPL < 0 && i + 1 < n) {
      const next = trades[i + 1];
      const lossClose = t.closeTs, nextOpen = next.openTs;

      if (lossClose && nextOpen && nextOpen > lossClose) {
        const delay = nextOpen - lossClose;
        reentryDelays.push(delay);
        postLossResults.push(next.netPL > 0);
        sameSymbolFlags.push(!!(next.symbol && t.symbol && next.symbol === t.symbol));

        if (delay < 300_000) {  // < 5 minutes = immediate re-entry
          immediateReentries.push({ delay, prevTrade: t, nextTrade: next });
        }
      }

      // Consecutive loss events (track the trade after the Nth consecutive loss)
      const ev = {
        lots:   next.lots,
        win:    next.netPL > 0,
        delay:  lossClose && next.openTs ? next.openTs - lossClose : null,
      };
      if (consLoss >= 4)      consLossEvents.after4.push(ev);
      else if (consLoss >= 3) consLossEvents.after3.push(ev);
      else if (consLoss >= 2) consLossEvents.after2.push(ev);
    }
  }

  const avgReentryDelay     = reentryDelays.length ? mean(reentryDelays) : null;
  const immediateReentryRate = losses.length ? immediateReentries.length / losses.length * 100 : 0;
  const postLossWinRate     = postLossResults.length
    ? postLossResults.filter(Boolean).length / postLossResults.length * 100 : null;
  const sameSymbolRate      = sameSymbolFlags.length
    ? sameSymbolFlags.filter(Boolean).length / sameSymbolFlags.length * 100 : 0;

  // Aggregate consecutive loss reaction stats
  const consecutiveLoss = {};
  [['after2', 2], ['after3', 3], ['after4plus', 4]].forEach(([key, k]) => {
    const evArr = consLossEvents[k === 4 ? 'after4' : `after${k}`];
    consecutiveLoss[key] = {
      count:    evArr.length,
      avgLot:   evArr.filter(e => e.lots).length ? mean(evArr.filter(e=>e.lots).map(e=>e.lots)) : null,
      winRate:  evArr.length ? evArr.filter(e => e.win).length / evArr.length * 100 : null,
      avgDelay: evArr.filter(e => e.delay).length ? mean(evArr.filter(e=>e.delay).map(e=>e.delay)) : null,
    };
  });

  // Revenge trade detection: high immediate re-entry rate + win rate significantly below baseline
  const revengeDetected = immediateReentryRate > 25
    && postLossWinRate !== null
    && postLossWinRate < baselineWinRate - 10;

  /* ── 5. CONCENTRATION ────────────────────────────────── */
  const symMap = {};
  trades.forEach(t => {
    const s = t.symbol || 'Unknown';
    if (!symMap[s]) symMap[s] = { symbol: s, count: 0, wins: 0, losses: 0, netPL: 0 };
    symMap[s].count++;
    if (t.netPL > 0)      symMap[s].wins++;
    else if (t.netPL < 0) symMap[s].losses++;
    symMap[s].netPL += t.netPL;
  });
  const symbolStats = Object.values(symMap)
    .map(s => ({ ...s, winRate: s.count ? s.wins/s.count*100 : 0, tradePct: n ? s.count/n*100 : 0 }))
    .sort((a, b) => b.count - a.count);

  const topSym        = symbolStats[0] || null;
  const topLosing     = [...symbolStats].sort((a, b) => a.netPL - b.netPL)[0] || null;
  const topByLossCount = [...symbolStats].sort((a, b) => b.losses - a.losses)[0] || null;
  const topPct        = topSym ? topSym.count / n * 100 : 0;

  // Concentration score (0-100): higher = more concentrated risk
  let concentrationScore = Math.min(topPct * 1.2, 100);
  if (symbolStats.length <= 2) concentrationScore = Math.min(concentrationScore + 20, 100);

  /* ── OVERALL BEHAVIOUR SCORE (0-100, higher = worse) ─── */
  let behaviourScore = 0;
  if (escalationRate > 40)          behaviourScore += 25;
  else if (escalationRate > 20)     behaviourScore += 12;
  if (cutsWinnersShort)             behaviourScore += 20;
  if (frequencyScore > 60)          behaviourScore += 15;
  if (revengeDetected)              behaviourScore += 20;
  if (immediateReentryRate > 30)    behaviourScore += 10;
  if (concentrationScore > 70)      behaviourScore += 10;
  behaviourScore = Math.min(behaviourScore, 100);

  /* ── RETURN ──────────────────────────────────────────── */
  return {
    // ── Lot Escalation ──────────────────────────────────
    lotEscalation: {
      escalationRate,            // % of losses followed by larger lot
      escalationCount,           // raw count of escalation events
      escalationEvents,          // array of {index, lossLots, nextLots, multiplier, ...}
      avgMultiplier,             // average lot increase factor after loss
      maxMultiplier,             // largest single escalation detected
      lotCV,                     // coefficient of variation (stdDev/mean)
      avgLot,                    // mean lot size across all trades
      maxLot,                    // largest single lot
      sdLot,                     // lot size standard deviation
      martingaleConf,            // 0-100 composite martingale confidence
      lossCount: losses.length,
    },
    // ── Holding Behaviour ───────────────────────────────
    holdingBehaviour: {
      avgHoldWin,                // avg duration (ms) of winning trades
      avgHoldLoss,               // avg duration (ms) of losing trades
      avgHoldWinFormatted:  fmtDuration(avgHoldWin),
      avgHoldLossFormatted: fmtDuration(avgHoldLoss),
      holdRatio,                 // avgHoldWin / avgHoldLoss (<1 = cuts winners short)
      cutsWinnersShort,          // boolean: holdRatio < 1.0
      holdsLosersLong,           // boolean: holdRatio > 2.0
      tpHitRate,                 // % of winners closed near TP
      slHitRate,                 // % of losers closed near SL
      winWithDurCount: winWithDur.length,
      lossWithDurCount: lossWithDur.length,
    },
    // ── Overtrading ─────────────────────────────────────
    overtrading: {
      tradesPerCalDay,           // total trades / calendar days
      avgPerTradingDay,          // total trades / unique trading days
      maxInDay,                  // busiest single day
      uniqueTradingDays,
      calDays,
      overtradingDays,           // array of day objects where count > 2× average
      dayStats,                  // all trading days with count, wins, losses, netPL
      frequencyScore,            // 0-100 composite (higher = more overtrading concern)
    },
    // ── Recovery Behaviour ──────────────────────────────
    recoveryBehaviour: {
      avgReentryDelay,                        // ms average from loss close to next trade open
      avgReentryDelayFormatted: fmtDuration(avgReentryDelay),
      immediateReentryRate,                   // % of losses with re-entry < 5 min
      immediateReentryCount: immediateReentries.length,
      postLossWinRate,                        // win rate on trades immediately after a loss
      baselineWinRate,                        // overall win rate for comparison
      postLossWinRateDelta: postLossWinRate !== null ? postLossWinRate - baselineWinRate : null,
      sameSymbolRate,                         // % of re-entries on same symbol as the loss
      revengeDetected,                        // boolean: immediate re-entry + degraded win rate
      consecutiveLoss,                        // { after2, after3, after4plus }: { count, avgLot, winRate, avgDelay }
      postLossCount: postLossResults.length,
    },
    // ── Concentration ───────────────────────────────────
    concentration: {
      topSym,                    // { symbol, count, wins, losses, netPL, winRate, tradePct }
      topLosing,                 // symbol with worst net P&L
      topByLossCount,            // symbol with most losing trades
      symbolStats,               // all symbols sorted by trade count
      concentrationScore,        // 0-100 (higher = more concentrated)
      topPct,                    // % of trades on top symbol
      totalLossTrades: losses.length,
    },
    // ── Summary ─────────────────────────────────────────
    behaviourScore,              // 0-100 composite concern score (higher = worse behaviour)
    totalTrades: n,
    currency:    parsedData.accountInfo?.currency || '',
    accountInfo: parsedData.accountInfo,
    trades,                      // all trades with netPL, durMs, openTs, closeTs
  };
}

/* ═══ rulesEngine.js ═══ */
/* ═══════════════════════════════════════════════════════════
   DataLB Rules Engine v1
   Inputs:  metrics  — from datalb_metrics_v2
            sessions — from datalb_session_engine_v1
            behaviour— from datalb_behaviour_engine_v1
   Output:  DiagnosisResult object
   ─────────────────────────────────────────────────────────
   25 rules across 5 categories:
     RISK (6)          R-001 → R-006
     BEHAVIOUR (7)     B-001 → B-007
     SESSION (4)       S-001 → S-004
     RECOVERY (4)      RC-001 → RC-004
     CONCENTRATION (4) C-001 → C-004
═══════════════════════════════════════════════════════════ */

const SESS_DEFS = [
  { key: 'Asia', start: 0, end: 8 },
  { key: 'London', start: 8, end: 13 },
  { key: 'NewYork', start: 13, end: 22 },
  { key: 'After', start: 22, end: 24 },
];

/**
 * Build and evaluate all 25 rules.
 *
 * @param {object} m  — MetricsResult from calculateMetrics()
 * @param {object} s  — SessionAnalytics from calculateSessions()
 * @param {object} b  — BehaviourAnalytics from calculateBehaviour()
 * @returns {Rule[]}  — complete rule array with .triggered flag
 */
function buildRules(m, s, b) {
  const S = s.sessions;
  const fmtC = v => Math.abs(v ?? 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const fmtP = v => v == null ? '—' : `${v.toFixed(1)}%`;
  const fmtPF = v => v == null ? '—' : v === Infinity ? '∞' : v.toFixed(2);
  const cur = m.currency || '';

  // Find worst/best sessions by a given key (requiring minimum trade count)
  const worstSessBy = (key, minCount = 10) => {
    const el = SESS_DEFS.filter(sd => S[sd.key]?.count >= minCount);
    return el.length ? el.reduce((a, b_) => (S[a.key][key] <= S[b_.key][key] ? a : b_)) : null;
  };
  const bestSessBy = (key, minCount = 10) => {
    const el = SESS_DEFS.filter(sd => S[sd.key]?.count >= minCount);
    return el.length ? el.reduce((a, b_) => (S[a.key][key] >= S[b_.key][key] ? a : b_)) : null;
  };

  const worstSessPF = worstSessBy('profitFactor');
  const worstSessNP = worstSessBy('netProfit');
  const bestSessNP  = bestSessBy('netProfit');

  const rules = [

    /* ── RISK ───────────────────────────────────────────────────── */
    {
      id: 'R-001', name: 'System Unprofitability',
      category: 'RISK', severity: 'CRITICAL', priorityScore: 100,
      triggered: m.profitFactor < 1.0,
      triggerValue: `PF ${fmtPF(m.profitFactor)} < 1.0`,
      triggerCondition: 'profitFactor < 1.0',
      problem: 'The account loses more than it earns. No trade frequency, win rate, or position size adjustment can produce long-term profitability when PF < 1.0.',
      impact: `${cur} ${fmtC(m.grossLossAbs)} gross loss vs ${cur} ${fmtC(m.grossProfit)} gross profit. Account is on a mathematical depletion trajectory.`,
      recommendation: 'Halt trading immediately. Audit every losing trade. Set a minimum target of PF > 1.3 before returning to live trading. Do not add capital.',
    },
    {
      id: 'R-002', name: 'Inverse Risk Structure',
      category: 'RISK', severity: 'CRITICAL', priorityScore: 95,
      triggered: m.avgWin != null && m.avgLoss != null && m.avgLoss / m.avgWin > 2.0,
      triggerValue: m.avgWin && m.avgLoss
        ? `Avg Loss ${fmtC(m.avgLoss)} = ${(m.avgLoss / m.avgWin).toFixed(2)}× Avg Win ${fmtC(m.avgWin)}`
        : '—',
      triggerCondition: 'avgLoss / avgWin > 2.0',
      problem: 'Average loss is more than twice the average win. The account requires an unsustainably high win rate to break even.',
      impact: 'A modest win rate decline produces disproportionately large losses. High win rate periods mask the structural problem.',
      recommendation: 'Set a minimum RRR of 1:1.5 on every trade entry. No trade may have a potential loss exceeding 67% of the potential reward.',
    },
    {
      id: 'R-003', name: 'Extreme Drawdown',
      category: 'RISK', severity: 'CRITICAL', priorityScore: 90,
      triggered: m.maxRelDD > 30,
      triggerValue: `Max DD: ${fmtP(m.maxRelDD)} > 30%`,
      triggerCondition: 'maxRelDD > 30',
      problem: `Peak-to-trough equity decline of ${fmtP(m.maxRelDD)}. Recovery requires a ${((1 / (1 - m.maxRelDD / 100) - 1) * 100).toFixed(0)}% gain from the trough.`,
      impact: 'Psychological pressure from extreme drawdown typically produces compensatory behaviors that deepen it further. Statistical recovery is unlikely without structural change.',
      recommendation: 'Apply a hard daily loss limit of 3% of equity. Reduce position sizes by 50% until recovery to within 10% of peak. No size increase until full recovery.',
    },
    {
      id: 'R-004', name: 'Elevated Drawdown',
      category: 'RISK', severity: 'HIGH', priorityScore: 72,
      triggered: m.maxRelDD > 15 && m.maxRelDD <= 30,
      triggerValue: `Max DD: ${fmtP(m.maxRelDD)} (threshold: > 15%)`,
      triggerCondition: 'maxRelDD > 15 AND maxRelDD <= 30',
      problem: `Max drawdown of ${fmtP(m.maxRelDD)} exceeds the 15% professional norm. Risk management is not consistently applied.`,
      impact: 'Account at elevated risk of crossing into extreme drawdown zone. Recovery periods are extended.',
      recommendation: 'After any 3-trade losing sequence, reduce lot size by 25% until the next 5 trades show positive expectancy. Implement a 5% weekly loss limit.',
    },
    {
      id: 'R-005', name: 'Net Negative Account',
      category: 'RISK', severity: 'HIGH', priorityScore: 70,
      triggered: m.netProfit < 0 && m.totalTrades >= 10,
      triggerValue: `Net Profit: ${cur} ${m.netProfit < 0 ? '-' : ''}${fmtC(Math.abs(m.netProfit))}`,
      triggerCondition: 'netProfit < 0 AND totalTrades >= 10',
      problem: 'The account is net negative across the full statement period. Each additional trade in the current system statistically reduces account balance.',
      impact: 'Continued trading at current parameters will exhaust account capital. Trajectory is net-downward.',
      recommendation: 'Perform a full postmortem of every losing trade. Paper trade any strategy changes for 50+ trades before returning to live risk.',
    },
    {
      id: 'R-006', name: 'Poor Recovery Factor',
      category: 'RISK', severity: 'HIGH', priorityScore: 65,
      triggered: m.recoveryFactor !== null && m.recoveryFactor < 1.0 && m.netProfit > 0,
      triggerValue: m.recoveryFactor != null ? `Recovery Factor: ${m.recoveryFactor.toFixed(2)} < 1.0` : '—',
      triggerCondition: 'recoveryFactor < 1.0 AND netProfit > 0',
      problem: 'Net profit is less than the maximum drawdown sustained. Risk capital consumed exceeds returns generated.',
      impact: 'Strategy consumes more risk capital than it generates. Future adverse sequences likely to push into net loss before profits compound.',
      recommendation: 'Target recovery factor > 2.0. Reduce drawdown through tighter sizing, OR improve net profit through better entry selectivity.',
    },

    /* ── BEHAVIOUR ───────────────────────────────────────────── */
    {
      id: 'B-001', name: 'Martingale Pattern Detected',
      category: 'BEHAVIOUR', severity: 'CRITICAL', priorityScore: 92,
      triggered: b.lotEscalation.martingaleConf > 65,
      triggerValue: `Martingale Confidence: ${b.lotEscalation.martingaleConf}/100 (escalation ${fmtP(b.lotEscalation.escalationRate)}, avg ×${b.lotEscalation.avgMultiplier?.toFixed(2) || '—'})`,
      triggerCondition: 'martingaleConf > 65',
      problem: `Systematic pattern of multiplying position size after losses confirmed with ${b.lotEscalation.martingaleConf}% confidence.`,
      impact: 'Martingale strategies guarantee eventual catastrophic loss. A long enough losing sequence — which occurs with mathematical certainty — will exceed account capital.',
      recommendation: 'Eliminate escalation rule entirely. Switch to fixed-percentage risk model (max 1% equity per trade). All positions must be identically sized regardless of prior outcomes.',
    },
    {
      id: 'B-002', name: 'Significant Lot Escalation',
      category: 'BEHAVIOUR', severity: 'HIGH', priorityScore: 78,
      triggered: b.lotEscalation.escalationRate > 40 && b.lotEscalation.martingaleConf <= 65,
      triggerValue: `Escalation Rate: ${fmtP(b.lotEscalation.escalationRate)} of losses (threshold: > 40%)`,
      triggerCondition: 'escalationRate > 40 AND martingaleConf <= 65',
      problem: 'More than 40% of losing trades are followed by a larger position. Position sizing reacts to outcomes rather than following a fixed risk framework.',
      impact: 'Larger positions after losses increase exposure at the statistically worst moments, deepening drawdown sequences.',
      recommendation: 'Remove all discretion from position sizing. Calculate every lot using: (equity × risk%) / (SL pips × pip value). Prior trade outcome must not be an input.',
    },
    {
      id: 'B-003', name: 'Moderate Lot Escalation',
      category: 'BEHAVIOUR', severity: 'MEDIUM', priorityScore: 50,
      triggered: b.lotEscalation.escalationRate > 20 && b.lotEscalation.escalationRate <= 40,
      triggerValue: `Escalation Rate: ${fmtP(b.lotEscalation.escalationRate)} of losses (threshold: > 20%)`,
      triggerCondition: 'escalationRate > 20 AND escalationRate <= 40',
      problem: 'Approximately one in five losing trades is followed by a position size increase. A developing emotional response pattern.',
      impact: 'Minor compounding of loss sequences during drawdown. Escalation rate is likely to increase as adverse periods extend.',
      recommendation: 'Set a pre-trade alert if proposed lot size exceeds the 5-trade average by more than 10%. Log each decision to raise awareness of post-loss sizing choices.',
    },
    {
      id: 'B-004', name: 'Cuts Winners Short — Holds Losers Long',
      category: 'BEHAVIOUR', severity: 'HIGH', priorityScore: 74,
      triggered: b.holdingBehaviour.holdRatio !== null && b.holdingBehaviour.holdRatio < 0.85,
      triggerValue: b.holdingBehaviour.holdRatio != null
        ? `Hold Ratio: ${b.holdingBehaviour.holdRatio.toFixed(2)} (winners held ${((1 - b.holdingBehaviour.holdRatio) * 100).toFixed(0)}% shorter than losers)`
        : '—',
      triggerCondition: 'avgHoldWin / avgHoldLoss < 0.85',
      problem: 'Winning trades are closed faster than losing trades. Fear of giving back profits combined with hope on losses creates a structural asymmetry.',
      impact: 'Suppresses average win below potential maximum while allowing average loss to run. Primary driver of poor profit factor even at high win rates.',
      recommendation: 'Stop managing winners before they reach the original TP. The only valid exits are TP, SL, or a specific technical invalidation. Pre-defined exits must not change based on current P&L.',
    },
    {
      id: 'B-005', name: 'Overtrading Detected',
      category: 'BEHAVIOUR', severity: 'HIGH', priorityScore: 68,
      triggered: b.overtrading.frequencyScore > 65,
      triggerValue: `Frequency Score: ${b.overtrading.frequencyScore}/100 — ${b.overtrading.avgPerTradingDay.toFixed(1)} avg trades/day, ${b.overtrading.overtradingDays} overtrading days`,
      triggerCondition: 'frequencyScore > 65',
      problem: `Trade frequency exceeds the statistical threshold where quality setups are present. ${b.overtrading.avgPerTradingDay.toFixed(1)} trades/day includes marginal and low-quality entries.`,
      impact: 'Transaction costs consume larger percentage of gross profit. Win rate on above-average-frequency days is statistically lower.',
      recommendation: `Set a daily trade limit at ${Math.max(2, Math.round(b.overtrading.avgPerTradingDay * 0.5))} trades. After reaching the limit, stop trading regardless of apparent setups.`,
    },
    {
      id: 'B-006', name: 'Inconsistent Position Sizing',
      category: 'BEHAVIOUR', severity: 'MEDIUM', priorityScore: 48,
      triggered: b.lotEscalation.lotCV > 0.5,
      triggerValue: `Lot CV: ${(b.lotEscalation.lotCV * 100).toFixed(1)}% (threshold: > 50%) — avg ${b.lotEscalation.avgLot?.toFixed(3) || '—'} lots`,
      triggerCondition: 'lotCV > 0.5',
      problem: `Lot sizes vary by more than 50% of the mean. CV at ${(b.lotEscalation.lotCV * 100).toFixed(1)}% indicates discretionary, non-systematic position sizing.`,
      impact: 'Equity curve volatility is unpredictably high. A large discretionary position during a loss amplifies drawdown beyond systematic sizing would produce.',
      recommendation: 'Implement a fixed risk calculator: every trade sized to exactly 1% of current equity. Lot size must flow from SL distance — not conviction level or arbitrary preference.',
    },
    {
      id: 'B-007', name: 'Low Take Profit Hit Rate',
      category: 'BEHAVIOUR', severity: 'MEDIUM', priorityScore: 42,
      triggered: b.holdingBehaviour.tpHitRate !== null && b.holdingBehaviour.tpHitRate < 30,
      triggerValue: b.holdingBehaviour.tpHitRate != null
        ? `TP Hit Rate: ${fmtP(b.holdingBehaviour.tpHitRate)} (threshold: < 30%)`
        : 'Insufficient TP data',
      triggerCondition: 'tpHitRate < 30 AND tpHitRate is calculable',
      problem: `Only ${fmtP(b.holdingBehaviour.tpHitRate)} of winning trades are closed at or near the original TP. Winners are being exited before reaching planned reward.`,
      impact: 'Pre-trade RRR calculations are systematically overstated. Effective average win is significantly below planned average win.',
      recommendation: 'Review each early exit. Tactical exits (setup invalidation) are acceptable. Emotional exits (fear of retracement) must stop. Consider trailing stops to let profits run.',
    },

    /* ── SESSION ─────────────────────────────────────────────── */
    {
      id: 'S-001', name: 'Persistently Negative Session',
      category: 'SESSION', severity: 'HIGH', priorityScore: 74,
      triggered: worstSessNP !== null && S[worstSessNP.key]?.netProfit < 0 && S[worstSessNP.key]?.count >= 10,
      triggerValue: worstSessNP
        ? `${worstSessNP.key} Session: Net ${fmtC(S[worstSessNP.key].netProfit)} on ${S[worstSessNP.key].count} trades`
        : '—',
      triggerCondition: 'any session: netProfit < 0 AND count >= 10',
      problem: `The ${worstSessNP?.key || '—'} session is consistently loss-making with statistically meaningful sample size. No edge is present in this market window.`,
      impact: `Trading in the ${worstSessNP?.key || '—'} session destroys profits earned in other sessions. P&L is a direct drag on the overall account.`,
      recommendation: `Immediately restrict trading during the ${worstSessNP?.key || '—'} session. Do not re-enter until 50 paper trades show positive PF. Focus on the ${bestSessNP?.key || 'best performing'} session.`,
    },
    {
      id: 'S-002', name: 'Inefficient Session — Low Profit Factor',
      category: 'SESSION', severity: 'HIGH', priorityScore: 70,
      triggered: worstSessPF !== null && S[worstSessPF.key]?.profitFactor < 0.8 && S[worstSessPF.key]?.count >= 10,
      triggerValue: worstSessPF
        ? `${worstSessPF.key} Session PF: ${fmtPF(S[worstSessPF.key].profitFactor)} < 0.80 on ${S[worstSessPF.key].count} trades`
        : '—',
      triggerCondition: 'any session: profitFactor < 0.80 AND count >= 10',
      problem: `The ${worstSessPF?.key || '—'} session has PF below 0.80 across a meaningful sample. For every $100 won, $125+ is lost in this session.`,
      impact: 'The more trades logged in this session, the faster it erodes profitability built in other sessions.',
      recommendation: `Review instruments and setups during the ${worstSessPF?.key || '—'} session. If no differentiating pattern is found, suspend this session entirely.`,
    },
    {
      id: 'S-003', name: 'Wide Session Performance Disparity',
      category: 'SESSION', severity: 'MEDIUM', priorityScore: 46,
      triggered: (() => {
        const el = SESS_DEFS.filter(sd => S[sd.key]?.count >= 10 && S[sd.key]?.profitFactor < Infinity);
        if (el.length < 2) return false;
        const pfs = el.map(sd => Math.min(S[sd.key].profitFactor, 5));
        return Math.max(...pfs) / Math.max(Math.min(...pfs), 0.01) > 3;
      })(),
      triggerValue: 'Best vs Worst session PF ratio > 3:1',
      triggerCondition: 'max(sessionPF) / min(sessionPF) > 3 with ≥ 2 sessions with ≥ 10 trades',
      problem: 'Wide PF disparity between sessions indicates the strategy is not time-neutral and has unrecognised session-specific dependencies.',
      impact: 'Performance is fragile — heavily dependent on which sessions are traded. A schedule shift can dramatically change outcomes.',
      recommendation: 'Identify characteristics of the best-performing session. Apply those filters to screen out low-quality setups in underperforming sessions, or restrict to top 1–2 sessions.',
    },
    {
      id: 'S-004', name: 'Extreme Session Concentration',
      category: 'SESSION', severity: 'LOW', priorityScore: 22,
      triggered: (() => {
        if (!m.totalTrades) return false;
        return Math.max(...SESS_DEFS.map(sd => (S[sd.key]?.count || 0) / m.totalTrades * 100)) > 85;
      })(),
      triggerValue: 'One session contains >85% of all trades',
      triggerCondition: 'max(sessionTradeShare) > 85%',
      problem: 'More than 85% of trades are concentrated in a single session. All performance depends on one market window.',
      impact: 'A regime change in the dominant session leaves the account with no multi-session fallback.',
      recommendation: 'If intentional, ensure dominant session PF > 1.3. If not intentional, expand the trading window incrementally and track per-session performance separately.',
    },

    /* ── RECOVERY ─────────────────────────────────────────────── */
    {
      id: 'RC-001', name: 'Revenge Trading Pattern',
      category: 'RECOVERY', severity: 'HIGH', priorityScore: 80,
      triggered: b.recoveryBehaviour.revengeDetected,
      triggerValue: `Immediate re-entry: ${fmtP(b.recoveryBehaviour.immediateReentryRate)} of losses — post-loss win rate: ${fmtP(b.recoveryBehaviour.postLossWinRate)} vs ${fmtP(b.recoveryBehaviour.baselineWinRate)} baseline`,
      triggerCondition: 'immediateReentryRate > 25 AND postLossWinRate < baselineWinRate - 10',
      problem: 'Confirmed revenge trading: high immediate re-entry rate after losses combined with significantly degraded win rate on those trades.',
      impact: 'Post-loss trades entered with urgency rather than process. More likely to be poorly positioned, oversized, and poorly exited — turning a single loss into a multi-loss sequence.',
      recommendation: 'Implement a mandatory 15-minute cool-down period after every loss before any new trade may be opened. This must be a hard rule, not a guideline.',
    },
    {
      id: 'RC-002', name: 'High Immediate Re-Entry Rate',
      category: 'RECOVERY', severity: 'HIGH', priorityScore: 75,
      triggered: b.recoveryBehaviour.immediateReentryRate > 30 && !b.recoveryBehaviour.revengeDetected,
      triggerValue: `Immediate Re-Entry: ${fmtP(b.recoveryBehaviour.immediateReentryRate)} of losses (threshold: > 30%)`,
      triggerCondition: 'immediateReentryRate > 30 AND revengeDetected = false',
      problem: `${fmtP(b.recoveryBehaviour.immediateReentryRate)} of losses are followed by a new trade within 5 minutes. Trader is not pausing to assess the loss before re-engaging.`,
      impact: 'Rapid re-entry concentrates trade timing into emotionally charged periods, creating vulnerability to escalation.',
      recommendation: 'Introduce a 5-minute minimum wait period after any loss. During this window, review the loss objectively before considering the next entry.',
    },
    {
      id: 'RC-003', name: 'Post-Loss Win Rate Degradation',
      category: 'RECOVERY', severity: 'HIGH', priorityScore: 71,
      triggered: b.recoveryBehaviour.postLossWinRate !== null
        && (b.recoveryBehaviour.postLossWinRate - b.recoveryBehaviour.baselineWinRate) < -20,
      triggerValue: `Post-loss win rate: ${fmtP(b.recoveryBehaviour.postLossWinRate)} vs baseline: ${fmtP(b.recoveryBehaviour.baselineWinRate)}`,
      triggerCondition: 'postLossWinRate < baselineWinRate - 20',
      problem: 'Win rate on trades taken immediately after a loss is > 20 percentage points below baseline. Emotional state post-loss is measurably impacting entry quality.',
      impact: 'Losing sequences extend beyond their natural statistical length because behavioral factors lower the quality of recovery trades.',
      recommendation: 'Stop trading following a loss within the same session window. Losses reset the entry criteria clock — the next trade must meet the same conditions as the first trade of the day.',
    },
    {
      id: 'RC-004', name: 'Same-Symbol Re-Entry After Loss',
      category: 'RECOVERY', severity: 'MEDIUM', priorityScore: 44,
      triggered: b.recoveryBehaviour.sameSymbolRate > 60,
      triggerValue: `Same-symbol re-entry rate: ${fmtP(b.recoveryBehaviour.sameSymbolRate)} of post-loss entries`,
      triggerCondition: 'sameSymbolRate > 60',
      problem: `${fmtP(b.recoveryBehaviour.sameSymbolRate)} of trades after a loss are on the same symbol as the loss. Trader is returning to recover the specific loss rather than finding the next best setup.`,
      impact: 'Re-entering the same symbol after a loss means entering at a price level that was unfavourable moments earlier.',
      recommendation: 'After any loss, impose a 30-minute restriction on re-entering the same symbol. Next trade must be on a different instrument or wait for a new session structure.',
    },

    /* ── CONCENTRATION ───────────────────────────────────────── */
    {
      id: 'C-001', name: 'Extreme Symbol Concentration',
      category: 'CONCENTRATION', severity: 'HIGH', priorityScore: 67,
      triggered: b.concentration.topPct > 75,
      triggerValue: `Top symbol "${b.concentration.topSym?.sym || '—'}": ${fmtP(b.concentration.topPct)} of all trades (threshold: > 75%)`,
      triggerCondition: 'topSymbolTradePct > 75',
      problem: `${fmtP(b.concentration.topPct)} of all trades concentrated on ${b.concentration.topSym?.sym || '—'}. Entire account performance effectively depends on one instrument.`,
      impact: 'A structural change in the dominant instrument immediately and severely impacts account performance with no offsetting positions.',
      recommendation: 'Introduce at least 2 additional instruments from different asset classes. Cap any single symbol at 60% of monthly trades.',
    },
    {
      id: 'C-002', name: 'High Symbol Concentration',
      category: 'CONCENTRATION', severity: 'MEDIUM', priorityScore: 47,
      triggered: b.concentration.topPct > 55 && b.concentration.topPct <= 75,
      triggerValue: `Top symbol "${b.concentration.topSym?.sym || '—'}": ${fmtP(b.concentration.topPct)} of all trades`,
      triggerCondition: 'topSymbolTradePct > 55 AND topSymbolTradePct <= 75',
      problem: 'More than half of all trades are on a single instrument, reducing the statistical benefit of trading multiple instruments.',
      impact: 'Returns are highly dependent on edge in one instrument. Unusual behavior in that instrument disproportionately affects the account.',
      recommendation: 'Set a soft cap of 50% of monthly trades on any single symbol. Review whether concentration is intentional or a default habit.',
    },
    {
      id: 'C-003', name: 'Single Symbol Driving Losses',
      category: 'CONCENTRATION', severity: 'MEDIUM', priorityScore: 52,
      triggered: b.concentration.topLosingContrib > 45 && b.concentration.topLosing?.sym != null,
      triggerValue: `"${b.concentration.topLosing?.sym || '—'}": ${fmtP(b.concentration.topLosingContrib)} of total gross loss`,
      triggerCondition: 'topLosingSymbol grossLoss contribution > 45%',
      problem: `"${b.concentration.topLosing?.sym || '—'}" is responsible for ${fmtP(b.concentration.topLosingContrib)} of total gross losses. The trading approach appears to have no edge on this specific instrument.`,
      impact: 'Continued trading of this instrument at current parameters accelerates drawdown even when all other symbols are profitable.',
      recommendation: `Immediately suspend trading "${b.concentration.topLosing?.sym || '—'}" pending a 100-trade paper test. Do not return to live trading this symbol until PF > 1.2 on paper.`,
    },
    {
      id: 'C-004', name: 'Insufficient Symbol Diversity',
      category: 'CONCENTRATION', severity: 'LOW', priorityScore: 20,
      triggered: b.concentration.symStats.length <= 2,
      triggerValue: `Only ${b.concentration.symStats.length} symbol(s) traded across ${m.totalTrades} trades`,
      triggerCondition: 'uniqueSymbolsTraded <= 2',
      problem: `The account has traded only ${b.concentration.symStats.length} unique instrument(s). All statistics represent single-instrument data.`,
      impact: 'Any adverse condition specific to this instrument cannot be offset or identified through cross-instrument comparison.',
      recommendation: 'If intentional specialisation: ensure dominant instrument PF > 1.4. If diversification is desired: paper trade 2–3 additional instruments for one month before adding to live trading.',
    },
  ];

  return rules;
}

/**
 * Evaluate all rules and compute the diagnosis score.
 *
 * @param {object} m  — MetricsResult
 * @param {object} s  — SessionAnalytics
 * @param {object} b  — BehaviourAnalytics
 * @returns {DiagnosisResult}
 */
function evaluateRules(m, s, b) {
  const rules = buildRules(m, s, b);
  const triggered = rules.filter(r => r.triggered).sort((a, b_) => b_.priorityScore - a.priorityScore);

  // Scoring: start at 100, subtract per severity
  const PENALTY = { CRITICAL: 20, HIGH: 10, MEDIUM: 5, LOW: 2 };
  let diagScore = 100;
  triggered.forEach(r => { diagScore -= PENALTY[r.severity] || 0; });
  diagScore = Math.max(0, diagScore);

  // Grade mapping
  const grade = diagScore >= 90 ? 'A+' : diagScore >= 78 ? 'A'
    : diagScore >= 62 ? 'B' : diagScore >= 45 ? 'C'
    : diagScore >= 25 ? 'D' : 'F';

  return {
    // All rules (triggered + not triggered)
    allRules: rules,

    // Triggered only
    triggered,

    // By severity (triggered)
    critical: triggered.filter(r => r.severity === 'CRITICAL'),
    high:     triggered.filter(r => r.severity === 'HIGH'),
    medium:   triggered.filter(r => r.severity === 'MEDIUM'),
    low:      triggered.filter(r => r.severity === 'LOW'),

    // Clean rules
    notTriggered: rules.filter(r => !r.triggered),

    // Diagnosis score (0-100) and grade
    diagScore,
    grade,

    // Counts
    totalRules:      rules.length,
    triggeredCount:  triggered.length,
    criticalCount:   triggered.filter(r => r.severity === 'CRITICAL').length,
    highCount:       triggered.filter(r => r.severity === 'HIGH').length,
    mediumCount:     triggered.filter(r => r.severity === 'MEDIUM').length,
    lowCount:        triggered.filter(r => r.severity === 'LOW').length,
  };
}

/* ═══ identityEngine.js ═══ */
/* ═══════════════════════════════════════════════════════════
   DataLB Trader Identity Engine v1

   Inputs:
     m  — MetricsResult      from datalb_metrics_v2.calculateMetrics()
     s  — SessionAnalytics   from datalb_session_engine_v1.calculateSessions()
     b  — BehaviourAnalytics from datalb_behaviour_engine_v1.calculateBehaviour()
     r  — DiagnosisResult    from datalb_rules_engine_v1.evaluateRules()

   Output: TraderIdentity object with:
     - traderType, riskProfile, behaviourProfile, accountGrade
     - confidence scores per dimension (0-100)
     - identityLabel, mainWeakness, mainStrength
     - primaryFailureDriver, recommendedFocus
     - failureProbability (30/90/180-day)
     - warnings, recommendedNextActions
     - supportingEvidence per dimension
     - complete dimension score breakdowns

   Design principle: no single metric determines any dimension.
   Every classification uses a weighted multi-signal scoring system.
   Override rules are applied explicitly AFTER scoring is complete.
═══════════════════════════════════════════════════════════ */
/* ─────────────────────────────────────────────────────────
   SYMBOL CLASSIFICATION DICTIONARIES
───────────────────────────────────────────────────────── */
const SYMBOL_GROUPS = {
  GOLD:   ['XAUUSD','XAUEUR','XAUGBP','XAUAUD','XAUCHF','GOLD','XAU'],
  INDEX:  ['US30','SPX','SP500','NAS100','NASDAQ','GER30','DE30','DAX','UK100','FTSE','NDX','DOW','AUS200','N225','CAC'],
  CRYPTO: ['BTC','ETH','XRP','LTC','ADA','DOT','BNB','SOL'],
  OIL:    ['XTIUSD','WTIUSD','UKOIL','BRENT','CL','OIL'],
  SILVER: ['XAGUSD','XAG','SILVER'],
};

function getSymbolGroup(sym) {
  if (!sym) return 'FOREX';
  const s = sym.toUpperCase().replace(/[mM]+$/, '');   // strip broker suffixes
  for (const [group, list] of Object.entries(SYMBOL_GROUPS)) {
    if (list.some(token => s.includes(token))) return group;
  }
  return 'FOREX';
}

/* ─────────────────────────────────────────────────────────
   UTILITY
───────────────────────────────────────────────────────── */
const clamp  = (v, lo = 0, hi = 100) => Math.max(lo, Math.min(hi, v));
const fmtP   = v => v == null ? '—' : `${Number(v).toFixed(1)}%`;
const fmtPF  = v => v == null ? '—' : v === Infinity ? '∞' : Number(v).toFixed(2);
const fmtMs  = ms => {
  if (!ms || ms <= 0) return '—';
  const s = Math.floor(ms / 1000), m = Math.floor(s / 60),
        h = Math.floor(m / 60), d = Math.floor(h / 24);
  if (s < 60)  return `${s}s`;
  if (m < 60)  return `${m}m`;
  if (h < 24)  return `${h}h ${m % 60}m`;
  return `${d}d ${h % 24}h`;
};

/* ═══════════════════════════════════════════════════════════
   DIMENSION 1 — TRADER TYPE
   Nine types, each scored 0–100 independently.
   Priority override: Martingale (if conf > 65) wins unless
   it is combined with a time-based type as a label modifier.
═══════════════════════════════════════════════════════════ */

/**
 * Raw scoring for all nine trader types.
 * Returns { scores: {TypeKey: 0-100}, evidence: {TypeKey: string[]} }
 */
function scoreTraderTypes(m, s, b) {
  const hold  = m.avgHoldMs;                        // ms or null (overall avg)
  const tpd   = b.overtrading.avgPerTradingDay;     // trades per trading day
  const tpw   = m.tradesPerWeek || tpd * 7 / (m.calDays ? m.calDays / 7 : 1) || tpd * 5;
  const L     = b.lotEscalation;
  const C     = b.concentration;
  const hDist = (s && s.hourDistribution) || Array.from({length: 24}, () => ({count: 0}));
  const topSymRaw = (C.topSym?.symbol || C.topSym?.sym || '').toUpperCase().replace(/[mM]+$/, '');
  const topPct    = C.topPct || 0;
  const topGroup  = getSymbolGroup(topSymRaw);

  const scores   = { Scalper:0, IntradayTrader:0, SwingTrader:0, PositionTrader:0,
                     NewsTrader:0, GoldSpecialist:0, IndexTrader:0, MartingaleTrader:0, HybridTrader:0 };
  const evidence = {};

  /* ── A. MARTINGALE (priority override if confirmed) ───── */
  if (L.martingaleConf > 65) {
    scores.MartingaleTrader = clamp(65 + (L.martingaleConf - 65) * 0.55);
  } else if (L.martingaleConf > 40) {
    scores.MartingaleTrader = clamp(L.martingaleConf * 0.62);
  }
  evidence.MartingaleTrader = [
    `Martingale confidence: ${L.martingaleConf}/100`,
    `Escalation rate: ${fmtP(L.escalationRate)} of losses`,
    L.avgMultiplier ? `Avg lot multiplier: ${L.avgMultiplier.toFixed(2)}×` : null,
    L.maxMultiplier ? `Max multiplier detected: ${L.maxMultiplier.toFixed(2)}×` : null,
  ].filter(Boolean);

  /* ── B. INSTRUMENT SPECIALISTS ───────────────────────── */
  if (topGroup === 'GOLD' && topPct > 35) {
    scores.GoldSpecialist = clamp(42 + topPct * 0.58);
    evidence.GoldSpecialist = [
      `${topSymRaw}: ${fmtP(topPct)} of all trades`,
      `Symbol group: METALS/GOLD`,
      C.topSym?.count ? `${C.topSym.count} closed trades on this instrument` : null,
    ].filter(Boolean);
  }

  if (topGroup === 'INDEX' && topPct > 35) {
    scores.IndexTrader = clamp(42 + topPct * 0.58);
    evidence.IndexTrader = [
      `${topSymRaw}: ${fmtP(topPct)} of all trades`,
      `Symbol group: INDICES`,
    ].filter(Boolean);
  }

  // Secondary gold/index signal: if group appears in top 3 symbols but isn't dominant
  if (topGroup !== 'GOLD') {
    const symStats = b.concentration.symStats || m.symbolStats || [];
    const goldTradeCount = symStats
      .filter(s => getSymbolGroup(s.symbol || s.sym || '') === 'GOLD')
      .reduce((sum, s) => sum + (s.count || 0), 0);
    const goldShare = m.totalTrades ? goldTradeCount / m.totalTrades * 100 : 0;
    if (goldShare > 30 && goldShare <= 55) scores.GoldSpecialist = Math.max(scores.GoldSpecialist, clamp(25 + goldShare));
  }

  /* ── C. TIME-BASED TYPES (primary signal: avgHoldMs) ─── */
  const MS_5MIN  =    300_000;   //  5 minutes
  const MS_15MIN =    900_000;   // 15 minutes
  const MS_4H    =  14_400_000;  //  4 hours
  const MS_10DAY = 864_000_000;  // 10 days

  if (hold !== null && hold > 0) {
    if (hold < MS_15MIN) {
      scores.Scalper += hold < MS_5MIN ? 58 : 48;
      evidence.Scalper = [`Avg hold time: ${fmtMs(hold)} (< 15min — scalper range)`];
    } else if (hold < MS_4H) {
      scores.IntradayTrader += 50;
      evidence.IntradayTrader = [`Avg hold time: ${fmtMs(hold)} (intraday range)`];
    } else if (hold < MS_10DAY) {
      scores.SwingTrader += 52;
      evidence.SwingTrader = [`Avg hold time: ${fmtMs(hold)} (multi-day swing range)`];
    } else {
      scores.PositionTrader += 56;
      evidence.PositionTrader = [`Avg hold time: ${fmtMs(hold)} (long-term position range)`];
    }
  } else {
    // No timestamp data — fall back to frequency as primary signal
    if (tpd > 10)      { scores.Scalper       += 35; evidence.Scalper       = [`High frequency: ${tpd.toFixed(1)} trades/day (no hold time data)`]; }
    else if (tpd > 3)  { scores.IntradayTrader += 30; evidence.IntradayTrader = [`Moderate frequency: ${tpd.toFixed(1)} trades/day`]; }
    else if (tpd < 0.5){ scores.SwingTrader    += 30; evidence.SwingTrader   = [`Low frequency: ${tpd.toFixed(1)} trades/day`]; }
  }

  /* ── D. FREQUENCY ADJUSTMENTS (supporting signals) ──── */
  // These add to the time-based score but cannot independently win
  if      (tpd > 14) { scores.Scalper       += 28; }
  else if (tpd > 8)  { scores.Scalper       += 20; }
  else if (tpd > 4)  { scores.Scalper       +=  8; scores.IntradayTrader += 15; }
  else if (tpd >= 1) { scores.IntradayTrader += 20; scores.SwingTrader   +=  8; }
  else if (tpd < 0.5){ scores.SwingTrader   += 18; scores.PositionTrader += 22; }

  // Position-specific: weekly frequency
  if (tpw < 3)  scores.PositionTrader += 15;
  if (tpd < 0.3) scores.PositionTrader += 12;

  /* ── E. NEWS TRADER (hour-clustering proxy) ──────────── */
  // Standard high-impact news UTC windows: 08–09, 12–14 (NFP, CPI, FOMC, ECB)
  const newsPeakHours = [8, 9, 12, 13, 14];
  const total = m.totalTrades || 1;
  const newsTrades = newsPeakHours.reduce((sum, h) => sum + (hDist[h]?.count || 0), 0);
  const newsConc   = newsTrades / total * 100;
  // News trader: concentrates at release windows AND exits quickly
  if (newsConc > 38 && hold && hold < 7_200_000) {  // < 2h
    scores.NewsTrader = clamp(newsConc * 1.15, 0, 62);
    evidence.NewsTrader = [
      `${fmtP(newsConc)} of entries during news-peak UTC hours (08,09,12,13,14)`,
      `Avg hold: ${fmtMs(hold)} — consistent with event-driven exits`,
    ];
  }

  /* ── F. HYBRID fallback ──────────────────────────────── */
  // Evaluate after all types are scored
  const nonHybrid   = Object.entries(scores).filter(([k]) => k !== 'HybridTrader');
  const sortedNH    = nonHybrid.sort(([,a],[,b_]) => b_ - a);
  const [topKey, topScore] = sortedNH[0] || ['', 0];
  const [,  secondScore]   = sortedNH[1] || ['', 0];

  if (topScore < 38) {
    // No type is clearly dominant
    scores.HybridTrader = 65;
    evidence.HybridTrader = [
      'No single dominant trading style detected',
      `Closest match: ${topKey} (score: ${topScore.toFixed(0)})`,
      `Second match: ${sortedNH[1]?.[0]} (score: ${secondScore.toFixed(0)})`,
    ].filter(Boolean);
  } else if (secondScore > 0 && topScore - secondScore < 12 && topScore < 62) {
    // Two types are very close — hybrid label may be appropriate
    scores.HybridTrader = Math.max(scores.HybridTrader, 42);
    evidence.HybridTrader = [
      `Mixed style: ${topKey} and ${sortedNH[1]?.[0]} are similarly active`,
      `Score delta: ${(topScore - secondScore).toFixed(0)} pts — below clear-dominance threshold`,
    ];
  }

  return { scores, evidence };
}

/**
 * Select primary type and build the composite label.
 * Applies modifier prefixes (Gold, Index, Martingale, High-Frequency).
 */
function classifyTraderType(typeScoreResult, b, m) {
  const { scores, evidence } = typeScoreResult;
  const L   = b.lotEscalation;
  const C   = b.concentration;
  const tpd = b.overtrading.avgPerTradingDay;
  const topSymRaw  = (C.topSym?.symbol || C.topSym?.sym || '').toUpperCase().replace(/[mM]+$/, '');
  const topPct     = C.topPct || 0;
  const topGroup   = getSymbolGroup(topSymRaw);

  // ── MARTINGALE OVERRIDE ──────────────────────────────
  if (L.martingaleConf > 65 && scores.MartingaleTrader >= 63) {
    // May still carry a time-based sub-label (e.g., "Martingale Scalper")
    const timeTypes = ['Scalper','IntradayTrader','SwingTrader','PositionTrader'];
    const bestTime  = timeTypes.map(k => [k, scores[k]]).sort(([,a],[,b_]) => b_ - a)[0];
    const hasTimeSub = bestTime[1] > 28;

    const TYPE_NAMES = { Scalper:'Scalper', IntradayTrader:'Intraday Trader', SwingTrader:'Swing Trader', PositionTrader:'Position Trader' };
    const typeLbl = hasTimeSub ? `Martingale ${TYPE_NAMES[bestTime[0]]}` : 'Martingale Trader';

    return {
      primary:    'MartingaleTrader',
      typeLabel:  typeLbl,
      modifier:   'Martingale',
      freqTag:    null,
      subType:    hasTimeSub ? bestTime[0] : null,
      confidence: clamp(scores.MartingaleTrader + (hasTimeSub ? 4 : 0)),
      scores,
      evidence:   evidence.MartingaleTrader || [],
    };
  }

  // ── RANK ALL TYPES ────────────────────────────────────
  const sorted = Object.entries(scores)
    .filter(([k]) => k !== 'HybridTrader')
    .sort(([,a],[,b_]) => b_ - a);

  const [primaryKey, primaryScore] = sorted[0] || ['HybridTrader', 60];
  const [secondKey,  secondScore]  = sorted[1] || ['', 0];

  const TYPE_LABEL_MAP = {
    Scalper:          'Scalper',
    IntradayTrader:   'Intraday Trader',
    SwingTrader:      'Swing Trader',
    PositionTrader:   'Position Trader',
    NewsTrader:       'News Trader',
    GoldSpecialist:   'Gold Specialist',
    IndexTrader:      'Index Trader',
    MartingaleTrader: 'Martingale Trader',
    HybridTrader:     'Hybrid Trader',
  };

  let modifier  = '';
  let freqTag   = '';

  // Instrument modifier (only when the primary type is time-based, not specialist)
  const isTimeBased = ['Scalper','IntradayTrader','SwingTrader','PositionTrader','HybridTrader','NewsTrader'].includes(primaryKey);
  if (isTimeBased) {
    if (topGroup === 'GOLD' && topPct > 45) modifier = 'Gold';
    else if (topGroup === 'INDEX' && topPct > 45) modifier = 'Index';
    else if (topGroup === 'SILVER' && topPct > 45) modifier = 'Silver';
    else if (topGroup === 'CRYPTO' && topPct > 45) modifier = 'Crypto';
    else if (topGroup === 'OIL' && topPct > 45) modifier = 'Oil';
  }

  // Martingale prefix (weaker signal, conf 40-65)
  if (L.martingaleConf >= 42 && L.martingaleConf <= 65 && primaryKey !== 'MartingaleTrader') {
    modifier = modifier ? `Martingale ${modifier}` : 'Martingale';
  }

  // Frequency sub-tag
  if ((primaryKey === 'Scalper' || primaryKey === 'IntradayTrader') && tpd > 12) {
    freqTag = 'High-Frequency';
  }

  const baseName = TYPE_LABEL_MAP[primaryKey] || primaryKey;
  const typeParts = [freqTag, modifier, baseName].filter(Boolean);
  const typeLabel = typeParts.join(' ');

  // Confidence: lower if two types are very close
  const closeness = primaryScore - secondScore;
  const confPenalty = closeness < 10 ? 14 : closeness < 20 ? 7 : 0;

  return {
    primary:    primaryKey,
    typeLabel,
    modifier:   modifier || null,
    freqTag:    freqTag  || null,
    subType:    secondScore > 30 ? secondKey : null,
    confidence: clamp(primaryScore - confPenalty, 22, 95),
    scores,
    evidence:   evidence[primaryKey] || evidence[scores.HybridTrader > 50 ? 'HybridTrader' : primaryKey] || [],
  };
}

/* ═══════════════════════════════════════════════════════════
   DIMENSION 2 — RISK PROFILE
   Four levels scored independently from risk metrics.
   Override: Martingale type → forces Extreme Risk.
═══════════════════════════════════════════════════════════ */

function scoreRiskProfiles(m, b, r) {
  const L    = b.lotEscalation;
  const O    = b.overtrading;
  const dd   = m.maxRelDD;
  const escR = L.escalationRate;
  const cv   = L.lotCV;
  const pf   = m.profitFactor;
  const crit = r.criticalCount || 0;
  const mc   = L.martingaleConf;

  const scores = { Conservative: 0, Balanced: 0, Aggressive: 0, ExtremeRisk: 0 };

  /* ── EXTREME RISK ─ any strong signal can dominate ─────── */
  if (mc > 65)    scores.ExtremeRisk += 52;
  if (dd > 30)    scores.ExtremeRisk += 45;
  if (escR > 55)  scores.ExtremeRisk += 40;
  if (crit >= 2)  scores.ExtremeRisk += 30;

  /* ── AGGRESSIVE ─────────────────────────────────────────── */
  if (dd > 18 && dd <= 30)        scores.Aggressive += 42;
  if (escR > 30 && escR <= 55)    scores.Aggressive += 30;
  if (O.frequencyScore > 60)      scores.Aggressive += 20;
  if (cv > 0.4)                   scores.Aggressive += 16;
  if (mc > 35 && mc <= 65)        scores.Aggressive += 22;
  if (crit === 1)                 scores.Aggressive += 10;

  /* ── BALANCED ────────────────────────────────────────────── */
  if (dd > 8 && dd <= 18)              scores.Balanced += 42;
  if (escR > 10 && escR <= 30)         scores.Balanced += 26;
  if (pf >= 1.0 && pf < 1.5)          scores.Balanced += 20;
  if (O.frequencyScore >= 25 && O.frequencyScore <= 58) scores.Balanced += 18;
  if (cv >= 0.2 && cv <= 0.4)          scores.Balanced += 14;

  /* ── CONSERVATIVE ────────────────────────────────────────── */
  if (dd < 8)                          scores.Conservative += 44;
  if (escR < 10)                       scores.Conservative += 26;
  if (cv < 0.2)                        scores.Conservative += 22;
  if (pf > 1.5 && pf < Infinity)       scores.Conservative += 16;
  if (O.frequencyScore < 25)           scores.Conservative += 10;
  if (crit === 0 && r.highCount < 2)   scores.Conservative += 10;

  const evidence = {
    Conservative: [
      dd < 8  ? `Controlled drawdown: ${fmtP(dd)}` : null,
      escR < 10 ? `Negligible escalation: ${fmtP(escR)}` : null,
      cv < 0.2 ? `Consistent sizing: CV ${fmtP(cv*100)}` : null,
      pf > 1.5 ? `Solid profit factor: ${fmtPF(pf)}` : null,
    ].filter(Boolean),
    Balanced: [
      dd > 8 ? `Moderate drawdown: ${fmtP(dd)}` : null,
      `Escalation: ${fmtP(escR)} of losses`,
      `Profit factor: ${fmtPF(pf)}`,
    ].filter(Boolean),
    Aggressive: [
      dd > 18 ? `Elevated drawdown: ${fmtP(dd)}` : null,
      escR > 30 ? `Significant escalation: ${fmtP(escR)} of losses` : null,
      O.frequencyScore > 60 ? `High frequency score: ${O.frequencyScore}/100` : null,
    ].filter(Boolean),
    ExtremeRisk: [
      mc > 65 ? `Martingale confidence: ${mc}/100` : null,
      dd > 30 ? `Extreme drawdown: ${fmtP(dd)}` : null,
      escR > 55 ? `Severe escalation: ${fmtP(escR)} of losses` : null,
      crit >= 2 ? `${crit} critical diagnostic rules triggered` : null,
    ].filter(Boolean),
  };

  return { scores, evidence };
}

function classifyRiskProfile(riskScoreResult, b, r) {
  const { scores, evidence } = riskScoreResult;
  const L = b.lotEscalation;

  // Override: any confirmed martingale → Extreme Risk
  if (L.martingaleConf > 65) {
    return {
      primary: 'ExtremeRisk', label: 'Extreme Risk',
      confidence: clamp(L.martingaleConf + 4, 72, 97),
      scores, evidence: evidence.ExtremeRisk || [],
      forceReason: 'MARTINGALE_RISK_OVERRIDE',
    };
  }

  const sorted = Object.entries(scores).sort(([,a],[,b_]) => b_ - a);
  const [pk, ps] = sorted[0] || ['Balanced', 50];
  const [, ss]   = sorted[1] || ['', 0];

  const LABELS = { Conservative:'Conservative', Balanced:'Balanced', Aggressive:'Aggressive', ExtremeRisk:'Extreme Risk' };
  return {
    primary: pk, label: LABELS[pk] || pk,
    confidence: clamp(ps - (ps - ss < 14 ? 8 : 0), 25, 95),
    scores, evidence: evidence[pk] || [],
    forceReason: null,
  };
}

/* ═══════════════════════════════════════════════════════════
   DIMENSION 3 — BEHAVIOUR PROFILE
   Six profiles; Martingale and Revenge have override priority.
═══════════════════════════════════════════════════════════ */

function scoreBehaviourProfiles(m, b, r) {
  const L   = b.lotEscalation;
  const H   = b.holdingBehaviour;
  const O   = b.overtrading;
  const R   = b.recoveryBehaviour;
  const trig = r.triggeredCount || 0;
  const uniqueTD = O.uniqueTradingDays || O.uniqueTD || 1;

  const scores = {
    DisciplinedTrader:   0,
    Overtrader:          0,
    RevengeTrader:       0,
    FOTOTrader:          0,
    MartingaleBehaviour: 0,
    InconsistentTrader:  0,
  };

  /* ── MARTINGALE BEHAVIOUR (override) ──────────────────── */
  if (L.martingaleConf > 65) {
    scores.MartingaleBehaviour = clamp(62 + (L.martingaleConf - 65) * 0.52);
  } else if (L.martingaleConf > 40) {
    scores.MartingaleBehaviour = clamp(L.martingaleConf * 0.64);
  }

  /* ── REVENGE TRADER ──────────────────────────────────── */
  if (R.revengeDetected)                scores.RevengeTrader += 58;
  if (R.immediateReentryRate > 30)      scores.RevengeTrader += 24;
  else if (R.immediateReentryRate > 15) scores.RevengeTrader += 12;
  const plDelta = R.postLossWinRate != null ? R.postLossWinRate - R.baselineWinRate : 0;
  if (plDelta < -20)      scores.RevengeTrader += 14;
  else if (plDelta < -10) scores.RevengeTrader +=  7;

  /* ── OVERTRADER ──────────────────────────────────────── */
  if      (O.frequencyScore > 70) scores.Overtrader += 52;
  else if (O.frequencyScore > 55) scores.Overtrader += 32;
  else if (O.frequencyScore > 40) scores.Overtrader += 16;
  if (O.avgPerTradingDay > 12)    scores.Overtrader += 26;
  else if (O.avgPerTradingDay > 7) scores.Overtrader += 15;
  const otRate = (O.overtradingDays || 0) / uniqueTD;
  if (otRate > 0.30)  scores.Overtrader += 20;
  else if (otRate > 0.15) scores.Overtrader += 10;

  /* ── FOMO TRADER ─────────────────────────────────────── */
  // FOMO: chases moves (same-symbol re-entry), high frequency after market moves,
  // cuts winners early (afraid of reversal), not necessarily revenge
  if (!R.revengeDetected && R.immediateReentryRate > 18) scores.FOTOTrader += 28;
  if (R.sameSymbolRate > 60) scores.FOTOTrader += 26;
  else if (R.sameSymbolRate > 40) scores.FOTOTrader += 12;
  if (H.cutsWinnersShort) scores.FOTOTrader += 20;   // exits winners before TP (fear reversal)
  if (O.frequencyScore > 45) scores.FOTOTrader += 14;
  // High same-symbol AND cuts winners = classic FOMO signature
  if (R.sameSymbolRate > 55 && H.cutsWinnersShort) scores.FOTOTrader += 12;

  /* ── INCONSISTENT TRADER ────────────────────────────── */
  if      (L.lotCV > 0.55) scores.InconsistentTrader += 48;
  else if (L.lotCV > 0.40) scores.InconsistentTrader += 28;
  else if (L.lotCV > 0.30) scores.InconsistentTrader += 14;
  if (H.tpHitRate !== null && H.tpHitRate < 22) scores.InconsistentTrader += 16;
  // Mixed signals = inconsistency
  if (O.frequencyScore > 40 && R.revengeDetected) scores.InconsistentTrader += 12;

  /* ── DISCIPLINED TRADER (requires ALL positive signals) ─ */
  {
    let disc = 0;
    if (!R.revengeDetected)        disc += 22;
    if (L.lotCV < 0.22)           disc += 20;
    if (L.escalationRate < 12)    disc += 20;
    if (O.frequencyScore < 32)    disc += 20;
    if (trig < 4)                 disc += 18;
    scores.DisciplinedTrader = disc;
  }

  const evidence = {
    DisciplinedTrader: [
      !R.revengeDetected ? 'No revenge trading pattern detected' : null,
      L.lotCV < 0.22 ? `Consistent position sizing: CV ${fmtP(L.lotCV*100)}` : null,
      L.escalationRate < 12 ? `Low escalation rate: ${fmtP(L.escalationRate)} of losses` : null,
      trig < 4 ? `Only ${trig} diagnostic rules triggered` : null,
    ].filter(Boolean),
    Overtrader: [
      `Frequency score: ${O.frequencyScore}/100`,
      `${O.avgPerTradingDay.toFixed(1)} trades per trading day`,
      (O.overtradingDays || 0) > 0 ? `${O.overtradingDays} overtrading days detected` : null,
    ].filter(Boolean),
    RevengeTrader: [
      R.revengeDetected ? 'Revenge pattern confirmed by engine' : null,
      `Immediate re-entry rate: ${fmtP(R.immediateReentryRate)} of losses`,
      R.postLossWinRate != null ? `Post-loss win rate: ${fmtP(R.postLossWinRate)} vs ${fmtP(R.baselineWinRate)} baseline` : null,
    ].filter(Boolean),
    FOTOTrader: [
      `Same-symbol re-entry: ${fmtP(R.sameSymbolRate)} of post-loss entries`,
      H.cutsWinnersShort ? 'Cuts winners short — consistent with fear-driven exits' : null,
      `Immediate re-entry: ${fmtP(R.immediateReentryRate)} of losses`,
    ].filter(Boolean),
    MartingaleBehaviour: [
      `Martingale confidence: ${L.martingaleConf}/100`,
      `Escalation rate: ${fmtP(L.escalationRate)} of losses`,
      L.avgMultiplier ? `Avg lot multiplier: ${L.avgMultiplier.toFixed(2)}×` : null,
    ].filter(Boolean),
    InconsistentTrader: [
      `Lot size CV: ${fmtP(L.lotCV*100)} — inconsistent sizing`,
      H.tpHitRate != null ? `TP hit rate: ${fmtP(H.tpHitRate)} — unpredictable exit behavior` : null,
    ].filter(Boolean),
  };

  return { scores, evidence };
}

function classifyBehaviourProfile(behScoreResult, b) {
  const { scores, evidence } = behScoreResult;
  const L = b.lotEscalation;

  // Martingale override
  if (L.martingaleConf > 65 && scores.MartingaleBehaviour >= 60) {
    return {
      primary: 'MartingaleBehaviour', label: 'Martingale Behaviour',
      secondary: null,
      confidence: clamp(scores.MartingaleBehaviour + 5, 66, 96),
      scores, evidence: evidence.MartingaleBehaviour || [],
    };
  }

  const sorted = Object.entries(scores).sort(([,a],[,b_]) => b_ - a);
  const [pk, ps] = sorted[0] || ['InconsistentTrader', 30];
  const [sk, ss] = sorted[1] || ['', 0];

  const LABELS = {
    DisciplinedTrader:   'Disciplined Trader',
    Overtrader:          'Overtrader',
    RevengeTrader:       'Revenge Trader',
    FOTOTrader:          'FOMO Trader',
    MartingaleBehaviour: 'Martingale Behaviour',
    InconsistentTrader:  'Inconsistent Trader',
  };

  // Show secondary if it scores > 28 and within 24 pts of primary
  const showSecondary = ss > 28 && ps - ss < 24;

  return {
    primary: pk, label: LABELS[pk] || pk,
    secondary: showSecondary ? { key: sk, label: LABELS[sk] || sk } : null,
    confidence: clamp(ps - (ps - ss < 14 ? 8 : 0), 18, 95),
    scores, evidence: evidence[pk] || [],
  };
}

/* ═══════════════════════════════════════════════════════════
   DIMENSION 4 — ACCOUNT GRADE
   Based on rules engine diagScore with override caps.
═══════════════════════════════════════════════════════════ */

function classifyGrade(r, b, m) {
  const diagScore = r.diagScore;
  const L    = b.lotEscalation;
  const crit = r.criticalCount || 0;

  // Base grade
  let baseGrade;
  if (diagScore >= 90)      baseGrade = 'A+';
  else if (diagScore >= 78) baseGrade = 'A';
  else if (diagScore >= 62) baseGrade = 'B';
  else if (diagScore >= 45) baseGrade = 'C';
  else if (diagScore >= 25) baseGrade = 'D';
  else                      baseGrade = 'F';

  // Sub-grade: upper half of each band earns "+"
  const BANDS = { A:[78,89], B:[62,77], C:[45,61], D:[25,44] };
  let grade = baseGrade;
  if (BANDS[baseGrade]) {
    const [lo, hi] = BANDS[baseGrade];
    if (diagScore >= (lo + hi) / 2) grade = baseGrade + '+';
  }

  let capApplied = null, capReason = null;

  // Cap 1: Martingale confidence forces max grade C
  if (L.martingaleConf > 65 && !['C','C+','D','D+','F'].includes(grade)) {
    grade = 'C';
    capApplied = 'martingale_cap';
    capReason  = 'Martingale pattern detected — maximum grade capped at C regardless of score';
  }

  // Cap 2: 3+ critical rules forces max grade D
  if (crit >= 3 && !['D','D+','F'].includes(grade)) {
    grade = 'D';
    capApplied = capApplied || 'critical_rules_cap';
    capReason  = capReason  || `${crit} critical rules triggered — grade capped at D`;
  }

  // Cap 3: Net negative account limits to C
  if (m.netProfit < 0 && !['C','C+','D','D+','F'].includes(grade)) {
    grade = 'C';
    capApplied = capApplied || 'net_negative_cap';
    capReason  = capReason  || 'Net negative account — grade capped at C';
  }

  const GRADE_LABELS = {
    'A+':'Institutional','A+':'Institutional','A':'Professional','A-':'Professional',
    'B+':'Competent','B':'Competent','C+':'Below Average','C':'Below Average',
    'D+':'Poor','D':'Poor','F':'Critical',
  };

  return {
    grade, diagScore,
    gradeLabel:  GRADE_LABELS[grade] || 'Assessed',
    baseGrade,   capApplied, capReason,
    confidence:  clamp(88 - r.mediumCount * 3 - r.lowCount, 50, 96),
  };
}

/* ═══════════════════════════════════════════════════════════
   CONFIDENCE SCORING
═══════════════════════════════════════════════════════════ */

function computeOverallConfidence(m, typeConf, riskConf, behConf, gradeConf) {
  // Data sufficiency: 10→0.4, 30→0.65, 60→0.85, 100+→1.0
  const raw  = m.totalTrades;
  const suff = raw <= 10 ? 0.4 : raw <= 30 ? 0.4 + (raw - 10) * 0.0125 : raw <= 60 ? 0.65 + (raw - 30) * 0.0067 : Math.min(0.85 + (raw - 60) * 0.0015, 1.0);

  // Weighted average of dimension confidences
  const dimAvg = typeConf * 0.30 + riskConf * 0.25 + behConf * 0.25 + gradeConf * 0.20;

  return clamp(Math.round(dimAvg * suff), 18, 96);
}

/* ═══════════════════════════════════════════════════════════
   FAILURE PROBABILITY
═══════════════════════════════════════════════════════════ */

function _idComputeFailureProb(grade, riskPrimary, behPrimary) {
  const BASE = {
    'A+':{ p30:2, p90:5, p180:10 }, 'A':{ p30:3, p90:8, p180:14 },
    'A-':{ p30:4, p90:9, p180:17 }, 'B+':{ p30:5, p90:12, p180:22 },
    'B': { p30:7, p90:16, p180:28 }, 'C+':{ p30:13, p90:28, p180:46 },
    'C': { p30:18, p90:38, p180:57 }, 'D+':{ p30:27, p90:51, p180:71 },
    'D': { p30:33, p90:59, p180:79 }, 'F': { p30:55, p90:80, p180:95 },
  };
  const base = BASE[grade] || BASE['C'];

  const RISK_MULT = { Conservative:0.5, Balanced:0.82, Aggressive:1.38, ExtremeRisk:2.1 };
  const BEH_ADD   = { MartingaleBehaviour:16, RevengeTrader:9, Overtrader:5, FOTOTrader:5, InconsistentTrader:3, DisciplinedTrader:-5 };
  const MODES     = { MartingaleBehaviour:'Escalation Collapse', RevengeTrader:'Behavioural Spiral',
                      Overtrader:'Cost Erosion & Overexposure', FOTOTrader:'Chasing Extended Moves',
                      InconsistentTrader:'Variance-Driven Depletion', DisciplinedTrader:'Market Regime Change' };

  const mult = RISK_MULT[riskPrimary] || 1.0;
  const add  = BEH_ADD[behPrimary]    || 0;

  return {
    p30:  clamp(Math.round(base.p30 * mult + add), 1, 98),
    p90:  clamp(Math.round(base.p90 * mult + add), 1, 98),
    p180: clamp(Math.round(base.p180 * mult + add), 1, 98),
    dominantMode: MODES[behPrimary] || 'Gradual Depletion',
  };
}

/* ═══════════════════════════════════════════════════════════
   NARRATIVE FIELDS
═══════════════════════════════════════════════════════════ */

function findMainStrength(m, s, b, r) {
  const candidates = [];
  const S = s.sessions || {};

  // Best session with good PF
  if (s.bestKey && S[s.bestKey]?.count >= 10) {
    const best = S[s.bestKey];
    candidates.push({ score: clamp(best.profitFactor * 10, 0, 80), text: `Strong ${s.bestKey} session (PF ${fmtPF(best.profitFactor)}, ${fmtP(best.winRate)} win rate on ${best.count} trades)` });
  }

  // High profit factor overall
  if (m.profitFactor >= 1.5 && m.profitFactor < Infinity) {
    candidates.push({ score: m.profitFactor * 12, text: `Robust overall profit factor of ${fmtPF(m.profitFactor)}` });
  }

  // Low drawdown
  if (m.maxRelDD < 8) {
    candidates.push({ score: 40, text: `Excellent drawdown control: ${fmtP(m.maxRelDD)} max drawdown` });
  }

  // Consistent lot sizing
  if (b.lotEscalation.lotCV < 0.15) {
    candidates.push({ score: 30, text: `Highly consistent position sizing (lot CV: ${fmtP(b.lotEscalation.lotCV * 100)})` });
  }

  // Win streak
  if (m.maxWinStreak >= 7) {
    candidates.push({ score: m.maxWinStreak * 3, text: `${m.maxWinStreak}-trade winning streak — evidence of periods of strong edge` });
  }

  // Clean rules
  if (r.triggeredCount === 0) {
    candidates.push({ score: 75, text: 'No diagnostic rules triggered — clean risk profile across all categories' });
  }

  // Positive net profit with controlled drawdown
  if (m.netProfit > 0 && m.maxRelDD < 15) {
    candidates.push({ score: 38, text: `Profitable with acceptable drawdown: ${fmtP(m.maxRelDD)} max DD on positive-return period` });
  }

  if (!candidates.length) return 'Insufficient data for a clear strength signal in this statement period';
  return candidates.sort((a, b_) => b_.score - a.score)[0].text;
}

function findMainWeakness(b, r) {
  if (!r.triggered.length) return 'No significant weaknesses detected in this statement period';
  const top = [...r.triggered].sort((a, b_) => b_.priorityScore - a.priorityScore)[0];
  return `${top.name}: ${top.triggerValue}`;
}

function findFailureDriver(r) {
  if (!r.triggered.length) return 'No dominant failure driver identified — account is diagnostically clean';

  // CRITICAL rules override category count
  if (r.critical.length > 0) {
    const cat = r.critical[0].category;
    const desc = { RISK:'structural capital risk (unfavourable trade economics)', BEHAVIOUR:'behavioural patterns undermining performance', SESSION:'session-specific trading destroying profitability', RECOVERY:'post-loss reactions amplifying losses', CONCENTRATION:'single-instrument over-reliance' };
    return `${r.critical[0].name} — ${desc[cat] || cat}`;
  }

  // Category count
  const catCount = {};
  r.triggered.forEach(rule => { catCount[rule.category] = (catCount[rule.category] || 0) + 1; });
  const [domCat] = Object.entries(catCount).sort(([,a],[,b_]) => b_ - a)[0];
  const catDesc  = { RISK:'Structural capital risk and negative trade economics', BEHAVIOUR:'Behavioural patterns actively undermining system performance', SESSION:'Session-specific performance drag', RECOVERY:'Post-loss behavioural reactions compounding losses', CONCENTRATION:'Over-reliance on a single instrument creating fragility' };
  return catDesc[domCat] || domCat;
}

function findRecommendedFocus(r) {
  if (!r.triggered.length) return 'Maintain current discipline — monitor for behavioural drift as account scales and market conditions evolve';
  const top = [...r.triggered].sort((a, b_) => b_.priorityScore - a.priorityScore)[0];
  return top.recommendation.split('.')[0] + '.';
}

/* ═══════════════════════════════════════════════════════════
   WARNINGS
═══════════════════════════════════════════════════════════ */

function buildWarnings(m, b, r, gradeResult) {
  const warnings = [];
  const L = b.lotEscalation;

  if (L.martingaleConf > 65) {
    warnings.push({ severity:'CRITICAL', code:'MARTINGALE_CONFIRMED',
      message: `Martingale pattern confirmed with ${L.martingaleConf}% confidence. The current win rate conceals exponentially growing depletion risk. A long enough losing sequence — which occurs with mathematical certainty — will collapse the account.` });
  }
  if (b.recoveryBehaviour.revengeDetected) {
    const delta = ((b.recoveryBehaviour.postLossWinRate || 0) - (b.recoveryBehaviour.baselineWinRate || 0)).toFixed(1);
    warnings.push({ severity:'HIGH', code:'REVENGE_PATTERN',
      message: `Revenge trading confirmed. Post-loss win rate is ${fmtP(b.recoveryBehaviour.postLossWinRate)} — ${Math.abs(+delta)}pp below the ${fmtP(b.recoveryBehaviour.baselineWinRate)} baseline. Emotional re-entry is turning individual losses into extended losing sequences.` });
  }
  if (m.maxRelDD > 30) {
    const recovery = ((1 / (1 - m.maxRelDD / 100) - 1) * 100).toFixed(0);
    warnings.push({ severity:'CRITICAL', code:'EXTREME_DRAWDOWN',
      message: `Max drawdown of ${fmtP(m.maxRelDD)} requires a ${recovery}% gain from the trough to reach breakeven. Statistical recovery without structural changes to position sizing is unlikely.` });
  }
  if (gradeResult.capApplied) {
    warnings.push({ severity:'HIGH', code:'GRADE_CAP_APPLIED', message: gradeResult.capReason });
  }
  if (m.profitFactor < 1.0 && m.totalTrades >= 10) {
    warnings.push({ severity:'CRITICAL', code:'SYSTEM_UNPROFITABLE',
      message: `System is net unprofitable (PF ${fmtPF(m.profitFactor)}). Every additional trade in the current configuration statistically reduces account balance. Do not add capital until PF exceeds 1.3 over a 50+ trade sample.` });
  }
  if (m.totalTrades < 20) {
    warnings.push({ severity:'LOW', code:'LOW_SAMPLE_SIZE',
      message: `Only ${m.totalTrades} trades available. Identity classifications require a minimum of 30–50 trades for reliable statistical patterns. Current confidence is reduced proportionally.` });
  }

  return warnings;
}

/* ═══════════════════════════════════════════════════════════
   IDENTITY LABEL
═══════════════════════════════════════════════════════════ */

function buildIdentityLabel(typeResult, riskResult, behResult) {
  // Risk prefix adjective for the type label
  const ADJ = { Conservative:'Disciplined', Balanced:'Balanced', Aggressive:'Aggressive', ExtremeRisk:'Extreme-Risk' };
  const riskAdj = ADJ[riskResult.primary] || '';
  const typeLbl = typeResult.typeLabel || 'Trader';

  // Avoid duplication if adjective already appears in type label
  const typePart = typeLbl.toLowerCase().includes(riskAdj.toLowerCase())
    ? typeLbl
    : `${riskAdj} ${typeLbl}`;

  return {
    full:      `${typePart} — ${riskResult.label} — ${behResult.label}`,
    short:     typePart.trim(),
    typePart:  typeLbl,
    riskPart:  riskResult.label,
    behPart:   behResult.label,
  };
}

/* ═══════════════════════════════════════════════════════════
   RECOMMENDED NEXT ACTIONS
═══════════════════════════════════════════════════════════ */

function buildNextActions(r) {
  if (!r.triggered.length) {
    return [{
      priority: 1, ruleRef: 'NONE', severity: 'INFO',
      action: 'Maintain current discipline. Scale position sizes gradually as account equity grows. Monitor for behavioural drift — re-run this analysis after every 50 additional trades.',
    }];
  }
  return [...r.triggered]
    .sort((a, b_) => b_.priorityScore - a.priorityScore)
    .slice(0, 8)
    .map((rule, i) => ({
      priority: i + 1,
      ruleRef:  rule.id,
      severity: rule.severity,
      action:   rule.recommendation,
    }));
}

/* ═══════════════════════════════════════════════════════════
   MAIN: classifyTraderIdentity
═══════════════════════════════════════════════════════════ */

/**
 * Classify a trader's complete identity from all engine outputs.
 *
 * @param {object} m  MetricsResult    — from calculateMetrics() in datalb_metrics_v2.js
 * @param {object} s  SessionAnalytics — from calculateSessions() in datalb_session_engine_v1.js
 * @param {object} b  BehaviourAnalytics — from calculateBehaviour() in datalb_behaviour_engine_v1.js
 * @param {object} r  DiagnosisResult  — from evaluateRules() in datalb_rules_engine_v1.js
 * @returns {TraderIdentity}
 */
function classifyTraderIdentity(m, s, b, r) {

  /* ─ 1. Score each dimension ─────────────────────────── */
  const typeScores = scoreTraderTypes(m, s, b);
  const typeResult = classifyTraderType(typeScores, b, m);

  const riskScores  = scoreRiskProfiles(m, b, r);
  const riskResult  = classifyRiskProfile(riskScores, b, r);

  const behScores   = scoreBehaviourProfiles(m, b, r);
  const behResult   = classifyBehaviourProfile(behScores, b);

  const gradeResult = classifyGrade(r, b, m);

  /* ─ 2. Overall confidence ────────────────────────────── */
  const overallConf = computeOverallConfidence(
    m, typeResult.confidence, riskResult.confidence,
    behResult.confidence, gradeResult.confidence
  );

  /* ─ 3. Failure probability ───────────────────────────── */
  const failureProb = _idComputeFailureProb(
    gradeResult.grade, riskResult.primary, behResult.primary
  );

  /* ─ 4. Narrative ────────────────────────────────────── */
  const mainStrength         = findMainStrength(m, s, b, r);
  const mainWeakness         = findMainWeakness(b, r);
  const primaryFailureDriver = findFailureDriver(r);
  const recommendedFocus     = findRecommendedFocus(r);

  /* ─ 5. Identity label ───────────────────────────────── */
  const label = buildIdentityLabel(typeResult, riskResult, behResult);

  /* ─ 6. Warnings + actions ───────────────────────────── */
  const warnings              = buildWarnings(m, b, r, gradeResult);
  const recommendedNextActions = buildNextActions(r);

  /* ─ 7. Final identity object ────────────────────────── */
  return {

    /* ── Top-level fields (match example in spec) ─────── */
    traderType:           label.short,
    riskProfile:          riskResult.label,
    behaviourProfile:     behResult.label,
    accountGrade:         gradeResult.grade,
    confidence:           overallConf,
    mainWeakness,
    mainStrength,
    primaryFailureDriver,
    recommendedFocus,

    /* ── Dimension details ───────────────────────────── */
    traderTypeDetail: {
      primary:    typeResult.primary,
      typeLabel:  typeResult.typeLabel,
      modifier:   typeResult.modifier,
      freqTag:    typeResult.freqTag,
      subType:    typeResult.subType,
      confidence: typeResult.confidence,
      scores:     typeResult.scores,
      evidence:   typeResult.evidence,
    },
    riskProfileDetail: {
      primary:     riskResult.primary,
      label:       riskResult.label,
      confidence:  riskResult.confidence,
      scores:      riskResult.scores,
      evidence:    riskResult.evidence,
      forceReason: riskResult.forceReason,
    },
    behaviourProfileDetail: {
      primary:    behResult.primary,
      label:      behResult.label,
      secondary:  behResult.secondary,
      confidence: behResult.confidence,
      scores:     behResult.scores,
      evidence:   behResult.evidence,
    },
    gradeDetail: {
      grade:      gradeResult.grade,
      diagScore:  gradeResult.diagScore,
      gradeLabel: gradeResult.gradeLabel,
      capApplied: gradeResult.capApplied,
      capReason:  gradeResult.capReason,
      confidence: gradeResult.confidence,
    },

    /* ── Identity label variants ─────────────────────── */
    identityLabel:      label.full,
    identityLabelShort: label.short,

    /* ── Statistical outputs ─────────────────────────── */
    failureProbability: failureProb,

    /* ── Diagnostic outputs ──────────────────────────── */
    warnings,
    recommendedNextActions,

    /* ── Confidence by dimension ─────────────────────── */
    confidenceScores: {
      overall:          overallConf,
      traderType:       typeResult.confidence,
      riskProfile:      riskResult.confidence,
      behaviourProfile: behResult.confidence,
      accountGrade:     gradeResult.confidence,
      dataCompleteness: Math.round(clamp(m.totalTrades / 100, 0, 1) * 100),
    },

    /* ── Supporting evidence per dimension ───────────── */
    supportingEvidence: {
      traderType:       typeResult.evidence,
      riskProfile:      riskResult.evidence,
      behaviourProfile: behResult.evidence,
      triggeredRules:   r.triggered.map(rule => `${rule.id}: ${rule.name} (${rule.severity})`),
    },

    /* ── Meta ────────────────────────────────────────── */
    totalTrades:    m.totalTrades,
    currency:       m.currency,
    diagScore:      gradeResult.diagScore,
    rulesTriggered: r.triggeredCount,
    criticalRules:  r.criticalCount,
  };
}

/* ═══ brokerIntelligenceEngine.js ═══ */
/* ═══════════════════════════════════════════════════════════
   DataLB Broker Intelligence Engine v1

   Inputs:
     m   — MetricsResult        from datalb_metrics_v2
     s   — SessionAnalytics     from datalb_session_engine_v1
     b   — BehaviourAnalytics   from datalb_behaviour_engine_v1
     r   — DiagnosisResult      from datalb_rules_engine_v1
     id  — TraderIdentity       from datalb_identity_engine_v1

   Output: BrokerIntelligence object
   ─────────────────────────────────────────────────────────
   Routing decision logic:
     A-Book  — hedge trades with external liquidity providers
     B-Book  — internalise trades (broker takes the other side)
     Hybrid  — split: A-book certain trade types / sizes,
               B-book the rest

   Design principle:
     Every factor scores independently 0–100.
     Scores feed two composite indices:
       • riskToBroker      — how dangerous is this account to B-book?
       • expectedToxicFlow — how likely is the flow to be winning?
     These two indices, plus override rules, determine routing.
═══════════════════════════════════════════════════════════ */
/* ─────────────────────────────────────────────────────────
   UTILITIES
───────────────────────────────────────────────────────── */
const clamp  = (v, lo = 0, hi = 100) => Math.max(lo, Math.min(hi, v));
const fmtP   = v => v == null ? '—' : `${Number(v).toFixed(1)}%`;
const fmtPF  = v => v == null ? '—' : v === Infinity ? '∞' : Number(v).toFixed(2);
const fmtC   = v => Math.abs(v ?? 0).toLocaleString('en-US',{ minimumFractionDigits:2, maximumFractionDigits:2 });

/* ─────────────────────────────────────────────────────────
   FACTOR DEFINITIONS
   Each factor returns { score 0-100, label, rationale }
   Score semantics vary by factor:
     Profitability     → higher score = more dangerous to B-book (account earns)
     Martingale        → higher score = safer to B-book (guaranteed to blow up)
     Scalping          → higher score = more toxic (hard to hedge, spread erosion)
     etc.
   The scoring direction is documented per factor.
───────────────────────────────────────────────────────── */

/**
 * Factor 1 — Profitability
 * Higher score = account is genuinely profitable = more dangerous to B-book.
 * Unprofitable accounts are safe to B-book.
 */
function scoreProfitability(m) {
  const pf  = m.profitFactor;
  const np  = m.netProfit;
  const wr  = m.winRate;
  const tot = m.totalTrades;

  if (tot < 10) return { score: 35, label: 'Insufficient Data', rationale: `Only ${tot} trades — cannot reliably determine long-term profitability.` };

  let score = 0;

  // Profit factor is the primary signal
  if      (pf === Infinity)  score += 60;  // no losses at all — very dangerous
  else if (pf >= 2.0)        score += 55;
  else if (pf >= 1.5)        score += 40;
  else if (pf >= 1.2)        score += 28;
  else if (pf >= 1.0)        score += 16;
  else if (pf >= 0.8)        score += 6;
  else                       score += 0;   // deep losses = safe to B-book

  // Net profit confirmation
  if      (np > 0)    score += 20;
  else if (np < 0)    score -= 10;

  // Win rate as supporting signal
  if      (wr >= 70)  score += 14;
  else if (wr >= 58)  score += 8;
  else if (wr < 40)   score -= 4;

  // Sample size penalty: low confidence = pull towards neutral
  if (tot < 30) score = score * 0.7 + 30 * 0.3;

  const s = clamp(Math.round(score));
  const label = s >= 70 ? 'Consistently Profitable'
    : s >= 50 ? 'Marginally Profitable'
    : s >= 32 ? 'Break-Even'
    : 'Net Unprofitable';
  const rationale = `PF ${fmtPF(pf)}, net ${np >= 0 ? '+' : ''}${fmtC(np)} ${m.currency}, win rate ${fmtP(wr)} over ${tot} trades.`;
  return { score: s, label, rationale };
}

/**
 * Factor 2 — Consistency
 * Higher score = account behaviour is stable and predictable = higher long-term B-book risk.
 * Erratic accounts may be self-correcting via blowup.
 */
function scoreConsistency(m, b) {
  const cv    = b.lotEscalation.lotCV;
  const escR  = b.lotEscalation.escalationRate;
  const pf    = m.profitFactor;

  let score = 0;

  // Lot CV: low variation = consistent sizing = predictable flow
  if      (cv < 0.10)  score += 35;
  else if (cv < 0.20)  score += 28;
  else if (cv < 0.35)  score += 18;
  else if (cv < 0.55)  score += 8;
  else                 score += 0;

  // Escalation penalises consistency (erratic)
  if      (escR < 5)   score += 25;
  else if (escR < 15)  score += 16;
  else if (escR < 35)  score += 6;
  else                 score += 0;

  // Profit factor consistency: stable PF indicates repeatable edge
  if (pf >= 1.5 && pf < Infinity) score += 25;
  else if (pf >= 1.0)             score += 15;
  else                            score += 0;

  // Max loss streak: longer streaks = less consistent
  const mls = m.maxLossStreak || 0;
  if      (mls <= 3)  score += 15;
  else if (mls <= 6)  score += 8;
  else                score += 0;

  const s = clamp(Math.round(score));
  const label = s >= 72 ? 'Highly Consistent'
    : s >= 50 ? 'Moderately Consistent'
    : s >= 30 ? 'Inconsistent'
    : 'Highly Erratic';
  const rationale = `Lot CV ${fmtP(cv * 100)}, escalation rate ${fmtP(escR)}, max loss streak ${mls}.`;
  return { score: s, label, rationale };
}

/**
 * Factor 3 — Drawdown
 * Higher score = low drawdown = account is controlled = more dangerous to B-book long-term.
 * High drawdown accounts self-destruct; safe to internalise.
 */
function scoreDrawdown(m) {
  const dd  = m.maxRelDD;
  const rf  = m.recoveryFactor;

  let score = 0;

  // Max relative drawdown (inverted: low DD = high score = dangerous to B-book)
  if      (dd < 5)   score += 52;
  else if (dd < 10)  score += 40;
  else if (dd < 18)  score += 26;
  else if (dd < 28)  score += 14;
  else if (dd < 40)  score += 5;
  else               score += 0;

  // Recovery factor: high RF = efficient recovery = more dangerous
  if      (rf !== null && rf > 3.0)  score += 30;
  else if (rf !== null && rf > 1.5)  score += 20;
  else if (rf !== null && rf > 0.5)  score += 10;

  // Absolute drawdown below starting balance (panic risk)
  if (m.absoluteDD === 0)          score += 18;
  else if (m.absoluteDD > 0)       score -= 8;

  const s = clamp(Math.round(score));
  const label = s >= 70 ? 'Controlled Drawdown'
    : s >= 48 ? 'Moderate Drawdown'
    : s >= 28 ? 'High Drawdown'
    : 'Extreme Drawdown';
  const rationale = `Max drawdown ${fmtP(dd)}, recovery factor ${rf !== null ? rf.toFixed(2) : '—'}.`;
  return { score: s, label, rationale };
}

/**
 * Factor 4 — Martingale Behaviour
 * Higher score = stronger martingale = SAFER for broker to B-book.
 * Martingale accounts are mathematical self-destruct machines.
 * This factor is inverted relative to the others — a high score here
 * INCREASES B-book suitability, not A-book.
 */
function scoreMartingale(b) {
  const mc   = b.lotEscalation.martingaleConf;
  const escR = b.lotEscalation.escalationRate;
  const maxM = b.lotEscalation.maxMultiplier || 0;
  const avgM = b.lotEscalation.avgMultiplier || 0;

  let score = 0;

  if      (mc >= 80)  score += 55;
  else if (mc >= 60)  score += 40;
  else if (mc >= 40)  score += 25;
  else if (mc >= 20)  score += 12;

  if      (escR > 50)  score += 26;
  else if (escR > 30)  score += 16;
  else if (escR > 15)  score += 8;

  if      (maxM > 4)   score += 14;
  else if (maxM > 2.5) score += 9;
  else if (maxM > 1.5) score += 4;

  if (avgM > 1.8)      score += 5;

  const s = clamp(Math.round(score));
  const label = s >= 65 ? 'Confirmed Martingale'
    : s >= 40 ? 'Partial Escalation'
    : s >= 20 ? 'Mild Escalation'
    : 'No Escalation';
  const rationale = `Martingale confidence ${mc}/100, escalation rate ${fmtP(escR)}, max multiplier ${maxM.toFixed(2)}×.`;
  return { score: s, label, rationale };
}

/**
 * Factor 5 — Scalping Behaviour
 * Higher score = more scalper-like = more toxic to broker.
 * Scalpers exploit small spreads at high frequency.
 * A-book is preferred for confirmed scalpers because they win
 * on execution quality and the broker cannot profitably hedge them.
 */
function scoreScalping(m, b, id) {
  const tpd  = b.overtrading.avgPerTradingDay;
  const hold = m.avgHoldMs;
  const pf   = m.profitFactor;
  const type = id?.traderTypeDetail?.primary || '';

  let score = 0;

  // Type classification
  if (type === 'Scalper')        score += 38;
  else if (type === 'IntradayTrader') score += 16;

  // Hold duration
  if      (hold && hold < 300_000)   score += 36;  // < 5 min
  else if (hold && hold < 900_000)   score += 24;  // < 15 min
  else if (hold && hold < 3_600_000) score += 10;  // < 1 hour

  // Trade frequency
  if      (tpd > 20)  score += 20;
  else if (tpd > 10)  score += 14;
  else if (tpd > 5)   score += 7;

  // Profitable scalping = maximum toxicity
  if (pf >= 1.3 && tpd > 8) score += 12;

  const s = clamp(Math.round(score));
  const label = s >= 68 ? 'High-Frequency Scalper'
    : s >= 44 ? 'Active Intraday Trader'
    : s >= 22 ? 'Occasional Short-Term Trader'
    : 'Not a Scalper';
  const hold_fmt = hold ? (hold < 60000 ? `${Math.round(hold/1000)}s` : hold < 3600000 ? `${Math.round(hold/60000)}m` : `${Math.round(hold/3600000)}h`) : '—';
  const rationale = `Avg hold ${hold_fmt}, ${tpd.toFixed(1)} trades/day, classified as ${type || 'unknown'}.`;
  return { score: s, label, rationale };
}

/**
 * Factor 6 — News Trading Behaviour
 * Higher score = stronger news trading = more toxic to broker.
 * News traders exploit momentary dislocations and are notoriously
 * difficult to hedge. Many brokers specifically exclude them from B-book.
 */
function scoreNewsTrading(m, s, id) {
  const hDist = s.hourDistribution || Array.from({length:24}, () => ({ count:0 }));
  const total = m.totalTrades || 1;
  const type  = id?.traderTypeDetail?.primary || '';

  // News peak UTC windows (approximate for major releases)
  const PEAK_HOURS = [8, 9, 12, 13, 14, 15]; // ECB, NFP, CPI, FOMC
  const peakTrades = PEAK_HOURS.reduce((sum, h) => sum + (hDist[h]?.count || 0), 0);
  const peakPct    = peakTrades / total * 100;

  let score = 0;

  // Identity engine classification
  if (type === 'NewsTrader')     score += 42;

  // Entry hour concentration in news windows
  if      (peakPct > 60)  score += 40;
  else if (peakPct > 40)  score += 28;
  else if (peakPct > 25)  score += 14;
  else if (peakPct > 12)  score += 6;

  const hold = m.avgHoldMs;
  // Short hold time at news hours = classic news spike exploitation
  if (hold && peakPct > 30 && hold < 3_600_000) score += 12;

  const sc = clamp(Math.round(score));
  const label = sc >= 60 ? 'Confirmed News Trader'
    : sc >= 35 ? 'Probable News Trader'
    : sc >= 16 ? 'Partial News Exposure'
    : 'No News Trading Signal';
  const rationale = `${fmtP(peakPct)} of entries during peak news UTC hours (08–15). Identity: ${type || 'unclassified'}.`;
  return { score: sc, label, rationale };
}

/**
 * Factor 7 — Concentration Risk
 * Higher score = more concentrated = higher correlated P&L impact on broker.
 * Concentrated accounts move in one direction — if they win, the broker
 * internalising them takes a large directional loss.
 */
function scoreConcentration(b, m) {
  const topPct    = b.concentration.topPct || 0;
  const symCount  = b.concentration.symStats?.length || 1;
  const concScore = b.concentration.concentrationScore || 0;
  const topSym    = (b.concentration.topSym?.sym || b.concentration.topSym?.symbol || '').toUpperCase();

  let score = 0;

  // High single-symbol concentration = directional risk to broker
  if      (topPct > 80)  score += 46;
  else if (topPct > 65)  score += 34;
  else if (topPct > 50)  score += 22;
  else if (topPct > 35)  score += 12;

  // Very few symbols = systematic directional bias
  if      (symCount === 1)  score += 30;
  else if (symCount === 2)  score += 20;
  else if (symCount <= 4)   score += 10;

  // Composite concentration score from behaviour engine
  if (concScore > 80)  score += 20;
  else if (concScore > 60) score += 12;
  else if (concScore > 40) score += 5;

  const s = clamp(Math.round(score));
  const label = s >= 68 ? 'Extreme Concentration'
    : s >= 44 ? 'High Concentration'
    : s >= 24 ? 'Moderate Concentration'
    : 'Well Diversified';
  const rationale = `Top symbol "${topSym || '—'}": ${fmtP(topPct)} of trades. ${symCount} unique instrument(s) traded.`;
  return { score: s, label, rationale };
}

/**
 * Factor 8 — Recovery Behaviour (Post-Loss Patterns)
 * Higher score = trader acts irrationally after losses = self-destructive = safe to B-book.
 * Emotional traders who revenge trade and escalate after losses
 * are statistically likely to give back profits.
 */
function scoreRecoveryBehaviour(b) {
  const R    = b.recoveryBehaviour;
  const immR = R.immediateReentryRate || 0;
  const ssmR = R.sameSymbolRate || 0;
  const plDelta = R.postLossWinRate != null ? R.postLossWinRate - R.baselineWinRate : 0;

  let score = 0;

  // Revenge trading = reliable self-destruction
  if (R.revengeDetected)       score += 42;

  // Immediate re-entry frequency
  if      (immR > 50)  score += 28;
  else if (immR > 30)  score += 18;
  else if (immR > 15)  score += 9;

  // Same-symbol re-entry = compulsive, not analytical
  if      (ssmR > 70)  score += 18;
  else if (ssmR > 50)  score += 11;
  else if (ssmR > 30)  score += 5;

  // Post-loss win rate degradation confirms emotional spiral
  if      (plDelta < -25)  score += 12;
  else if (plDelta < -15)  score += 7;

  const s = clamp(Math.round(score));
  const label = s >= 65 ? 'Severe Post-Loss Behaviour'
    : s >= 40 ? 'Emotional After Losses'
    : s >= 20 ? 'Mild Reaction to Losses'
    : 'Controlled After Losses';
  const rationale = `Immediate re-entry: ${fmtP(immR)}, same-symbol: ${fmtP(ssmR)}, revenge: ${R.revengeDetected ? 'YES' : 'NO'}, post-loss WR delta: ${plDelta.toFixed(1)}pp.`;
  return { score: s, label, rationale };
}

/**
 * Factor 9 — Risk Stability
 * Higher score = stable, low-risk behavior = more dangerous to B-book.
 * Erratic risk-takers eventually blow their account; stable traders persist.
 */
function scoreRiskStability(m, b) {
  const cv   = b.lotEscalation.lotCV;
  const dd   = m.maxRelDD;
  const mls  = m.maxLossStreak || 0;
  const freq = b.overtrading.frequencyScore;

  let score = 0;

  // Low lot variation = disciplined position sizing
  if      (cv < 0.12)  score += 35;
  else if (cv < 0.22)  score += 26;
  else if (cv < 0.38)  score += 14;
  else if (cv < 0.55)  score += 5;

  // Low drawdown = capital preservation mindset
  if      (dd < 6)   score += 30;
  else if (dd < 12)  score += 22;
  else if (dd < 20)  score += 12;
  else if (dd < 30)  score += 4;

  // Controlled loss streak
  if      (mls <= 3)  score += 20;
  else if (mls <= 5)  score += 12;
  else if (mls <= 8)  score += 5;

  // Controlled frequency
  if (freq < 30) score += 15;
  else if (freq < 50) score += 8;

  const s = clamp(Math.round(score));
  const label = s >= 72 ? 'Very Stable Risk Profile'
    : s >= 50 ? 'Moderate Risk Stability'
    : s >= 30 ? 'Variable Risk Profile'
    : 'Unstable / Erratic Risk';
  const rationale = `Lot CV ${fmtP(cv*100)}, max DD ${fmtP(dd)}, max loss streak ${mls}, freq score ${freq}/100.`;
  return { score: s, label, rationale };
}

/* ─────────────────────────────────────────────────────────
   COMPOSITE SCORES
───────────────────────────────────────────────────────── */

/**
 * Risk To Broker Score (0-100)
 * High score = this account is dangerous to B-book.
 * Driven by: profitability, consistency, drawdown control, risk stability.
 * Reduced by: martingale (self-destructs), bad recovery (emotional).
 *
 * Interpretation:
 *   0–30  : Low risk — safe to B-book
 *   31–55 : Moderate risk — hybrid candidate
 *   56–75 : High risk — A-book preferred
 *   76–100: Extreme risk — must A-book
 */
function computeRiskToBroker(factors) {
  const {
    profitability, consistency, drawdown, martingale,
    scalping, newsTrading, concentration, recoveryBehaviour, riskStability
  } = factors;

  // Martingale and emotional recovery are NEGATIVE risk signals for the broker
  // (they reduce danger because account is self-destructing)
  const martingaleReduction   = martingale.score   * 0.65;  // confirmed martingale = lower B-book risk
  const recoveryReduction     = recoveryBehaviour.score * 0.55;  // revenge trading = account will blow

  // Positive risk contributions (account is dangerous to B-book)
  const raw =
    profitability.score  * 0.28 +   // primary: is the account making money?
    consistency.score    * 0.18 +   // secondary: is it reliable?
    drawdown.score       * 0.16 +   // tertiary: does it protect capital?
    riskStability.score  * 0.14 +   // sizing discipline
    scalping.score       * 0.10 +   // scalping toxicity
    newsTrading.score    * 0.08 +   // news trading toxicity
    concentration.score  * 0.06 -   // concentration increases broker directional risk
    martingaleReduction  * 0.10 -   // offsets — self-destructs
    recoveryReduction    * 0.08;    // offsets — will blow up emotionally

  return clamp(Math.round(raw));
}

/**
 * Expected Toxic Flow Score (0-100)
 * High score = flow is likely to be selectively winning
 * (information-asymmetric, spread-erosive, news-exploiting).
 * Toxic flow cannot be profitably hedged or internalised.
 *
 * Interpretation:
 *   0–25  : Benign flow — B-bookable
 *   26–50 : Mildly directional — hybrid
 *   51–70 : Directional / scalping — A-book preferred
 *   71–100: Highly toxic — must A-book
 */
function computeExpectedToxicFlow(factors) {
  const { scalping, newsTrading, concentration, profitability, consistency } = factors;

  // Toxic flow is primarily driven by scalping, news exploitation, and
  // directional concentration by profitable, consistent traders
  const raw =
    scalping.score      * 0.34 +   // fastest path to toxic flow
    newsTrading.score   * 0.28 +   // news traders are classically toxic
    concentration.score * 0.14 +   // concentrated directional risk
    profitability.score * 0.14 +   // profitable accounts = toxic to internalise
    consistency.score   * 0.10;    // consistent accounts = predictably toxic

  return clamp(Math.round(raw));
}

/* ─────────────────────────────────────────────────────────
   ROUTING DECISION ENGINE
───────────────────────────────────────────────────────── */

/**
 * Compute raw A-Book / B-Book / Hybrid probabilities (0-100 each, do not sum to 100).
 * The final recommendation uses these alongside hard override rules.
 */
function computeRoutingProbabilities(rtb, etf, factors, id) {
  const {
    profitability, martingale, scalping, newsTrading, riskStability, recoveryBehaviour
  } = factors;

  const grade   = id?.accountGrade || 'C';
  const gradeN  = { 'A+':100,'A':85,'A-':75,'B+':65,'B':55,'B-':48,'C+':38,'C':28,'D+':16,'D':8,'F':0 }[grade] || 28;

  // ── A-BOOK probability ────────────────────────────────────────
  // Drivers: profitable + consistent + stable + scalping/news + controlled drawdown
  let aBook = 0;
  if (rtb >= 72)                       aBook += 45;  // primary signal: very risky to B-book
  else if (rtb >= 55)                  aBook += 30;
  if (etf >= 65)                       aBook += 35;  // primarily toxic flow
  else if (etf >= 45)                  aBook += 20;
  if (scalping.score >= 60)            aBook += 18;  // scalpers: always A-book if profitable
  if (newsTrading.score >= 55)         aBook += 15;  // news traders: always A-book
  if (profitability.score >= 62)       aBook += 14;
  if (riskStability.score >= 65)       aBook += 10;
  if (gradeN >= 65)                    aBook += 10;  // high-grade accounts: long-term value
  aBook = clamp(aBook);

  // ── B-BOOK probability ────────────────────────────────────────
  // Drivers: unprofitable + martingale + emotional + low RtB
  let bBook = 0;
  if (rtb <= 30)                       bBook += 45;  // low risk to broker
  else if (rtb <= 45)                  bBook += 25;
  if (martingale.score >= 65)          bBook += 40;  // will blow up — pure B-book
  else if (martingale.score >= 40)     bBook += 20;
  if (profitability.score <= 22)       bBook += 25;  // losing account
  else if (profitability.score <= 38)  bBook += 14;
  if (recoveryBehaviour.score >= 65)   bBook += 18;  // revenge traders destroy themselves
  else if (recoveryBehaviour.score >= 40) bBook += 9;
  if (gradeN <= 16)                    bBook += 16;  // D/F grade = self-liquidating
  if (etf <= 22)                       bBook += 10;
  bBook = clamp(bBook);

  // ── HYBRID probability ────────────────────────────────────────
  // Middle ground: large trades A-booked, standard retail B-booked
  const aOrB = Math.max(aBook, bBook);
  let hybrid  = 0;
  if (aOrB < 55)                       hybrid += 40;  // neither clearly dominant
  if (rtb >= 35 && rtb <= 60)          hybrid += 25;  // moderate risk zone
  if (etf >= 25 && etf <= 55)          hybrid += 20;
  if (profitability.score >= 35 && profitability.score <= 62) hybrid += 14;
  // Hybrid is also the safest fallback when data is thin
  hybrid = clamp(hybrid);

  return { aBook, bBook, hybrid };
}

/**
 * Apply override rules that bypass the probabilistic scoring.
 * These are non-negotiable routing decisions.
 */
function applyRoutingOverrides(probs, factors, id, m, b, r) {
  const L    = b.lotEscalation;
  const overrides = [];

  // Override 1: Confirmed martingale with catastrophic confidence → mandatory B-book
  if (L.martingaleConf >= 75) {
    overrides.push({
      code:   'MARTINGALE_BBOOK_MANDATORY',
      rule:   'Martingale confidence ≥ 75% — account will self-destruct',
      effect: 'Force B-Book',
      force:  'B-Book',
    });
  }

  // Override 2: Confirmed news trader + profitable → mandatory A-book
  if (factors.newsTrading.score >= 58 && factors.profitability.score >= 52) {
    overrides.push({
      code:   'NEWS_TRADER_ABOOK_MANDATORY',
      rule:   'Confirmed profitable news trader — execution-toxic flow',
      effect: 'Force A-Book',
      force:  'A-Book',
    });
  }

  // Override 3: High-frequency profitable scalper → mandatory A-book
  if (factors.scalping.score >= 65 && factors.profitability.score >= 55) {
    overrides.push({
      code:   'PROFITABLE_SCALPER_ABOOK',
      rule:   'Profitable high-frequency scalper — spread erosion risk',
      effect: 'Force A-Book',
      force:  'A-Book',
    });
  }

  // Override 4: Grade A+ or A with disciplined profile → A-book qualification
  if (['A+','A'].includes(id?.accountGrade) && (id?.behaviourProfile || '').includes('Disciplined')) {
    overrides.push({
      code:   'INSTITUTIONAL_GRADE_ABOOK',
      rule:   'Grade A+ or A disciplined trader — long-term profitable client',
      effect: 'Qualify for A-Book',
      force:  'A-Book',
    });
  }

  // Override 5: Grade F with extreme drawdown → mandatory B-book
  if (id?.accountGrade === 'F' || m.maxRelDD > 45) {
    overrides.push({
      code:   'CRITICAL_ACCOUNT_BBOOK',
      rule:   `Grade F or extreme drawdown (${m.maxRelDD.toFixed(1)}%) — capital depletion imminent`,
      effect: 'Force B-Book',
      force:  'B-Book',
    });
  }

  // Resolve conflicts: A-Book overrides take precedence over B-Book overrides
  // (regulatory and reputational risk is higher if a winning trader can't get fills)
  const aForce = overrides.find(o => o.force === 'A-Book');
  const bForce = overrides.find(o => o.force === 'B-Book');

  let forced = null;
  if (aForce)      forced = 'A-Book';
  else if (bForce) forced = 'B-Book';

  return { overrides, forced };
}

/**
 * Select the final routing recommendation.
 */
function selectRouting(probs, overrideResult) {
  if (overrideResult.forced) {
    return { recommendation: overrideResult.forced, method: 'override' };
  }

  // Probabilistic: highest of the three wins if clear margin; otherwise Hybrid
  const { aBook, bBook, hybrid } = probs;
  const top = Math.max(aBook, bBook, hybrid);
  const second = [aBook, bBook, hybrid].filter(v => v !== top).reduce((a, b_) => Math.max(a, b_), 0);

  if (top - second >= 18) {
    if (top === aBook) return { recommendation: 'A-Book', method: 'probabilistic' };
    if (top === bBook) return { recommendation: 'B-Book', method: 'probabilistic' };
    return { recommendation: 'Hybrid', method: 'probabilistic' };
  }

  // Tie-break: if aBook and bBook are close, Hybrid is the conservative choice
  return { recommendation: 'Hybrid', method: 'tie-break' };
}

/**
 * Compute routing confidence (0-100).
 * High confidence when one routing option dominates clearly.
 */
function computeRoutingConfidence(probs, overrideResult, m) {
  const { aBook, bBook, hybrid } = probs;
  const scores = [aBook, bBook, hybrid].sort((a, b_) => b_ - a);
  const margin = scores[0] - scores[1];

  let conf = 0;

  // Override = high base confidence
  if (overrideResult.forced) conf += 42;
  else conf += 20;

  // Clear margin between top and second
  if      (margin >= 35)  conf += 32;
  else if (margin >= 22)  conf += 22;
  else if (margin >= 12)  conf += 12;

  // Top option strength
  if      (scores[0] >= 70)  conf += 20;
  else if (scores[0] >= 50)  conf += 12;

  // Data sufficiency
  const tot = m.totalTrades;
  if      (tot >= 100) conf += 10;
  else if (tot >= 50)  conf += 6;
  else if (tot >= 30)  conf += 3;

  // Number of override rules (more overrides = more certain)
  conf += Math.min(overrideResult.overrides.length * 4, 12);

  return clamp(Math.round(conf), 18, 97);
}

/**
 * Build a routing explanation narrative.
 */
function buildRoutingExplanation(recommendation, factors, probs, overrideResult, rtb, etf, id) {
  const { profitability, consistency, drawdown, martingale, scalping, newsTrading, recoveryBehaviour, riskStability } = factors;

  const grade   = id?.accountGrade || '—';
  const type    = id?.traderType   || '—';
  const beh     = id?.behaviourProfile || '—';

  // Section 1: account summary
  const summary = `Account classified as "${type}" — Grade ${grade} — ${beh}. `
    + `Risk To Broker: ${rtb}/100. Expected Toxic Flow: ${etf}/100.`;

  // Section 2: key routing drivers
  const drivers = [];

  if (overrideResult.overrides.length > 0) {
    drivers.push(`OVERRIDE RULES ACTIVE: ${overrideResult.overrides.map(o => o.rule).join('; ')}.`);
  }

  if (recommendation === 'A-Book') {
    if (profitability.score >= 55) drivers.push(`Account is net profitable (${profitability.label}) — internalising this flow creates direct P&L exposure for the broker.`);
    if (scalping.score >= 55) drivers.push(`Scalping behaviour confirmed (${scalping.label}) — high-frequency entries erode spread revenue if B-booked. LP routing is cost-effective.`);
    if (newsTrading.score >= 45) drivers.push(`News trading detected (${newsTrading.label}) — event-driven entries exploit momentary dislocations and cannot be profitably hedged internally.`);
    if (riskStability.score >= 60) drivers.push(`Risk profile is stable and controlled (${riskStability.label}) — account is likely to persist long-term, generating sustainable A-book commission revenue.`);
    if (consistency.score >= 60) drivers.push(`Consistent trading behaviour (${consistency.label}) — predictable flow with demonstrated edge. B-booking this client creates growing directional liability.`);
  } else if (recommendation === 'B-Book') {
    if (martingale.score >= 55) drivers.push(`Martingale pattern confirmed (${martingale.label}) — this account will self-destruct when a sufficient losing sequence occurs. B-book internalises the statistical profit from this event.`);
    if (profitability.score <= 28) drivers.push(`Account is net unprofitable (${profitability.label}) — internalising losing flow generates direct broker revenue.`);
    if (recoveryBehaviour.score >= 55) drivers.push(`Severe post-loss behaviour (${recoveryBehaviour.label}) — emotional decision-making after losses reliably produces additional losing trades. B-book captures this pattern.`);
    if (drawdown.score <= 22) drivers.push(`Extreme drawdown detected (${drawdown.label}) — account is on a capital depletion trajectory. Continued B-booking statistically increases broker revenue.`);
  } else { // Hybrid
    drivers.push(`Neither A-book nor B-book clearly dominates. Split routing recommended:`);
    drivers.push(`A-book: positions above ${(id?.traderTypeDetail?.primary === 'Scalper' ? '0.50' : '1.00')} lots, positions opened during news windows, and trades on instruments with thin LP spreads.`);
    drivers.push(`B-book: standard retail-size positions on liquid instruments during normal market hours.`);
    if (profitability.score >= 35 && profitability.score <= 60) drivers.push(`Profitability is marginal (${profitability.label}) — not yet at institutional concern level, but warrants monitoring.`);
  }

  // Section 3: monitoring instruction
  const monitoring = recommendation === 'A-Book'
    ? 'Review routing every 90 days or after any 50-trade increment. Monitor for deterioration in discipline that would allow reclassification to Hybrid.'
    : recommendation === 'B-Book'
    ? 'Monitor max open exposure per session. Set a B-book internalisation cap of 5× the account equity to avoid concentrated directional risk on a single B-booked client.'
    : 'Re-evaluate split threshold after 100 additional trades. If profitability exceeds PF 1.5 consistently, migrate fully to A-book.';

  return {
    summary,
    drivers,
    monitoring,
    full: [summary, ...drivers, monitoring].join(' '),
  };
}

/* ─────────────────────────────────────────────────────────
   MAIN ENTRY POINT
───────────────────────────────────────────────────────── */

/**
 * Compute broker routing intelligence for a single MT4/MT5 account.
 *
 * @param {object} m    MetricsResult      from calculateMetrics()
 * @param {object} s    SessionAnalytics   from calculateSessions()
 * @param {object} b    BehaviourAnalytics from calculateBehaviour()
 * @param {object} r    DiagnosisResult    from evaluateRules()
 * @param {object} id   TraderIdentity     from classifyTraderIdentity()
 * @returns {BrokerIntelligence}
 */
function computeBrokerIntelligence(m, s, b, r, id) {

  /* ── 1. Score all 9 factors ─────────────────────────────── */
  const factors = {
    profitability:     scoreProfitability(m),
    consistency:       scoreConsistency(m, b),
    drawdown:          scoreDrawdown(m),
    martingale:        scoreMartingale(b),
    scalping:          scoreScalping(m, b, id),
    newsTrading:       scoreNewsTrading(m, s, id),
    concentration:     scoreConcentration(b, m),
    recoveryBehaviour: scoreRecoveryBehaviour(b),
    riskStability:     scoreRiskStability(m, b),
  };

  /* ── 2. Compute composite indices ─────────────────────── */
  const riskToBroker      = computeRiskToBroker(factors);
  const expectedToxicFlow = computeExpectedToxicFlow(factors);

  /* ── 3. Routing probabilities ─────────────────────────── */
  const probabilities = computeRoutingProbabilities(riskToBroker, expectedToxicFlow, factors, id);

  /* ── 4. Override rules ────────────────────────────────── */
  const overrideResult = applyRoutingOverrides(probabilities, factors, id, m, b, r);

  /* ── 5. Final recommendation ─────────────────────────── */
  const routingDecision = selectRouting(probabilities, overrideResult);

  /* ── 6. Confidence ────────────────────────────────────── */
  const routingConfidence = computeRoutingConfidence(probabilities, overrideResult, m);

  /* ── 7. Narrative ─────────────────────────────────────── */
  const explanation = buildRoutingExplanation(
    routingDecision.recommendation, factors, probabilities,
    overrideResult, riskToBroker, expectedToxicFlow, id
  );

  /* ── 8. Risk tier labels ─────────────────────────────── */
  const RISK_TIER = riskToBroker >= 76 ? 'EXTREME RISK'
    : riskToBroker >= 56 ? 'HIGH RISK'
    : riskToBroker >= 35 ? 'MODERATE RISK'
    : 'LOW RISK';

  const TOXIC_TIER = expectedToxicFlow >= 71 ? 'HIGHLY TOXIC'
    : expectedToxicFlow >= 51 ? 'DIRECTIONAL / SCALPING'
    : expectedToxicFlow >= 26 ? 'MILDLY DIRECTIONAL'
    : 'BENIGN FLOW';

  /* ── 9. Return complete intelligence object ──────────── */
  return {

    /* ── Primary routing output ──────────────────────── */
    recommendedRouting:   routingDecision.recommendation,   // 'A-Book' | 'B-Book' | 'Hybrid'
    routingConfidence,                                        // 0-100
    routingMethod:        routingDecision.method,            // 'override' | 'probabilistic' | 'tie-break'
    routingExplanation:   explanation,                        // { summary, drivers[], monitoring, full }

    /* ── Composite risk indices ───────────────────────── */
    riskToBroker,         // 0-100: danger of B-booking this account
    riskToBrokerTier:     RISK_TIER,
    expectedToxicFlow,    // 0-100: probability of selectively winning / non-hedgeable flow
    expectedToxicFlowTier: TOXIC_TIER,

    /* ── Routing probabilities (do not sum to 100) ──── */
    routingProbabilities: {
      aBook:  probabilities.aBook,
      bBook:  probabilities.bBook,
      hybrid: probabilities.hybrid,
    },

    /* ── Factor scores ───────────────────────────────── */
    factorScores: {
      profitability:     { score: factors.profitability.score,     label: factors.profitability.label,     rationale: factors.profitability.rationale },
      consistency:       { score: factors.consistency.score,       label: factors.consistency.label,       rationale: factors.consistency.rationale },
      drawdown:          { score: factors.drawdown.score,          label: factors.drawdown.label,          rationale: factors.drawdown.rationale },
      martingale:        { score: factors.martingale.score,        label: factors.martingale.label,        rationale: factors.martingale.rationale },
      scalping:          { score: factors.scalping.score,          label: factors.scalping.label,          rationale: factors.scalping.rationale },
      newsTrading:       { score: factors.newsTrading.score,       label: factors.newsTrading.label,       rationale: factors.newsTrading.rationale },
      concentration:     { score: factors.concentration.score,     label: factors.concentration.label,     rationale: factors.concentration.rationale },
      recoveryBehaviour: { score: factors.recoveryBehaviour.score, label: factors.recoveryBehaviour.label, rationale: factors.recoveryBehaviour.rationale },
      riskStability:     { score: factors.riskStability.score,     label: factors.riskStability.label,     rationale: factors.riskStability.rationale },
    },

    /* ── Override rules applied ──────────────────────── */
    overrides: overrideResult.overrides,
    overrideApplied: overrideResult.forced !== null,

    /* ── Meta ────────────────────────────────────────── */
    totalTrades:  m.totalTrades,
    currency:     m.currency,
    accountGrade: id?.accountGrade || '—',
    traderType:   id?.traderType   || '—',
  };
}

/* ─────────────────────────────────────────────────────────
   EXPORTS
───────────────────────────────────────────────────────── */

/* ═══ failureEngine.js ═══ */
/* ═══════════════════════════════════════════════════════════
   DataLB Failure Probability Engine v2

   Inputs:
     m   — MetricsResult        from datalb_metrics_v2
     s   — SessionAnalytics     from datalb_session_engine_v1
     b   — BehaviourAnalytics   from datalb_behaviour_engine_v1
     r   — DiagnosisResult      from datalb_rules_engine_v1
     id  — TraderIdentity       from datalb_identity_engine_v1
     bi  — BrokerIntelligence   from datalb_broker_intelligence_v1

   Output: FailureAnalysis object

   ─────────────────────────────────────────────────────────
   Design principles:
     1. No random values. Every probability derives from a
        documented formula applied to concrete metrics.
     2. All intermediate values are preserved in the output
        so every probability estimate is fully traceable.
     3. Failure is defined as: account equity falls to 50%
        of peak, OR margin call, OR account reaches zero.
     4. Survival score and failure probability are computed
        from independent pathways and then reconciled —
        they must be internally consistent.
     5. The model uses a multi-factor weighted hazard approach:
        each risk dimension contributes a hazard rate per day.
        Daily hazards compound over 30/90/180-day windows.
   ─────────────────────────────────────────────────────────
   Failure categories (mutually exclusive primary assignment):
     STRUCTURAL   — negative expectancy / inverse risk structure
     DRAWDOWN     — equity depletion via sustained drawdown
     BEHAVIOURAL  — emotional patterns compounding losses
     ESCALATION   — martingale / lot escalation collapse
     FREQUENCY    — overtrading / cost erosion
     SESSION      — persistent negative session drag
     CONCENTRATION— single instrument catastrophic loss
═══════════════════════════════════════════════════════════ */
/* ─────────────────────────────────────────────────────────
   UTILITIES
───────────────────────────────────────────────────────── */
const clamp  = (v, lo = 0, hi = 100) => Math.max(lo, Math.min(hi, v));
const fmtP   = v => v == null ? '—' : `${Number(v).toFixed(1)}%`;
const fmtPF  = v => v == null ? '—' : v === Infinity ? '∞' : Number(v).toFixed(2);
const fmtC   = (v, cur = '') => `${cur ? cur + ' ' : ''}${Math.abs(v ?? 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

/**
 * Compound a daily probability over N days.
 * P(failure within N days) = 1 − (1 − dailyHazard)^N
 * Capped at 98% to reflect irreducible uncertainty.
 */
function compound(dailyHazard, days) {
  if (dailyHazard <= 0) return 0;
  const p = 1 - Math.pow(Math.max(0, 1 - dailyHazard), days);
  return clamp(Math.round(p * 100), 0, 98);
}

/**
 * Convert a 0–100 risk score to a per-day hazard rate.
 * Score 0   → ~0.0001/day  (near-zero failure risk)
 * Score 50  → ~0.003/day   (~25% over 90 days)
 * Score 100 → ~0.022/day   (~86% over 90 days, ~98% over 180)
 * Uses a calibrated exponential mapping.
 */
function scoreToHazard(score) {
  // Calibration constants: tuned so score=50 → p90 ≈ 25%, score=80 → p90 ≈ 70%
  const normalized = clamp(score) / 100;
  return 0.0001 * Math.exp(normalized * 5.4);
}

/* ─────────────────────────────────────────────────────────
   HAZARD COMPONENT FUNCTIONS
   Each returns { hazardScore 0-100, label, evidence, weight }
   hazardScore represents relative failure contribution (not a raw %)
───────────────────────────────────────────────────────── */

/**
 * H1 — Structural Hazard
 * Driven by: profit factor, expectancy, win/loss ratio.
 * A system with negative expectancy fails deterministically.
 */
function hazardStructural(m) {
  const pf  = m.profitFactor;
  const wr  = m.winRate / 100;
  const aw  = m.avgWin;
  const al  = m.avgLoss;
  const np  = m.netProfit;
  const tot = m.totalTrades;

  let score = 0;
  const ev  = [];

  // Profit factor is the primary structural signal
  if      (pf < 0.60)                score += 72; ev.push(`PF ${fmtPF(pf)} — severe negative expectancy`);
  else if (pf < 0.80)                score += 52; ev.push(`PF ${fmtPF(pf)} — system loses more than it earns`);
  else if (pf < 1.00)                score += 32; ev.push(`PF ${fmtPF(pf)} — below break-even`);
  else if (pf < 1.20)                score += 14; ev.push(`PF ${fmtPF(pf)} — marginally profitable`);
  else if (pf >= 1.20)               score += 0;  ev.push(`PF ${fmtPF(pf)} — positive expectancy`);

  // Win/loss ratio check (independent of PF)
  if (aw !== null && al !== null) {
    const wlr = aw / al;
    if      (wlr < 0.40) { score += 22; ev.push(`Avg win/loss ratio ${wlr.toFixed(2)} — losses far exceed wins`); }
    else if (wlr < 0.65) { score += 14; ev.push(`Avg win/loss ratio ${wlr.toFixed(2)} — below sustainable threshold`); }
    else if (wlr < 1.00) { score += 6;  ev.push(`Avg win/loss ratio ${wlr.toFixed(2)} — modest asymmetry`); }

    // Required break-even win rate
    if (al > 0 && aw > 0) {
      const beWR  = al / (al + aw);
      const slack = wr - beWR;
      if      (slack < -0.05) { score += 16; ev.push(`Win rate ${fmtP(wr*100)} is ${fmtP(Math.abs(slack)*100)} below break-even WR of ${fmtP(beWR*100)}`); }
      else if (slack < 0.05)  { score += 8;  ev.push(`Win rate barely above break-even — vulnerable to normal variance`); }
    }
  }

  // Net profit as confirming signal
  if (np < 0 && tot >= 10) {
    const lossRate = Math.abs(np) / tot;
    score += Math.min(lossRate > 20 ? 12 : lossRate > 5 ? 7 : 3, 12);
    ev.push(`Net negative: ${fmtC(Math.abs(np), m.currency)} total loss over ${tot} trades`);
  }

  return {
    hazardScore: clamp(score),
    label: score >= 60 ? 'Critical Structural Failure' : score >= 35 ? 'Structural Weakness' : score >= 15 ? 'Marginal Edge' : 'Sound Structure',
    evidence: ev,
    weight: 0.28,  // structural is the highest-weight hazard
    category: 'STRUCTURAL',
  };
}

/**
 * H2 — Drawdown Hazard
 * Driven by: max relative DD, absolute DD, recovery factor, drawdown duration.
 */
function hazardDrawdown(m) {
  const dd  = m.maxRelDD;
  const rf  = m.recoveryFactor;
  const np  = m.netProfit;

  let score = 0;
  const ev  = [];

  // Max relative drawdown
  if      (dd > 50) { score += 68; ev.push(`Extreme drawdown: ${fmtP(dd)} — account requires ${((1/(1-dd/100)-1)*100).toFixed(0)}% gain to recover`); }
  else if (dd > 35) { score += 50; ev.push(`Severe drawdown: ${fmtP(dd)} — near survival-threatening zone`); }
  else if (dd > 22) { score += 34; ev.push(`High drawdown: ${fmtP(dd)} — significantly above professional threshold`); }
  else if (dd > 12) { score += 18; ev.push(`Moderate drawdown: ${fmtP(dd)}`); }
  else if (dd > 6)  { score += 8;  ev.push(`Controlled drawdown: ${fmtP(dd)}`); }
  else              { score += 0;  ev.push(`Minimal drawdown: ${fmtP(dd)}`); }

  // Recovery factor — negative RF with positive NP is unusual but possible
  if (rf !== null) {
    if      (rf < 0)    { score += 20; ev.push(`Negative recovery factor (${rf.toFixed(2)}) — account lost more than it ever made`); }
    else if (rf < 0.5)  { score += 14; ev.push(`Very low recovery factor: ${rf.toFixed(2)} — profit does not justify drawdown taken`); }
    else if (rf < 1.0)  { score += 8;  ev.push(`Recovery factor ${rf.toFixed(2)} below 1.0 — drawdown exceeds net profit`); }
    else if (rf < 2.0)  { score += 3;  ev.push(`Recovery factor ${rf.toFixed(2)} — acceptable but not strong`); }
  } else if (np <= 0) {
    score += 10;
    ev.push('Recovery factor undefined — account is net negative');
  }

  // Absolute drawdown below starting balance
  if (m.absoluteDD > 0) {
    const ad = m.absoluteDD;
    const relAbs = m.totalTrades >= 10 ? clamp(ad / (ad + Math.max(m.grossProfit, 1)) * 100) : 20;
    if (relAbs > 40) { score += 12; ev.push(`Equity fell below starting balance — absolute drawdown ${fmtC(ad, m.currency)}`); }
  }

  return {
    hazardScore: clamp(score),
    label: score >= 60 ? 'Critical Drawdown Risk' : score >= 38 ? 'High Drawdown Risk' : score >= 18 ? 'Moderate Drawdown' : 'Drawdown Controlled',
    evidence: ev,
    weight: 0.22,
    category: 'DRAWDOWN',
  };
}

/**
 * H3 — Escalation / Martingale Hazard
 * Driven by: martingale confidence, escalation rate, max multiplier.
 * Martingale systems have a guaranteed-ruin property:
 * time-to-ruin decreases exponentially with stake multiplier.
 */
function hazardEscalation(b) {
  const mc   = b.lotEscalation.martingaleConf;
  const escR = b.lotEscalation.escalationRate;
  const maxM = b.lotEscalation.maxMultiplier || 0;
  const avgM = b.lotEscalation.avgMultiplier || 0;
  const lotCV = b.lotEscalation.lotCV;
  const losses = b.lotEscalation.lossCount || 1;

  let score = 0;
  const ev  = [];

  // Martingale confidence
  if      (mc >= 80) { score += 65; ev.push(`Martingale confidence ${mc}/100 — ruin is a mathematical certainty given sufficient losing streak`); }
  else if (mc >= 60) { score += 48; ev.push(`Martingale confidence ${mc}/100 — systematic doubling confirmed`); }
  else if (mc >= 40) { score += 28; ev.push(`Martingale confidence ${mc}/100 — partial escalation pattern`); }
  else if (mc >= 20) { score += 12; ev.push(`Martingale confidence ${mc}/100 — mild escalation detected`); }

  // Escalation rate
  if      (escR > 60) { score += 22; ev.push(`${fmtP(escR)} of losses followed by larger position`); }
  else if (escR > 40) { score += 14; ev.push(`${fmtP(escR)} escalation rate — significant post-loss sizing increase`); }
  else if (escR > 20) { score += 7;  ev.push(`${fmtP(escR)} escalation rate — moderate`); }

  // Max multiplier — exponential tail risk
  if      (maxM > 8)   { score += 18; ev.push(`Max lot multiplier ${maxM.toFixed(1)}× — exponential exposure at losing sequences`); }
  else if (maxM > 4)   { score += 12; ev.push(`Max lot multiplier ${maxM.toFixed(1)}×`); }
  else if (maxM > 2)   { score += 6;  ev.push(`Max lot multiplier ${maxM.toFixed(1)}×`); }

  // Lot coefficient of variation
  if      (lotCV > 0.8) { score += 8;  ev.push(`Lot CV ${fmtP(lotCV*100)} — extreme sizing variance`); }
  else if (lotCV > 0.5) { score += 5;  ev.push(`Lot CV ${fmtP(lotCV*100)} — high sizing variance`); }

  return {
    hazardScore: clamp(score),
    label: score >= 62 ? 'Guaranteed Ruin (Martingale)' : score >= 40 ? 'High Escalation Risk' : score >= 18 ? 'Moderate Escalation' : 'No Escalation',
    evidence: ev,
    weight: 0.18,
    category: 'ESCALATION',
  };
}

/**
 * H4 — Behavioural Hazard
 * Driven by: revenge trading, FOMO, overtrading, post-loss win rate degradation.
 * Emotional behaviour systematically reduces trading quality during adverse periods.
 */
function hazardBehavioural(b, r, id) {
  const R    = b.recoveryBehaviour;
  const O    = b.overtrading;
  const H    = b.holdingBehaviour;
  const beh  = id?.behaviourProfileDetail?.primary || '';

  let score = 0;
  const ev  = [];

  // Revenge trading (confirmed pattern)
  if (R.revengeDetected) {
    score += 42;
    const delta = R.postLossWinRate != null ? (R.postLossWinRate - R.baselineWinRate).toFixed(1) : '—';
    ev.push(`Revenge trading confirmed — post-loss win rate ${fmtP(R.postLossWinRate)} vs ${fmtP(R.baselineWinRate)} baseline (Δ${delta}pp)`);
  }

  // Immediate re-entry rate
  if      (R.immediateReentryRate > 55) { score += 20; ev.push(`${fmtP(R.immediateReentryRate)} of losses followed by immediate re-entry`); }
  else if (R.immediateReentryRate > 35) { score += 12; ev.push(`${fmtP(R.immediateReentryRate)} immediate re-entry rate — elevated`); }
  else if (R.immediateReentryRate > 20) { score += 6;  ev.push(`${fmtP(R.immediateReentryRate)} immediate re-entry rate — moderate`); }

  // Post-loss win rate degradation
  if (R.postLossWinRate !== null) {
    const delta = R.postLossWinRate - R.baselineWinRate;
    if      (delta < -30) { score += 18; ev.push(`Post-loss WR degradation ${delta.toFixed(1)}pp — severe emotional impact on quality`); }
    else if (delta < -20) { score += 12; ev.push(`Post-loss WR degradation ${delta.toFixed(1)}pp`); }
    else if (delta < -10) { score += 6;  ev.push(`Post-loss WR degradation ${delta.toFixed(1)}pp`); }
  }

  // Holding asymmetry (cuts winners short, holds losers)
  if (H.holdRatio !== null && H.holdRatio < 0.7) {
    score += 12;
    ev.push(`Hold ratio ${H.holdRatio.toFixed(2)} — winners held ${((1-H.holdRatio)*100).toFixed(0)}% shorter than losers`);
  } else if (H.holdRatio !== null && H.holdRatio < 0.85) {
    score += 6;
    ev.push(`Hold ratio ${H.holdRatio.toFixed(2)} — mild asymmetry between winners and losers`);
  }

  // Overtrading
  if      (O.frequencyScore > 75) { score += 14; ev.push(`Frequency score ${O.frequencyScore}/100 — significant overtrading confirmed`); }
  else if (O.frequencyScore > 55) { score += 8;  ev.push(`Frequency score ${O.frequencyScore}/100 — elevated trading frequency`); }

  // Behaviour profile multiplier from identity engine
  const BEH_MULT = { MartingaleBehaviour: 1.0, RevengeTrader: 0.85, FOTOTrader: 0.65, Overtrader: 0.55, InconsistentTrader: 0.35, DisciplinedTrader: -0.25 };
  const mult = BEH_MULT[beh] || 0;
  const adj  = Math.round(score * Math.abs(mult));
  if (mult > 0)   { score += adj; ev.push(`Behaviour profile "${beh}" amplifies hazard by ${fmtP(mult*100)}`); }
  else if (mult < 0) { score = Math.max(0, score + adj); ev.push(`Behaviour profile "${beh}" reduces hazard`); }

  return {
    hazardScore: clamp(score),
    label: score >= 62 ? 'Destructive Behaviour Pattern' : score >= 40 ? 'Significant Behavioural Risk' : score >= 20 ? 'Moderate Emotional Impact' : 'Controlled Behaviour',
    evidence: ev,
    weight: 0.16,
    category: 'BEHAVIOURAL',
  };
}

/**
 * H5 — Frequency / Cost Hazard
 * Driven by: overtrading score, commission drag, avg trades/day.
 * High-frequency trading erodes edge through transaction costs.
 */
function hazardFrequency(m, b) {
  const O    = b.overtrading;
  const tpd  = O.avgPerTradingDay;
  const otD  = O.overtradingDays || 0;
  const uTD  = O.uniqueTradingDays || O.uniqueTD || 1;
  const pf   = m.profitFactor;

  let score = 0;
  const ev  = [];

  // Frequency score from behaviour engine
  if      (O.frequencyScore > 80) { score += 40; ev.push(`Frequency score ${O.frequencyScore}/100 — critical overtrading`); }
  else if (O.frequencyScore > 60) { score += 26; ev.push(`Frequency score ${O.frequencyScore}/100 — high overtrading`); }
  else if (O.frequencyScore > 40) { score += 14; ev.push(`Frequency score ${O.frequencyScore}/100 — elevated`); }
  else if (O.frequencyScore > 25) { score += 6;  ev.push(`Frequency score ${O.frequencyScore}/100 — moderate`); }

  // Average daily trades
  if      (tpd > 25) { score += 28; ev.push(`${tpd.toFixed(1)} avg trades/day — commission drag is material`); }
  else if (tpd > 15) { score += 18; ev.push(`${tpd.toFixed(1)} avg trades/day — high frequency`); }
  else if (tpd > 8)  { score += 9;  ev.push(`${tpd.toFixed(1)} avg trades/day — moderately active`); }

  // Overtrading days as proportion of all trading days
  const otRate = otD / uTD;
  if      (otRate > 0.5)  { score += 18; ev.push(`${fmtP(otRate*100)} of trading days exceed 2× average frequency`); }
  else if (otRate > 0.3)  { score += 10; ev.push(`${fmtP(otRate*100)} of trading days are overtrading days`); }
  else if (otRate > 0.15) { score += 5;  ev.push(`${fmtP(otRate*100)} of trading days exceed normal frequency`); }

  // High frequency + low PF = cost destruction
  if (tpd > 8 && pf < 1.2) {
    score += 12;
    ev.push(`High frequency (${tpd.toFixed(1)}/day) combined with low PF (${fmtPF(pf)}) — commission erosion likely exceeds edge`);
  }

  return {
    hazardScore: clamp(score),
    label: score >= 55 ? 'Overtrading Confirmed' : score >= 35 ? 'Elevated Trading Frequency' : score >= 15 ? 'Moderate Frequency' : 'Healthy Frequency',
    evidence: ev,
    weight: 0.10,
    category: 'FREQUENCY',
  };
}

/**
 * H6 — Session Drag Hazard
 * Driven by: worst session PF and net profit, session contribution percentages.
 */
function hazardSession(s, m) {
  const sessions   = s?.sessions || {};
  const SESS_KEYS  = ['Asia','London','NewYork','After'];
  const total      = m.totalTrades || 1;

  let score = 0;
  const ev  = [];

  // Find sessions that are net-negative and have meaningful sample size
  const negSessions = SESS_KEYS
    .map(k => sessions[k])
    .filter(Boolean)
    .filter(sess => sess.count >= 10 && sess.netProfit < 0)
    .sort((a, b_) => a.netProfit - b_.netProfit);  // worst first

  if (negSessions.length > 0) {
    const worst = negSessions[0];
    const share = worst.count / total * 100;

    // Session PF
    if      (worst.profitFactor < 0.50) { score += 40; ev.push(`${worst.key} session PF ${fmtPF(worst.profitFactor)} — severe negative edge in this window`); }
    else if (worst.profitFactor < 0.70) { score += 28; ev.push(`${worst.key} session PF ${fmtPF(worst.profitFactor)} — significant session drag`); }
    else if (worst.profitFactor < 0.85) { score += 16; ev.push(`${worst.key} session PF ${fmtPF(worst.profitFactor)}`); }
    else if (worst.profitFactor < 1.00) { score += 8;  ev.push(`${worst.key} session slightly negative`); }

    // Trade share in the negative session amplifies risk
    if (share > 50) { score += 20; ev.push(`${fmtP(share)} of trades are in the ${worst.key} session — dominant loss window`); }
    else if (share > 30) { score += 12; }
    else if (share > 15) { score += 6;  }

    if (negSessions.length >= 2) {
      score += 16;
      ev.push(`${negSessions.length} sessions are net-negative — no single session anchor for profitability`);
    }
  }

  // Also check for zero positive sessions with enough data
  const viableSessions = SESS_KEYS.map(k => sessions[k]).filter(Boolean).filter(s => s.count >= 10);
  if (viableSessions.length >= 2 && viableSessions.every(s => s.netProfit <= 0)) {
    score += 20;
    ev.push('All sessions with sufficient data are net-negative');
  }

  if (score === 0) ev.push('No materially negative session detected');

  return {
    hazardScore: clamp(score),
    label: score >= 52 ? 'Session Drag Confirmed' : score >= 30 ? 'Negative Session Present' : score >= 12 ? 'Mild Session Weakness' : 'Sessions Healthy',
    evidence: ev,
    weight: 0.08,
    category: 'SESSION',
  };
}

/**
 * H7 — Concentration Hazard
 * Driven by: single-instrument dominance, top losing symbol contribution.
 * A concentrated account can be destroyed by a single instrument event.
 */
function hazardConcentration(b) {
  const C   = b.concentration;
  const topPct  = C.topPct || 0;
  const sym     = C.topSym?.sym || C.topSym?.symbol || '?';
  const nSym    = C.symStats?.length || 1;
  const topLoss = C.topLosingContrib || 0;

  let score = 0;
  const ev  = [];

  // Single-symbol dominance
  if      (topPct > 90) { score += 46; ev.push(`${sym}: ${fmtP(topPct)} of trades — account is a single-instrument strategy`); }
  else if (topPct > 75) { score += 34; ev.push(`${sym}: ${fmtP(topPct)} of trades — extreme concentration`); }
  else if (topPct > 60) { score += 22; ev.push(`${sym}: ${fmtP(topPct)} of trades — high concentration`); }
  else if (topPct > 45) { score += 12; ev.push(`${sym}: ${fmtP(topPct)} of trades`); }

  // Number of symbols
  if (nSym === 1) { score += 20; ev.push('Only 1 unique instrument traded — no diversification'); }
  else if (nSym <= 2) { score += 10; ev.push(`Only ${nSym} instruments traded`); }

  // Top losing symbol contribution to gross losses
  if      (topLoss > 70) { score += 24; ev.push(`One symbol drives ${fmtP(topLoss)} of total gross losses — catastrophic single-instrument drag`); }
  else if (topLoss > 50) { score += 16; ev.push(`One symbol accounts for ${fmtP(topLoss)} of total gross losses`); }
  else if (topLoss > 35) { score += 8;  ev.push(`One symbol accounts for ${fmtP(topLoss)} of gross losses`); }

  if (score === 0) ev.push(`${nSym} unique instruments traded — adequate diversification`);

  return {
    hazardScore: clamp(score),
    label: score >= 55 ? 'Extreme Concentration Risk' : score >= 35 ? 'High Concentration' : score >= 15 ? 'Moderate Concentration' : 'Diversified',
    evidence: ev,
    weight: 0.08,
    category: 'CONCENTRATION',
  };
}

/* ─────────────────────────────────────────────────────────
   COMPOSITE DAILY HAZARD RATE
───────────────────────────────────────────────────────── */

/**
 * Combine all hazard components into a single weighted daily hazard rate.
 * Each component contributes: dailyHazard_i = scoreToHazard(score_i) × weight_i
 * Total daily hazard = Σ(dailyHazard_i) × globalModifier
 *
 * Global modifier from: account grade, broker risk-to-broker score, consecutive losses.
 */
function computeDailyHazard(hazards, m, r, id, bi) {
  const grade  = id?.accountGrade || 'C';
  const rtb    = bi?.riskToBroker || 50;
  const mls    = m.maxLossStreak  || 0;

  // Weighted sum of component hazards
  let baseHazard = 0;
  for (const h of Object.values(hazards)) {
    baseHazard += scoreToHazard(h.hazardScore) * h.weight;
  }

  // Global modifiers (multiplicative)
  const GRADE_MOD = {
    'A+':0.25,'A':0.35,'A-':0.42,'B+':0.55,'B':0.72,
    'B-':0.88,'C+':1.10,'C':1.30,'D+':1.55,'D':1.80,'F':2.40
  };
  const gradeMod = GRADE_MOD[grade] || 1.30;

  // Broker risk-to-broker: high RtB = account is dangerous to broker, which also
  // means the account is capable of sustained profitable periods (inversely reduces failure)
  const brokerMod = rtb >= 60 ? 0.78 : rtb >= 40 ? 0.90 : 1.05;

  // Consecutive losses: a long losing streak can indicate the edge has stopped working
  const mlsMod = mls >= 10 ? 1.22 : mls >= 6 ? 1.10 : mls >= 4 ? 1.04 : 1.0;

  // Critical rules fired
  const critMod = r.criticalCount >= 3 ? 1.25 : r.criticalCount >= 2 ? 1.14 : r.criticalCount >= 1 ? 1.06 : 1.0;

  const dailyHazard = baseHazard * gradeMod * brokerMod * mlsMod * critMod;

  return {
    base: baseHazard,
    daily: dailyHazard,
    gradeMod, brokerMod, mlsMod, critMod,
  };
}

/* ─────────────────────────────────────────────────────────
   SURVIVAL SCORE
───────────────────────────────────────────────────────── */

/**
 * Compute the Survival Score (0–100).
 * This is computed INDEPENDENTLY from the hazard model
 * using a rubric-based approach, then reconciled with
 * the probability model for consistency.
 *
 * Interpretation:
 *   90–100 : Excellent — institutional-grade survival characteristics
 *   70–89  : Good — above-average survival probability
 *   50–69  : Moderate — identifiable risks but viable
 *   30–49  : Poor — multiple structural weaknesses
 *   10–29  : Critical — likely to fail without intervention
 *   0–9    : Terminal — failure is near-certain
 */
function computeSurvivalScore(m, b, r, id, bi) {
  const pf   = m.profitFactor;
  const dd   = m.maxRelDD;
  const rf   = m.recoveryFactor;
  const mc   = b.lotEscalation.martingaleConf;
  const cv   = b.lotEscalation.lotCV;
  const escR = b.lotEscalation.escalationRate;
  const beh  = id?.behaviourProfileDetail?.primary || '';
  const grade = id?.accountGrade || 'C';
  const rtb  = bi?.riskToBroker || 50;

  let score = 100;   // start at perfect and deduct

  // Structural deductions
  if      (pf < 0.60)  score -= 45;
  else if (pf < 0.80)  score -= 32;
  else if (pf < 1.00)  score -= 20;
  else if (pf < 1.20)  score -= 8;
  else if (pf >= 1.50) score += 5;   // bonus for strong edge

  // Drawdown deductions
  if      (dd > 50)   score -= 38;
  else if (dd > 35)   score -= 26;
  else if (dd > 22)   score -= 16;
  else if (dd > 12)   score -= 8;
  else if (dd < 6)    score += 4;    // bonus for tight drawdown

  // Recovery factor
  if (rf !== null) {
    if      (rf < 0)    score -= 18;
    else if (rf < 0.5)  score -= 12;
    else if (rf < 1.0)  score -= 6;
    else if (rf >= 2.0) score += 4;
  }

  // Escalation / martingale
  if      (mc >= 75)  score -= 30;
  else if (mc >= 55)  score -= 20;
  else if (mc >= 35)  score -= 10;

  // Lot consistency
  if      (cv > 0.8)  score -= 14;
  else if (cv > 0.5)  score -= 8;
  else if (cv > 0.3)  score -= 4;
  else if (cv < 0.15) score += 4;   // bonus for excellent consistency

  // Behaviour profile
  const BEH_DED = {
    DisciplinedTrader: 0, InconsistentTrader: -10, Overtrader: -14,
    FOTOTrader: -16, RevengeTrader: -22, MartingaleBehaviour: -28,
  };
  score += (BEH_DED[beh] || -8);

  // Critical rules — each one represents a confirmed structural failure
  score -= (r.criticalCount * 10);
  score -= (r.highCount * 4);
  score -= (r.mediumCount * 1.5);

  // Grade-based floor/ceiling
  const GRADE_BOUNDS = {
    'A+': [78, 100], 'A': [68, 96], 'A-': [60, 92], 'B+': [50, 85],
    'B': [40, 80], 'B-': [32, 72], 'C+': [22, 62], 'C': [14, 55],
    'D+': [8, 42], 'D': [4, 32], 'F': [0, 18],
  };
  const [lo, hi] = GRADE_BOUNDS[grade] || [14, 55];
  score = clamp(Math.round(score), lo, hi);

  // Broker perspective: high RtB = account has genuine long-term edge
  if (rtb >= 70) score = Math.min(score + 4, hi);

  return clamp(score, 0, 100);
}

/* ─────────────────────────────────────────────────────────
   FAILURE DRIVERS
───────────────────────────────────────────────────────── */

/**
 * Identify the primary and secondary failure drivers
 * from the ranked hazard components.
 */
function identifyFailureDrivers(hazards) {
  const ranked = Object.entries(hazards)
    .map(([key, h]) => ({ key, ...h }))
    .sort((a, b_) => b_.hazardScore - a.hazardScore);

  // Category → human label
  const CAT_LABEL = {
    STRUCTURAL:    'Negative Trade Economics (Low Profit Factor & Unfavourable Win/Loss Ratio)',
    DRAWDOWN:      'Capital Depletion via Excessive Drawdown',
    ESCALATION:    'Exponential Risk Escalation (Martingale / Lot Doubling)',
    BEHAVIOURAL:   'Emotional Behaviour (Revenge Trading / Post-Loss Deterioration)',
    FREQUENCY:     'Transaction Cost Erosion (Overtrading)',
    SESSION:       'Persistent Session Drag (Negative Edge in Active Trading Window)',
    CONCENTRATION: 'Single-Instrument Catastrophic Exposure',
  };

  const primary   = ranked[0];
  const secondary = ranked[1];

  return {
    primary: {
      category:    primary.category,
      label:       CAT_LABEL[primary.category] || primary.category,
      hazardScore: primary.hazardScore,
      evidence:    primary.evidence.slice(0, 3),
      description: buildDriverDescription(primary),
    },
    secondary: secondary.hazardScore >= 12 ? {
      category:    secondary.category,
      label:       CAT_LABEL[secondary.category] || secondary.category,
      hazardScore: secondary.hazardScore,
      evidence:    secondary.evidence.slice(0, 2),
      description: buildDriverDescription(secondary),
    } : null,
    ranked: ranked.map(h => ({ category: h.category, hazardScore: h.hazardScore, label: h.label })),
  };
}

function buildDriverDescription(h) {
  const CAT_DESC = {
    STRUCTURAL:    'The account has a mathematical negative expectancy — it is designed to lose money on average per trade regardless of win rate.',
    DRAWDOWN:      'The account equity has declined sharply from its peak and the recovery path requires returns that are statistically unlikely given current parameters.',
    ESCALATION:    'Position sizes increase after losses, creating exponentially growing exposure during losing sequences. One sufficiently long losing streak will collapse the account.',
    BEHAVIOURAL:   'Emotional decision-making after losses results in worse performance precisely when discipline is most critical — compounding losses rather than recovering from them.',
    FREQUENCY:     'Trading frequency is too high for the edge being demonstrated. Transaction costs are consuming a disproportionate share of gross profit.',
    SESSION:       'The account is actively trading in market windows where it has demonstrated no edge, and those sessions are consistently destroying profitability.',
    CONCENTRATION: 'Virtually all exposure is concentrated in a single instrument. One adverse event — news spike, flash crash, spread widening — can catastrophically damage the account.',
  };
  return CAT_DESC[h.category] || `${h.label}: hazard score ${h.hazardScore}/100.`;
}

/* ─────────────────────────────────────────────────────────
   EXPECTED TIME TO FAILURE
───────────────────────────────────────────────────────── */

/**
 * Estimate expected account lifespan in calendar days.
 * Computed from the daily hazard rate using the expected value of a
 * geometric distribution: E[T] = 1 / dailyHazard.
 * Capped at 3,650 days (10 years) for near-zero hazard rates.
 */
function computeExpectedTimeToFailure(dailyHazardInfo) {
  const h    = dailyHazardInfo.daily;
  if (h <= 0) return { days: 3650, label: 'Indefinite (>10 years)', confidence: 'Low — insufficient hazard signal' };

  const days = Math.min(Math.round(1 / h), 3650);

  const label = days <= 30  ? `~${days} days — imminent failure expected`
    : days <= 90            ? `~${days} days — failure likely within 3 months`
    : days <= 180           ? `~${days} days — failure likely within 6 months`
    : days <= 365           ? `~${days} days — failure expected within the year`
    : days <= 730           ? `~${Math.round(days/30)} months (~${(days/365).toFixed(1)} years)`
    : days <= 1825          ? `~${(days/365).toFixed(1)} years — account viable but vulnerable`
    : `>${(days/365).toFixed(0)} years — structurally sound`;

  return {
    days,
    label,
    confidence: days > 730 ? 'Low — thin-tailed estimate at long horizons' : days > 180 ? 'Moderate' : 'High',
    dailyHazardRate: h,
  };
}

/* ─────────────────────────────────────────────────────────
   IMPROVEMENT POTENTIAL
───────────────────────────────────────────────────────── */

/**
 * Estimate what the survival score would be if the top N
 * identifiable problems were corrected.
 * Uses the primary and secondary failure drivers to define
 * the improvement scenario.
 */
function computeImprovementPotential(hazards, survivalScore, failureProb, m, b, r) {
  const ranked = Object.entries(hazards)
    .map(([key, h]) => ({ key, ...h }))
    .sort((a, b_) => b_.hazardScore - a.hazardScore);

  // Estimate potential hazard reduction per category if corrected
  const FIX_REDUCTION = {
    STRUCTURAL:    0.72,  // fixing expectancy has the largest impact
    ESCALATION:    0.85,  // eliminating martingale fully resolves that hazard
    DRAWDOWN:      0.60,  // position sizing fix can substantially reduce DD
    BEHAVIOURAL:   0.68,  // implementing cool-down rules reduces revenge trading
    FREQUENCY:     0.55,  // setting daily limits reduces but doesn't eliminate cost
    SESSION:       0.80,  // stopping trading in a bad session fully resolves it
    CONCENTRATION: 0.70,  // adding 2 instruments substantially reduces this
  };

  // Score improvement if top 2 drivers are corrected
  const top2 = ranked.slice(0, 2);
  let improvedHazardScore = 0;
  for (const h of Object.values(hazards)) {
    const reduction = top2.some(t => t.category === h.category) ? (FIX_REDUCTION[h.category] || 0.6) : 0;
    improvedHazardScore += h.hazardScore * h.weight * (1 - reduction);
  }
  improvedHazardScore = clamp(Math.round(improvedHazardScore / Object.values(hazards).reduce((s, h) => s + h.weight, 0)));

  // Survival score improvement (heuristic uplift)
  const survivalUplift = top2.reduce((s, h) => {
    const fix = FIX_REDUCTION[h.category] || 0.6;
    return s + h.hazardScore * fix * 0.35;  // each point of hazard reduced ≈ 0.35 survival points
  }, 0);
  const improvedSurvival = clamp(Math.round(survivalScore + survivalUplift));

  // Improved 90-day failure probability
  const improvedDailyH = scoreToHazard(improvedHazardScore) * 0.85;  // 15% additional improvement from discipline
  const improvedP90    = compound(improvedDailyH, 90);

  // Specific actions that drive the improvement
  const actionMap = {
    STRUCTURAL:    'Restructure strategy to achieve minimum PF of 1.3 — set a hard minimum RRR of 1:1.5 on all entries',
    ESCALATION:    'Eliminate all position size escalation — implement fixed 1% equity risk per trade with no exceptions',
    DRAWDOWN:      'Implement a 3% daily loss limit and 50% position size reduction after any 15% drawdown from peak',
    BEHAVIOURAL:   'Implement mandatory 15-minute cool-down after every loss — track and review post-loss trade outcomes separately',
    FREQUENCY:     `Set a hard daily trade limit of ${Math.max(2, Math.round(b.overtrading.avgPerTradingDay * 0.5))} — stop trading when limit is reached regardless of setups`,
    SESSION:       'Immediately stop trading in the identified negative session — paper trade that window for 50 trades before returning',
    CONCENTRATION: 'Add 2 additional instruments from different asset classes — cap any single symbol at 60% of monthly trades',
  };

  const actions = top2.map(h => ({
    category: h.category,
    action:   actionMap[h.category] || `Correct ${h.label} pattern`,
    hazardReduction: Math.round((FIX_REDUCTION[h.category] || 0.6) * h.hazardScore),
  }));

  return {
    currentSurvivalScore: survivalScore,
    improvedSurvivalScore: improvedSurvival,
    survivalGain: improvedSurvival - survivalScore,
    currentP90:  failureProb.p90,
    improvedP90,
    p90Reduction: failureProb.p90 - improvedP90,
    drivenBy: top2.map(h => h.category),
    actions,
    summary: `Correcting ${top2.map(h => h.category.toLowerCase()).join(' and ')} would improve survival score by ${improvedSurvival - survivalScore} points and reduce 90-day failure probability from ${failureProb.p90}% to ~${improvedP90}%.`,
  };
}

/* ─────────────────────────────────────────────────────────
   CONFIDENCE SCORE
───────────────────────────────────────────────────────── */

function computeModelConfidence(m, r) {
  const tot  = m.totalTrades;
  const days = m.calDays || 1;
  let conf   = 0;

  // Sample size
  if      (tot >= 200) conf += 36;
  else if (tot >= 100) conf += 28;
  else if (tot >= 50)  conf += 20;
  else if (tot >= 30)  conf += 12;
  else if (tot >= 10)  conf += 6;
  else                 conf += 2;

  // Statement period length
  if      (days >= 180) conf += 26;
  else if (days >= 90)  conf += 18;
  else if (days >= 30)  conf += 12;
  else                  conf += 4;

  // Number of triggered rules (more rules = more evidence for the model)
  conf += Math.min(r.triggeredCount * 3, 24);

  // Data completeness: hold time data available?
  if (m.avgHoldMs) conf += 8;

  // Session data: at least 2 sessions have meaningful samples?
  conf += 6;  // base assumption

  return clamp(conf, 10, 96);
}

/* ─────────────────────────────────────────────────────────
   MAIN ENTRY POINT
───────────────────────────────────────────────────────── */

/**
 * Compute complete failure probability analysis for an MT4/MT5 account.
 *
 * @param {object} m   MetricsResult        — from calculateMetrics()
 * @param {object} s   SessionAnalytics     — from calculateSessions()
 * @param {object} b   BehaviourAnalytics   — from calculateBehaviour()
 * @param {object} r   DiagnosisResult      — from evaluateRules()
 * @param {object} id  TraderIdentity       — from classifyTraderIdentity()
 * @param {object} bi  BrokerIntelligence   — from computeBrokerIntelligence()
 * @returns {FailureAnalysis}
 */
function computeFailureProbability(m, s, b, r, id, bi) {

  /* ── 1. Score all 7 hazard components ─────────────── */
  const hazards = {
    structural:    hazardStructural(m),
    drawdown:      hazardDrawdown(m),
    escalation:    hazardEscalation(b),
    behavioural:   hazardBehavioural(b, r, id),
    frequency:     hazardFrequency(m, b),
    session:       hazardSession(s, m),
    concentration: hazardConcentration(b),
  };

  /* ── 2. Composite daily hazard rate ───────────────── */
  const dailyHazardInfo = computeDailyHazard(hazards, m, r, id, bi);

  /* ── 3. Failure probabilities (compounded) ────────── */
  const h  = dailyHazardInfo.daily;
  const failureProb = {
    p30:  compound(h, 30),
    p90:  compound(h, 90),
    p180: compound(h, 180),
    dailyHazardRate:     parseFloat(h.toExponential(4)),
    modelFormula: 'P(fail within N days) = 1 − (1 − dailyHazard)^N',
  };

  /* ── 4. Survival score (independent rubric) ───────── */
  const survivalScore = computeSurvivalScore(m, b, r, id, bi);

  /* ── 5. Consistency check: reconcile survival ↔ prob ─*/
  // If 90-day failure > 60%, survival score should be below 40.
  // If survival score > 70, 90-day failure should be below 25.
  // Apply a soft reconciliation nudge (not a hard override).
  const reconciledSurvival = failureProb.p90 > 60 && survivalScore > 45
    ? Math.min(survivalScore, 45)
    : failureProb.p90 < 20 && survivalScore < 55
    ? Math.max(survivalScore, 55)
    : survivalScore;

  /* ── 6. Failure drivers ───────────────────────────── */
  const failureDrivers = identifyFailureDrivers(hazards);

  /* ── 7. Expected time to failure ─────────────────── */
  const expectedTimeToFailure = computeExpectedTimeToFailure(dailyHazardInfo);

  /* ── 8. Improvement potential ─────────────────────── */
  const improvementPotential = computeImprovementPotential(
    hazards, reconciledSurvival, failureProb, m, b, r
  );

  /* ── 9. Model confidence ─────────────────────────── */
  const confidenceScore = computeModelConfidence(m, r);

  /* ── 10. Supporting evidence ────────────────────────*/
  const supportingEvidence = {
    tradeSample:      m.totalTrades,
    statementPeriod:  m.calDays ? `${m.calDays} calendar days` : 'unknown',
    profitFactor:     m.profitFactor === Infinity ? '∞' : m.profitFactor.toFixed(2),
    maxDrawdown:      fmtP(m.maxRelDD),
    recoveryFactor:   m.recoveryFactor !== null ? m.recoveryFactor.toFixed(2) : '—',
    martingaleConf:   `${b.lotEscalation.martingaleConf}/100`,
    escalationRate:   fmtP(b.lotEscalation.escalationRate),
    maxLossStreak:    m.maxLossStreak,
    accountGrade:     id?.accountGrade || '—',
    riskToBroker:     bi?.riskToBroker != null ? `${bi.riskToBroker}/100` : '—',
    expectedToxicFlow: bi?.expectedToxicFlow != null ? `${bi.expectedToxicFlow}/100` : '—',
    dailyHazardRate:  dailyHazardInfo.daily.toExponential(4),
    hazardModifiers: {
      grade:       `${dailyHazardInfo.gradeMod.toFixed(2)}×`,
      broker:      `${dailyHazardInfo.brokerMod.toFixed(2)}×`,
      lossStreak:  `${dailyHazardInfo.mlsMod.toFixed(2)}×`,
      critRules:   `${dailyHazardInfo.critMod.toFixed(2)}×`,
    },
    hazardComponentScores: Object.fromEntries(
      Object.entries(hazards).map(([k, h]) => [k, { score: h.hazardScore, weight: h.weight, label: h.label }])
    ),
    rulesTriggered: r.triggeredCount,
    criticalRules:  r.criticalCount,
  };

  /* ── 11. Survival tier label ─────────────────────── */
  const SURV_TIER = reconciledSurvival >= 85 ? 'Excellent'
    : reconciledSurvival >= 68 ? 'Good'
    : reconciledSurvival >= 50 ? 'Moderate'
    : reconciledSurvival >= 30 ? 'Poor'
    : reconciledSurvival >= 12 ? 'Critical'
    : 'Terminal';

  /* ── Return complete FailureAnalysis object ─────────*/
  return {

    /* ── Primary outputs ─────────────────────────── */
    survivalScore:    reconciledSurvival,
    survivalTier:     SURV_TIER,

    failureProbability: {
      p30:  failureProb.p30,   // % chance of failure within 30 days
      p90:  failureProb.p90,   // % chance of failure within 90 days
      p180: failureProb.p180,  // % chance of failure within 180 days
      dailyHazardRate:  failureProb.dailyHazardRate,
      modelFormula:     failureProb.modelFormula,
    },

    failureDrivers,         // { primary, secondary, ranked[] }
    expectedTimeToFailure,  // { days, label, confidence, dailyHazardRate }
    improvementPotential,   // { survivalGain, p90Reduction, actions[], summary }
    confidenceScore,        // 0-100

    /* ── Intermediate model data (fully traceable) ── */
    hazardComponents: hazards,
    dailyHazardInfo,
    supportingEvidence,

    /* ── Meta ────────────────────────────────────── */
    currency:      m.currency,
    totalTrades:   m.totalTrades,
    accountGrade:  id?.accountGrade || '—',
    traderType:    id?.traderType   || '—',
  };
}

/* ─────────────────────────────────────────────────────────
   EXPORTS
───────────────────────────────────────────────────────── */

/* ═══ kavoxPredictiveEngine.js ═══ */
/* ═══════════════════════════════════════════════════════════
   KAVOX Predictive Engine™ v1

   Inputs:
     m   — MetricsResult        from datalb_metrics_v2
     s   — SessionAnalytics     from datalb_session_engine_v1
     b   — BehaviourAnalytics   from datalb_behaviour_engine_v1
     r   — DiagnosisResult      from datalb_rules_engine_v1
     id  — TraderIdentity       from datalb_identity_engine_v1
     bi  — BrokerIntelligence   from datalb_broker_intelligence_v1
     fa  — FailureAnalysis      from datalb_failure_engine_v2

   Outputs: KavoxForecast object containing:
     1. survivalForecast      — survival curve + confidence band
     2. riskForecast          — drawdown, VaR, lot escalation projections
     3. performanceForecast   — P&L trajectory, break-even, expected range
     4. behaviourForecast     — pattern evolution, escalation trajectory
     5. improvementProjection — counterfactual scenario modelling

   ─────────────────────────────────────────────────────────
   Design principles:
     • No Math.random(). All pseudo-randomness uses a
       deterministic LCG seeded by account-specific metrics
       (trade count, profit factor, martingale confidence).
       Identical inputs always produce identical forecasts.
     • Every output is traceable to the input metric that
       drives it. Intermediate values are preserved.
     • Monte Carlo uses 1,000 simulated paths. Each path
       is deterministic given the seed. Percentiles are
       derived from path distributions, not assumed.
     • Confidence intervals narrow when sample size is large,
       widen when data is thin — encoded via a data
       sufficiency factor applied to all volatility estimates.
     • Failure is defined as: cumulative P&L drops 50% below
       peak, OR account draws below starting balance by 30%+.
═══════════════════════════════════════════════════════════ */
/* ─────────────────────────────────────────────────────────
   DETERMINISTIC PSEUDO-RANDOM NUMBER GENERATOR
   Linear Congruential Generator (LCG) — fully seedable.
   Same seed → same sequence → same forecast.
───────────────────────────────────────────────────────── */
function createRNG(seed) {
  // Knuth's constants for 32-bit LCG
  let state = Math.abs(Math.round(seed)) % 2147483647 || 1;
  return {
    next() {
      state = (state * 1664525 + 1013904223) & 0xFFFFFFFF;
      return (state >>> 0) / 0xFFFFFFFF;  // [0, 1)
    },
    // Box-Muller: generates standard normal variate
    nextGaussian(mu = 0, sigma = 1) {
      const u1 = Math.max(this.next(), 1e-10);
      const u2 = this.next();
      const z  = Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
      return mu + sigma * z;
    },
    // Bernoulli trial
    trial(p) { return this.next() < p; },
  };
}

function buildSeed(m, b) {
  // Deterministic seed from key metrics — changes when data changes
  const pf   = m.profitFactor === Infinity ? 9999 : Math.round(m.profitFactor * 1000);
  const mc   = b.lotEscalation.martingaleConf;
  const tot  = m.totalTrades;
  const dd   = Math.round(m.maxRelDD * 100);
  return (pf * 7 + mc * 13 + tot * 3 + dd * 17) % 2147483647 || 42;
}

/* ─────────────────────────────────────────────────────────
   UTILITIES
───────────────────────────────────────────────────────── */
const clamp  = (v, lo = 0, hi = 100) => Math.max(lo, Math.min(hi, v));
const round2 = v => Math.round(v * 100) / 100;
const round0 = v => Math.round(v);
const fmtP   = v => `${Number(v).toFixed(1)}%`;
const fmtPF  = v => v == null ? '—' : v >= 999 ? '∞' : Number(v).toFixed(2);

/**
 * Compute percentiles from a sorted array.
 * p: array of percentiles [0-100] to extract.
 */
function percentiles(arr, ps) {
  const sorted = [...arr].sort((a, b) => a - b);
  const n = sorted.length;
  return ps.map(p => {
    const i = (p / 100) * (n - 1);
    const lo = Math.floor(i), hi = Math.ceil(i);
    if (lo === hi) return sorted[lo];
    return sorted[lo] + (i - lo) * (sorted[hi] - sorted[lo]);
  });
}

/**
 * Data sufficiency factor: scales uncertainty.
 * 10 trades → 0.4 (wide CIs), 200+ trades → 1.0 (tight CIs).
 */
function dataSufficiency(totalTrades) {
  if (totalTrades >= 200) return 1.00;
  if (totalTrades >= 100) return 0.88;
  if (totalTrades >=  50) return 0.72;
  if (totalTrades >=  30) return 0.58;
  if (totalTrades >=  15) return 0.44;
  return 0.32;
}

/**
 * Hazard-based daily failure probability → survival at day t.
 * S(t) = (1 − h)^t
 */
function survival(dailyHazard, t) {
  return Math.pow(Math.max(0, 1 - dailyHazard), t);
}

/* ─────────────────────────────────────────────────────────
   EXTRACT CORE PARAMETERS FROM ENGINE OUTPUTS
   All simulation parameters are derived, never assumed.
───────────────────────────────────────────────────────── */

function extractParams(m, s, b, r, id, bi, fa) {
  const cur = m.currency || '';

  // ── Trade-level P&L statistics ───────────────────────
  // Expected value per trade (mathematical expectancy)
  const expectancy = m.totalTrades > 0
    ? m.netProfit / m.totalTrades
    : 0;

  // Standard deviation of P&L per trade
  // Approximated from avg win, avg loss, win rate:
  //   Var = wr * σ²_win + (1-wr) * σ²_loss + wr*(1-wr)*(avgWin+avgLoss)²
  // We don't have per-trade SD from engines, so use a conservative estimate:
  const wr    = m.winRate / 100;
  const avgW  = m.avgWin || 0;
  const avgL  = m.avgLoss || 0;
  const varPL = wr * (avgW ** 2) + (1 - wr) * (avgL ** 2) - expectancy ** 2;
  const sdPL  = Math.sqrt(Math.max(varPL, 0));

  // Scale factor: if we have few trades, use a wider estimate
  const dsf = dataSufficiency(m.totalTrades);
  const sdPL_adj = sdPL * (2 - dsf);  // wider SD when data is thin

  // ── Trade frequency ───────────────────────────────────
  const tradesPerDay = m.tradesPerCalDay || (m.avgPerTradingDay * 0.7);

  // ── Daily P&L expectation and volatility ─────────────
  const dailyExpectancy = expectancy * tradesPerDay;
  const dailySD         = sdPL_adj * Math.sqrt(tradesPerDay);

  // ── Lot escalation dynamics ───────────────────────────
  const L = b.lotEscalation;
  const lotEscalationPerLoss = L.escalationRate / 100;  // probability of escalating after a loss
  const avgEscMult           = L.avgMultiplier || 1.0;
  const avgLot               = L.avgLot || 1.0;
  const lossProb             = 1 - wr;

  // ── Drawdown dynamics ─────────────────────────────────
  const currentDD    = m.maxRelDD;
  const recoveryRate = m.recoveryFactor !== null && m.recoveryFactor > 0
    ? Math.min(m.recoveryFactor, 5.0)  // cap at 5 to avoid unrealistic recovery
    : 0.3;

  // ── Behaviour deterioration probabilities ─────────────
  // P(revenge trade within 5 min after loss)
  const revengeProbPerLoss = b.recoveryBehaviour.immediateReentryRate / 100;
  // Marginal win rate on revenge trades (vs baseline)
  const revengeWRDelta = b.recoveryBehaviour.postLossWinRate !== null
    ? (b.recoveryBehaviour.postLossWinRate - b.recoveryBehaviour.baselineWinRate) / 100
    : -0.12;

  // ── Daily hazard from failure engine ─────────────────
  const dailyHazardRate = fa.dailyHazardInfo?.daily ?? fa.failureProbability?.dailyHazardRate ?? 0.003;

  // ── Session performance differential ──────────────────
  const bestSess  = s.bestKey  ? s.sessions[s.bestKey]  : null;
  const worstSess = s.worstKey ? s.sessions[s.worstKey] : null;

  const sessionPFBonus = bestSess?.profitFactor && bestSess.profitFactor < 10
    ? bestSess.profitFactor - m.profitFactor
    : 0;
  const sessionPFDrag  = worstSess?.profitFactor
    ? m.profitFactor - worstSess.profitFactor
    : 0;

  // ── Improvement multipliers (for counterfactual) ──────
  // If escalation removed: lot becomes consistent → PF improves approx by:
  //   1 + escalationRate/100 * (avgMult - 1) * 0.3  (conservative estimate)
  const pfGainFromNoEscalation = 1 + (L.escalationRate / 100) * (avgEscMult - 1) * 0.30;
  // If worst session removed:
  const pfGainFromBestSession = worstSess && m.totalTrades > 0
    ? 1 + Math.max(0, sessionPFDrag) * (worstSess.count / m.totalTrades)
    : 1.0;
  // If revenge trading eliminated:
  const pfGainFromNoRevenge = b.recoveryBehaviour.revengeDetected
    ? 1 + Math.abs(revengeWRDelta) * revengeProbPerLoss * 0.5
    : 1.0;

  return {
    cur, expectancy, sdPL, sdPL_adj, dsf,
    tradesPerDay, dailyExpectancy, dailySD,
    lotEscalationPerLoss, avgEscMult, avgLot, lossProb, wr,
    avgWin: avgW, avgLoss: avgL,
    currentDD, recoveryRate,
    revengeProbPerLoss, revengeWRDelta,
    dailyHazardRate,
    bestSess, worstSess, sessionPFBonus, sessionPFDrag,
    pfGainFromNoEscalation, pfGainFromBestSession, pfGainFromNoRevenge,
    profitFactor: m.profitFactor,
  };
}

/* ═══════════════════════════════════════════════════════════
   MODULE 1 — SURVIVAL FORECAST
   Outputs a survival curve with central estimate + CI band
   at daily resolution for 0–365 days.
   Also outputs key milestones: days to 25/50/75% survival.
═══════════════════════════════════════════════════════════ */
function computeSurvivalForecast(m, fa, params) {
  const { dailyHazardRate, dsf } = params;

  // Base survival curve: S(t) = (1 - h)^t
  const DAYS = [1, 7, 14, 30, 60, 90, 120, 180, 270, 365];
  const central = DAYS.map(t => ({
    day:   t,
    prob:  round2(survival(dailyHazardRate, t) * 100),
  }));

  // Confidence band: uncertainty in hazard rate
  // CI width scales inversely with data sufficiency
  const hazardUncertainty = dailyHazardRate * (0.6 * (1 - dsf) + 0.15);
  const hLow  = Math.max(dailyHazardRate - hazardUncertainty, 0.00001);
  const hHigh = dailyHazardRate + hazardUncertainty;

  const band = DAYS.map(t => ({
    day:      t,
    low:      round2(survival(hHigh, t) * 100),   // pessimistic h → lower survival
    central:  round2(survival(dailyHazardRate, t) * 100),
    high:     round2(survival(hLow, t) * 100),     // optimistic h → higher survival
  }));

  // Key milestones: day when survival crosses 75%, 50%, 25%
  function dayForSurvival(target) {
    if (dailyHazardRate <= 0) return null;
    const t = Math.log(target / 100) / Math.log(1 - dailyHazardRate);
    return Math.round(t);
  }

  const milestones = {
    p75: dayForSurvival(75),
    p50: dayForSurvival(50),
    p25: dayForSurvival(25),
  };

  // Current survival probabilities from failure engine
  const current = {
    p30:  fa.failureProbability.p30,
    p90:  fa.failureProbability.p90,
    p180: fa.failureProbability.p180,
    survivalScore: fa.survivalScore,
  };

  // Trajectory label
  const p90surv = survival(dailyHazardRate, 90) * 100;
  const trajectory = p90surv >= 85 ? 'Stable'
    : p90surv >= 65 ? 'Moderate Concern'
    : p90surv >= 40 ? 'High Risk'
    : 'Critical Trajectory';

  return {
    current,
    curve:       central,
    confidenceBand: band,
    milestones,
    dailyHazardRate: round2(dailyHazardRate * 10000) / 10000,  // 4 sig figs
    hazardUncertainty: round2(hazardUncertainty * 10000) / 10000,
    trajectory,
    dataConfidence: round2(dsf * 100),
    interpretation: {
      summary: `At the current daily hazard rate of ${(dailyHazardRate * 100).toFixed(4)}%/day, `
        + `the account has a ${round2(survival(dailyHazardRate, 90) * 100)}% probability of surviving the next 90 days `
        + `and a ${round2(survival(dailyHazardRate, 365) * 100)}% probability of surviving the next 365 days.`,
      milestonesDesc: milestones.p50
        ? `Median account lifespan at current trajectory: ~${milestones.p50} days.`
        : 'Account has >50% survival probability beyond the 1-year forecast horizon.',
    },
  };
}

/* ═══════════════════════════════════════════════════════════
   MODULE 2 — RISK FORECAST
   Projects: drawdown trajectory, Value-at-Risk, lot escalation,
   worst-case single session loss, maximum consecutive loss risk.
═══════════════════════════════════════════════════════════ */
function computeRiskForecast(m, b, r, params, rng) {
  const {
    dailySD, expectancy, tradesPerDay, avgLot, avgEscMult,
    lotEscalationPerLoss, lossProb, currentDD, avgWin, avgLoss,
  } = params;

  const cur = m.currency || '';

  // ── Drawdown projection ───────────────────────────────
  // Current drawdown + expected incremental drawdown
  // Incremental DD over N days ≈ max adverse run from the P&L process.
  // E[max drawdown over N trades] ≈ sdPL * sqrt(N) * 1.58 (known constant for GBM)
  const tradesIn90  = Math.round(tradesPerDay * 90);
  const tradesIn180 = Math.round(tradesPerDay * 180);

  // Max drawdown estimator for geometric random walk:
  //   E[MaxDD(N)] ≈ σ_trade * sqrt(N) * sqrt(2 * ln(N)) / sqrt(N) = σ * sqrt(2 ln N)
  //   (Bachelier-Chernoff approximation, valid for N >> 1)
  const sdTrade = params.sdPL_adj;
  const expectedDDAdd90  = sdTrade > 0 && tradesIn90 > 1
    ? sdTrade * Math.sqrt(2 * Math.log(tradesIn90))
    : 0;
  const expectedDDAdd180 = sdTrade > 0 && tradesIn180 > 1
    ? sdTrade * Math.sqrt(2 * Math.log(tradesIn180))
    : 0;

  // Projected cumulative max drawdown (in currency)
  const currentAbsDD   = m.maxAbsDD || 0;
  const projected90DD  = round2(currentAbsDD + expectedDDAdd90 * (m.profitFactor < 1 ? 1.4 : 0.7));
  const projected180DD = round2(currentAbsDD + expectedDDAdd180 * (m.profitFactor < 1 ? 1.5 : 0.75));

  // ── Value at Risk (1-day, 5% tail) ────────────────────
  // VaR = worst expected loss on a single day at 5% confidence
  // For daily P&L ~ N(μ_daily, σ_daily):
  //   VaR_5% = -(μ_daily - 1.645 * σ_daily)
  const VaR1D = round2(Math.max(0, -(params.dailyExpectancy - 1.645 * params.dailySD)));
  const CVaR1D = round2(Math.max(0, VaR1D * 1.35));  // Expected Shortfall ≈ 1.35 × VaR for Gaussian

  // ── Lot escalation trajectory ─────────────────────────
  // If martingale is present: how many consecutive losses before a given lot multiple?
  // Lot after k consecutive losses = avgLot * avgEscMult^k
  const mc = b.lotEscalation.martingaleConf;
  const escTrajectory = [];
  if (mc > 25) {
    for (let k = 1; k <= 8; k++) {
      const lotAtK    = round2(avgLot * Math.pow(avgEscMult, k));
      // P(k consecutive losses) = lossProb^k (with independence assumption)
      const probK     = round2(Math.pow(lossProb, k) * 100);
      // Expected loss at this point in currency
      const lossAtK   = round2(avgLoss * lotAtK / avgLot);
      // Cumulative loss of sequence up to this point
      const cumLoss   = round2(
        avgLoss * avgLot * (Math.pow(avgEscMult, k) - 1) / (avgEscMult - 1)
      );
      escTrajectory.push({ losses: k, lotSize: lotAtK, probPct: probK, singleLoss: lossAtK, cumulativeLoss: cumLoss });
    }
  }

  // ── Worst-case consecutive loss streak probability ────
  // P(streak of k or more in N trades) = 1 - (1 - lossProb^k)^(N - k + 1)
  // (Longest-run probability formula)
  function pStreakOfK(k, N) {
    if (N <= k) return round2(Math.pow(lossProb, k) * 100);
    const pNoStreakInWindow = Math.pow(1 - Math.pow(lossProb, k), N - k + 1);
    return round2(Math.max(0, Math.min(100, (1 - pNoStreakInWindow) * 100)));
  }

  const streakRisks = [5, 7, 10, 12, 15].map(k => ({
    consecutiveLosses: k,
    in90Days:  pStreakOfK(k, tradesIn90),
    in180Days: pStreakOfK(k, tradesIn180),
  }));

  // ── Maximum position exposure under escalation ────────
  // Worst realistic lot (90th percentile of max observed run so far)
  const maxLotObserved = b.lotEscalation.maxMultiplier
    ? round2(avgLot * b.lotEscalation.maxMultiplier)
    : round2(avgLot * 1.5);
  // Projected peak lot over 180 days (continuing escalation trend)
  const projectedPeakLot = mc > 50
    ? round2(maxLotObserved * Math.pow(avgEscMult, 2))  // 2 additional escalation levels
    : maxLotObserved;

  return {
    drawdownProjection: {
      currentMaxDD: round2(m.maxRelDD),
      currentAbsDD: round2(currentAbsDD),
      projected90DayAbsDD:  projected90DD,
      projected180DayAbsDD: projected180DD,
      note: m.profitFactor < 1
        ? 'Drawdown is expected to continue growing given negative expectancy'
        : 'Drawdown may stabilise if positive expectancy continues',
    },
    valueAtRisk: {
      VaR1D,
      CVaR1D,
      VaR5Day: round2(VaR1D * Math.sqrt(5)),
      VaR20Day: round2(VaR1D * Math.sqrt(20)),
      confidence: '95%',
      model: 'Gaussian daily P&L approximation — wider tails likely in practice',
    },
    lotEscalationTrajectory: escTrajectory,
    streakRisk: streakRisks,
    positionRisk: {
      currentAvgLot: round2(avgLot),
      maxLotObserved,
      projectedPeakLot,
      peakLotMultiple: round2(projectedPeakLot / avgLot),
    },
    riskRating: m.maxRelDD > 30 || mc > 65 ? 'EXTREME'
      : m.maxRelDD > 18 || mc > 40 ? 'HIGH'
      : m.maxRelDD > 10 ? 'MODERATE'
      : 'LOW',
  };
}

/* ═══════════════════════════════════════════════════════════
   MODULE 3 — PERFORMANCE FORECAST
   Monte Carlo simulation of 1,000 account equity paths.
   Returns: P&L distribution at 30/90/180 days,
            break-even probability, expected range.
═══════════════════════════════════════════════════════════ */
function computePerformanceForecast(m, params, rng) {
  const {
    dailyExpectancy, dailySD, tradesPerDay,
    lossProb, revengeProbPerLoss, revengeWRDelta,
    avgWin, avgLoss, lotEscalationPerLoss, avgEscMult, avgLot,
  } = params;

  const N_PATHS  = 1000;
  const HORIZONS = [30, 90, 180];

  // Simulate N_PATHS equity paths, each H days long
  // Each day: draw daily P&L from N(expectancy, sd), adjusted for behaviour
  const maxH = 180;
  const finalPLByHorizon = { 30: [], 90: [], 180: [] };
  const failureDay = [];  // which day (if any) did the path fail?

  // Failure threshold: account drops to -50% of peak cumulative P&L
  // If starting at 0, fail when cumPL < -0.5 * peakCumPL (for positive peaks)
  // Simplified: fail when daily loss pushes account into a drawdown > 50% of peak

  for (let p = 0; p < N_PATHS; p++) {
    let cumPL  = 0;
    let peak   = 0;
    let failed = false;
    let failedAt = null;

    for (let d = 1; d <= maxH; d++) {
      if (failed) break;

      // Daily P&L: Gaussian approximation
      // Adjust for revenge trading: on bad days, some trades are revenge trades
      // which have worse expectancy
      let dayExpect = dailyExpectancy;
      let daySD     = dailySD;

      // If yesterday was a loss day, apply revenge trading adjustment
      // (Implicit — we model it as a reduction in daily expectancy on some days)
      // P(revenge day) = revengeProbPerLoss * lossProb
      if (rng.trial(lossProb * revengeProbPerLoss)) {
        dayExpect += revengeWRDelta * avgWin * tradesPerDay * 0.3;
        daySD     *= 1.15;  // more variance on revenge days
      }

      // Generate daily P&L
      const dayPL = rng.nextGaussian(dayExpect, daySD);
      cumPL += dayPL;

      // Track peak
      if (cumPL > peak) peak = cumPL;

      // Failure condition: drawdown from peak > 50% (relative to starting capital)
      // Since we model in currency not %, use 50% of the peak as threshold
      // or if cumPL falls below -30% of initial equity (use avgLoss * 10 as proxy)
      const ddThreshold = peak > 0 ? peak * 0.5 : avgLoss * 15;
      if (peak - cumPL > ddThreshold || cumPL < -(avgLoss * 20)) {
        failed = true;
        failedAt = d;
      }

      // Record at horizons
      if (HORIZONS.includes(d)) {
        finalPLByHorizon[d].push(failed ? -(avgLoss * 20) : cumPL);
      }
    }

    failureDay.push(failedAt);
  }

  // ── Compute percentile distributions ─────────────────
  const pctTarget = [5, 10, 25, 50, 75, 90, 95];
  const distribution = {};
  HORIZONS.forEach(h => {
    const pcts = percentiles(finalPLByHorizon[h], pctTarget);
    distribution[h] = {
      p05: round2(pcts[0]),
      p10: round2(pcts[1]),
      p25: round2(pcts[2]),
      p50: round2(pcts[3]),  // median expected P&L
      p75: round2(pcts[4]),
      p90: round2(pcts[5]),
      p95: round2(pcts[6]),
      meanPL:       round2(finalPLByHorizon[h].reduce((s, v) => s + v, 0) / N_PATHS),
      probPositive: round2(finalPLByHorizon[h].filter(v => v > 0).length / N_PATHS * 100),
    };
  });

  // ── Break-even probability ────────────────────────────
  // P(net profitable after N days)
  // Analytically: P(cumPL > 0 after N days) = Φ(μ*N / (σ*sqrt(N))) = Φ(μ*sqrt(N) / σ)
  function breakEvenProb(days) {
    const mu = dailyExpectancy;
    const sigma = dailySD;
    if (sigma <= 0) return mu > 0 ? 100 : 0;
    const z = (mu * days) / (sigma * Math.sqrt(days));
    // Approximate Φ(z) using rational approximation (Abramowitz & Stegun)
    const absZ = Math.abs(z);
    const t_  = 1 / (1 + 0.2316419 * absZ);
    const poly = t_ * (0.319381530 + t_ * (-0.356563782 + t_ * (1.781477937 + t_ * (-1.821255978 + t_ * 1.330274429))));
    const phi  = 1 - (1 / Math.sqrt(2 * Math.PI)) * Math.exp(-absZ * absZ / 2) * poly;
    return round2((z >= 0 ? phi : 1 - phi) * 100);
  }

  // ── Expected P&L from analytical formula ─────────────
  // E[cumPL(N days)] = mu * N  (no compounding assumption)
  const analyticalExpected = {
    d30:  round2(dailyExpectancy * 30),
    d90:  round2(dailyExpectancy * 90),
    d180: round2(dailyExpectancy * 180),
    tradesIn30:  round2(tradesPerDay * 30),
    tradesIn90:  round2(tradesPerDay * 90),
    tradesIn180: round2(tradesPerDay * 180),
  };

  // ── Failure count from simulation ────────────────────
  const failCount90  = failureDay.filter(d => d !== null && d <= 90).length;
  const failCount180 = failureDay.filter(d => d !== null && d <= 180).length;

  return {
    monteCarloPaths: N_PATHS,
    distribution,
    breakEvenProbability: {
      in30Days:  breakEvenProb(30),
      in90Days:  breakEvenProb(90),
      in180Days: breakEvenProb(180),
      note: 'Probability that cumulative net P&L is positive at the stated horizon',
    },
    analyticalExpected,
    simulatedFailureRate: {
      within90Days:  round2(failCount90 / N_PATHS * 100),
      within180Days: round2(failCount180 / N_PATHS * 100),
    },
    performanceLabel: dailyExpectancy > 0 && m.profitFactor >= 1.3
      ? 'Positive Trajectory'
      : dailyExpectancy > 0
      ? 'Marginal Positive'
      : 'Negative Trajectory',
  };
}

/* ═══════════════════════════════════════════════════════════
   MODULE 4 — BEHAVIOUR FORECAST
   Projects how current behavioural patterns are likely to
   evolve, with and without intervention.
   Models: escalation acceleration, revenge frequency,
   frequency drift, consistency trend.
═══════════════════════════════════════════════════════════ */
function computeBehaviourForecast(m, b, r, id, fa, params) {
  const L   = b.lotEscalation;
  const O   = b.overtrading;
  const R   = b.recoveryBehaviour;

  // ── Escalation trajectory ─────────────────────────────
  // If not corrected, escalation rates tend to worsen under drawdown pressure.
  // Empirical observation: 30% of traders with escR > 30% increase it further.
  // We model a 3-scenario escalation trajectory.
  const escNow    = L.escalationRate;
  const escWorsen = L.martingaleConf > 40
    ? Math.min(100, escNow * 1.35)  // systematic martingale → worsens
    : Math.min(100, escNow * 1.15); // emotional → mild worsening
  const escStable = escNow;         // no change
  const escImprove = Math.max(0, escNow * 0.65);  // intervention

  // P(escalation rate worsens) from behaviour data
  const pWorsen = clamp(
    (L.martingaleConf / 100) * 0.45 +
    (R.revengeDetected ? 0.25 : 0) +
    (m.maxRelDD > 20 ? 0.15 : 0) +
    (m.netProfit < 0 ? 0.10 : 0)
  , 0, 0.85);
  const pImprove = clamp(
    (r.triggeredCount <= 2 ? 0.30 : 0.10) +
    (id.accountGrade === 'B' || id.accountGrade === 'B+' ? 0.15 : 0)
  , 0, 0.50);
  const pStable  = Math.max(0, 1 - pWorsen - pImprove);

  // ── Revenge trading frequency projection ──────────────
  // If the account continues on current trajectory, revenge trading frequency
  // is likely to increase during losing periods.
  // Model: immRateProjected = immRate * (1 + drawdownPressure * 0.5)
  const drawdownPressure = clamp(m.maxRelDD / 30, 0, 2);  // 0 = no DD, 2 = extreme DD
  const immRateNow       = R.immediateReentryRate;
  const immRateProjected = Math.min(100, immRateNow * (1 + drawdownPressure * 0.40));
  const immRateImproved  = immRateNow * 0.25;  // with 15-min rule

  // ── Frequency drift ────────────────────────────────────
  // Overtraders tend to increase frequency when losing (chasing losses).
  // Under-traders (low frequency) tend to be more stable.
  const freqNow = O.avgPerTradingDay;
  const freqDrift = m.netProfit < 0
    ? freqNow * 1.20   // losing accounts often increase frequency trying to recover
    : freqNow * 1.02;  // profitable accounts: slight drift

  // ── Lot consistency projection ─────────────────────────
  // If escalation worsens, CV will increase. Estimate future CV.
  const cvNow      = L.lotCV;
  const cvWorst    = round2(Math.min(cvNow * (1 + pWorsen * 0.6), 2.0));
  const cvBest     = round2(Math.max(cvNow * (1 - pImprove * 0.5), 0.05));

  // ── Martingale progression model ──────────────────────
  // If martingale is present, estimate the "critical sequence length"
  // at which the account will face a position it cannot fund.
  // CriticalK = log(accountEquity / avgLoss) / log(avgEscMult)
  // We approximate accountEquity from netProfit + expected initial balance
  // Using balance proxy = grossProfit + grossLossAbs (rough throughput measure)
  const equityProxy = Math.max(m.grossProfit + m.grossLossAbs, avgLoss => avgLoss) || 10000;
  const avgLossVal  = m.avgLoss || 50;
  const critK = L.avgMultiplier && L.avgMultiplier > 1
    ? Math.max(1, Math.log(equityProxy / avgLossVal) / Math.log(L.avgMultiplier))
    : null;

  // P(reaching critK consecutive losses in 90 days)
  const tradesIn90 = Math.round(params.tradesPerDay * 90);
  let pHitCrit90 = null;
  if (critK !== null) {
    const k = Math.ceil(critK);
    const pNoStreak = Math.pow(1 - Math.pow(params.lossProb, k), Math.max(1, tradesIn90 - k + 1));
    pHitCrit90 = round2(Math.max(0, Math.min(100, (1 - pNoStreak) * 100)));
  }

  // ── Behaviour label projection ─────────────────────────
  const currentBeh   = id.behaviourProfile;
  const hasImproving = fa.survivalScore >= 50 && r.triggeredCount <= 3;

  return {
    escalationForecast: {
      current:     round2(escNow),
      projected3Mo: round2(escNow * (1 + pWorsen * 0.35)),
      scenarioWorst:   round2(escWorsen),
      scenarioStable:  round2(escStable),
      scenarioBest:    round2(escImprove),
      probWorsen:      round2(pWorsen * 100),
      probStable:      round2(pStable * 100),
      probImprove:     round2(pImprove * 100),
    },
    revengeForecast: {
      currentImmediateReentryRate: round2(immRateNow),
      projectedWithoutChange:      round2(immRateProjected),
      projectedWithIntervention:   round2(immRateImproved),
      drawdownPressureFactor:      round2(drawdownPressure),
    },
    frequencyForecast: {
      currentAvgTradesPerDay: round2(freqNow),
      projectedTradesPerDay:  round2(freqDrift),
      interpretation: freqDrift > freqNow
        ? 'Trading frequency is projected to increase as account seeks to recover losses'
        : 'Trading frequency is projected to remain stable',
    },
    lotConsistencyForecast: {
      currentLotCV:   round2(cvNow * 100),
      worstCaseLotCV: round2(cvWorst * 100),
      bestCaseLotCV:  round2(cvBest * 100),
    },
    martingaleProgression: L.martingaleConf > 25 ? {
      avgMultiplier:           round2(L.avgMultiplier || 1),
      estimatedCriticalStreak: critK ? Math.ceil(critK) : null,
      probHittingCritIn90Days: pHitCrit90,
      interpretation: pHitCrit90 !== null
        ? `There is a ${pHitCrit90}% probability of encountering a ${Math.ceil(critK)}-trade losing streak in the next 90 days — a sequence at which lot sizes would reach unsustainable levels.`
        : 'Martingale risk is present but critical sequence probability cannot be precisely estimated from available data.',
    } : null,
    overallBehaviourTrajectory: hasImproving
      ? 'Moderate — some indicators suggest stabilisation is possible'
      : L.martingaleConf > 65 || R.revengeDetected
      ? 'Deteriorating — emotional and escalation patterns typically worsen under continued adverse conditions'
      : 'Stable — current patterns are unlikely to self-correct without deliberate intervention',
    currentProfile:   currentBeh,
    projectedProfile90Days: L.martingaleConf > 65
      ? 'Martingale Behaviour (accelerating)'
      : R.revengeDetected && m.netProfit < 0
      ? 'Revenge Trader (worsening under drawdown pressure)'
      : currentBeh,
  };
}

/* ═══════════════════════════════════════════════════════════
   MODULE 5 — IMPROVEMENT PROJECTION
   Counterfactual modelling: what would the forecast look like
   if specific identified problems were corrected?
   Three scenarios: Fix Top Issue, Fix Top 2 Issues, Ideal.
═══════════════════════════════════════════════════════════ */
function computeImprovementProjection(m, s, b, r, id, fa, params, rng) {
  const { pfGainFromNoEscalation, pfGainFromBestSession, pfGainFromNoRevenge,
          dailyHazardRate, dailyExpectancy, dailySD } = params;

  // ── Identify top 3 fixable issues ────────────────────
  const issues = [];

  if (b.lotEscalation.martingaleConf > 40 || b.lotEscalation.escalationRate > 25) {
    issues.push({
      issue:   'Lot Escalation / Martingale',
      ruleRef: 'B-001 / B-002',
      pfGain:  pfGainFromNoEscalation,
      hazardReduction: clamp(b.lotEscalation.martingaleConf > 65 ? 0.55 : 0.30),
      survivalGain: b.lotEscalation.martingaleConf > 65 ? 28 : 14,
      action: 'Switch to fixed 1% equity risk per trade. Remove all post-loss sizing adjustments.',
    });
  }
  if (s.worstKey && s.sessions[s.worstKey]?.netProfit < 0 && s.sessions[s.worstKey]?.count >= 10) {
    issues.push({
      issue:   `Eliminate ${s.worstKey} Session Trading`,
      ruleRef: 'S-001',
      pfGain:  pfGainFromBestSession,
      hazardReduction: clamp(0.20),
      survivalGain: 10,
      action: `Stop trading during the ${s.worstKey} session entirely. Restrict to ${s.bestKey || 'best performing'} session only.`,
    });
  }
  if (b.recoveryBehaviour.revengeDetected) {
    issues.push({
      issue:   'Revenge Trading',
      ruleRef: 'RC-001',
      pfGain:  pfGainFromNoRevenge,
      hazardReduction: clamp(0.25),
      survivalGain: 16,
      action: 'Implement mandatory 15-minute cool-down after every loss. No exceptions.',
    });
  }
  if (m.profitFactor < 1.2 && m.avgLoss && m.avgWin && m.avgLoss / m.avgWin > 1.5) {
    issues.push({
      issue:   'Inverse Risk Structure',
      ruleRef: 'R-002',
      pfGain:  1.25,
      hazardReduction: clamp(0.35),
      survivalGain: 20,
      action: 'Set minimum RRR of 1:1.5 on every entry. Never enter where potential loss exceeds potential reward by 50%.',
    });
  }

  // ── Scenario: Fix top issue only ─────────────────────
  function scenarioHazard(issueList) {
    let h = dailyHazardRate;
    issueList.forEach(iss => { h *= (1 - iss.hazardReduction); });
    return Math.max(h, 0.000005);
  }

  function scenarioPF(issueList) {
    let pf = m.profitFactor === Infinity ? 4.0 : m.profitFactor;
    issueList.forEach(iss => { pf *= iss.pfGain; });
    return Math.min(pf, 10);
  }

  function scenarioSurvival(issueList, days) {
    return round2(survival(scenarioHazard(issueList), days) * 100);
  }

  function scenarioBreakEven(adjustedExpectancy, days) {
    const mu = adjustedExpectancy * params.tradesPerDay;
    const sigma = params.dailySD;
    if (sigma <= 0) return mu > 0 ? 100 : 0;
    const z = (mu * days) / (sigma * Math.sqrt(days));
    const absZ = Math.abs(z);
    const t_ = 1 / (1 + 0.2316419 * absZ);
    const poly = t_ * (0.319381530 + t_ * (-0.356563782 + t_ * (1.781477937 + t_ * (-1.821255978 + t_ * 1.330274429))));
    const phi  = 1 - (1 / Math.sqrt(2 * Math.PI)) * Math.exp(-absZ * absZ / 2) * poly;
    return round2((z >= 0 ? phi : 1 - phi) * 100);
  }

  const top1 = issues.slice(0, 1);
  const top2 = issues.slice(0, 2);
  const top3 = issues.slice(0, 3);

  // Expected P&L improvement from fixing issues
  // Adjusted expectancy: proportional to PF gain
  function adjustedExpectancy(pfGain) {
    // If PF improves by X%, expectancy improves by ~X% of avgWin
    return params.expectancy * pfGain;
  }

  const scenarios = [
    {
      name:        'Current trajectory (no change)',
      issuesFixed: [],
      adjustedPF:     round2(m.profitFactor === Infinity ? 9.99 : m.profitFactor),
      adjustedHazard: round2(dailyHazardRate * 10000) / 10000,
      survival90:  round2(survival(dailyHazardRate, 90) * 100),
      survival365: round2(survival(dailyHazardRate, 365) * 100),
      p30Fail: fa.failureProbability.p30,
      p90Fail: fa.failureProbability.p90,
      breakEven90: scenarioBreakEven(params.expectancy, 90),
      survivalScore: fa.survivalScore,
      expectedPL90: round2(params.dailyExpectancy * 90),
    },
    {
      name:        `Fix 1: ${issues[0]?.issue || 'No issue identified'}`,
      issuesFixed: top1.map(i => i.issue),
      adjustedPF:     round2(scenarioPF(top1)),
      adjustedHazard: round2(scenarioHazard(top1) * 10000) / 10000,
      survival90:  scenarioSurvival(top1, 90),
      survival365: scenarioSurvival(top1, 365),
      p90Fail:     round2((1 - scenarioSurvival(top1, 90) / 100) * 100),
      breakEven90: scenarioBreakEven(adjustedExpectancy(scenarioPF(top1) / Math.max(m.profitFactor, 0.01)), 90),
      survivalScore: clamp(fa.survivalScore + (issues[0]?.survivalGain || 0)),
      expectedPL90: round2(adjustedExpectancy(scenarioPF(top1) / Math.max(m.profitFactor, 0.01)) * params.tradesPerDay * 90),
    },
    {
      name:        `Fix 2: + ${issues[1]?.issue || 'No second issue'}`,
      issuesFixed: top2.map(i => i.issue),
      adjustedPF:     round2(scenarioPF(top2)),
      adjustedHazard: round2(scenarioHazard(top2) * 10000) / 10000,
      survival90:  scenarioSurvival(top2, 90),
      survival365: scenarioSurvival(top2, 365),
      p90Fail:     round2((1 - scenarioSurvival(top2, 90) / 100) * 100),
      breakEven90: scenarioBreakEven(adjustedExpectancy(scenarioPF(top2) / Math.max(m.profitFactor, 0.01)), 90),
      survivalScore: clamp(fa.survivalScore + top2.reduce((s, i) => s + i.survivalGain, 0)),
      expectedPL90: round2(adjustedExpectancy(scenarioPF(top2) / Math.max(m.profitFactor, 0.01)) * params.tradesPerDay * 90),
    },
    {
      name:        `Fix 3: + ${issues[2]?.issue || 'Full correction'}`,
      issuesFixed: top3.map(i => i.issue),
      adjustedPF:     round2(scenarioPF(top3)),
      adjustedHazard: round2(scenarioHazard(top3) * 10000) / 10000,
      survival90:  scenarioSurvival(top3, 90),
      survival365: scenarioSurvival(top3, 365),
      p90Fail:     round2((1 - scenarioSurvival(top3, 90) / 100) * 100),
      breakEven90: scenarioBreakEven(adjustedExpectancy(scenarioPF(top3) / Math.max(m.profitFactor, 0.01)), 90),
      survivalScore: clamp(fa.survivalScore + top3.reduce((s, i) => s + i.survivalGain, 0)),
      expectedPL90: round2(adjustedExpectancy(scenarioPF(top3) / Math.max(m.profitFactor, 0.01)) * params.tradesPerDay * 90),
    },
  ];

  // ── Minimum viable performance threshold ─────────────
  // What PF is required for this account to have >50% 90-day survival?
  // S(90) = (1-h)^90 = 0.5 → h = 1 - 0.5^(1/90) = 0.00770...
  // Then reverse-engineer: what adjustment brings h to 0.00770?
  const targetH     = 1 - Math.pow(0.5, 1 / 90);  // h that gives 50% 90-day survival
  const currentH    = dailyHazardRate;
  const reductionNeeded = currentH > targetH ? 1 - targetH / currentH : 0;
  const pfNeededFor50SurvivalAt90 = round2(
    (m.profitFactor === Infinity ? 9.99 : m.profitFactor) * (1 + reductionNeeded * 0.5)
  );

  return {
    identifiedIssues: issues,
    scenarios,
    minimumViable: {
      targetSurvival90:  50,
      currentSurvival90: round2(survival(dailyHazardRate, 90) * 100),
      hazardReductionNeeded: round2(reductionNeeded * 100),
      pfNeededFor50SurvivalAt90,
      interpretation: reductionNeeded > 0
        ? `To achieve 50% 90-day survival probability, the account hazard rate must decrease by ${round2(reductionNeeded * 100)}%. This requires an estimated profit factor of at least ${pfNeededFor50SurvivalAt90}.`
        : 'Account already exceeds the 50% 90-day survival threshold.',
    },
    summary: {
      topIssue:          issues[0]?.issue || 'None identified',
      topAction:         issues[0]?.action || 'Maintain current discipline',
      survivalGainFix2:  top2.reduce((s, i) => s + i.survivalGain, 0),
      p90FailReductionFix2: fa.failureProbability.p90 - (scenarios[2]?.p90Fail || fa.failureProbability.p90),
    },
  };
}

/* ─────────────────────────────────────────────────────────
   MAIN ENTRY POINT
───────────────────────────────────────────────────────── */

/**
 * Run the full KAVOX Predictive Engine™ v1 forecast.
 *
 * @param {object} m   MetricsResult
 * @param {object} s   SessionAnalytics
 * @param {object} b   BehaviourAnalytics
 * @param {object} r   DiagnosisResult
 * @param {object} id  TraderIdentity
 * @param {object} bi  BrokerIntelligence
 * @param {object} fa  FailureAnalysis
 * @returns {KavoxForecast}
 */
function runKavoxPredictiveEngine(m, s, b, r, id, bi, fa) {

  /* ── Build seed and RNG ─────────────────────────────── */
  const seed = buildSeed(m, b);
  const rng  = createRNG(seed);

  /* ── Extract simulation parameters ─────────────────── */
  const params = extractParams(m, s, b, r, id, bi, fa);

  /* ── Run all 5 forecast modules ─────────────────────── */
  const survivalForecast      = computeSurvivalForecast(m, fa, params);
  const riskForecast          = computeRiskForecast(m, b, r, params, rng);
  const performanceForecast   = computePerformanceForecast(m, params, rng);
  const behaviourForecast     = computeBehaviourForecast(m, b, r, id, fa, params);
  const improvementProjection = computeImprovementProjection(m, s, b, r, id, fa, params, rng);

  /* ── Forecast confidence score ───────────────────────── */
  const dsf = params.dsf;
  const forecastConfidence = clamp(Math.round(
    dsf * 60                                         +  // data quality: max 60 pts
    (r.triggeredCount > 0 ? 20 : 10)                +  // rules evidence: max 20 pts
    (m.calDays >= 90 ? 15 : m.calDays >= 30 ? 8 : 3) + // time range: max 15 pts
    (m.avgHoldMs ? 5 : 0)                              // hold time data: max 5 pts
  ), 12, 95);

  /* ── Top-level forecast summary ─────────────────────── */
  const threeMoOutlook = (() => {
    const p90fail = fa.failureProbability.p90;
    const pPos    = performanceForecast.breakEvenProbability.in90Days;
    if      (p90fail <= 10 && pPos >= 65)  return 'Strong positive trajectory — continue current approach';
    else if (p90fail <= 25 && pPos >= 50)  return 'Stable — moderate improvement opportunity identified';
    else if (p90fail <= 45)                return 'Cautionary — structural issues require attention within 30 days';
    else if (p90fail <= 65)                return 'High risk — immediate corrective action required';
    else                                   return 'Critical — account is on a depletion trajectory';
  })();

  /* ── Assemble and return full forecast ───────────────── */
  return {

    /* ── Metadata ────────────────────────────────────── */
    engineVersion:    'KAVOX Predictive Engine™ v1',
    forecastDate:     new Date().toISOString().split('T')[0],
    seed,
    monteCarloPaths:  performanceForecast.monteCarloPaths,
    forecastConfidence,
    dataPoints:       m.totalTrades,
    forecastHorizon:  '180 days',
    currency:         m.currency,
    threeMoOutlook,

    /* ── Forecast modules ────────────────────────────── */
    survivalForecast,
    riskForecast,
    performanceForecast,
    behaviourForecast,
    improvementProjection,

    /* ── Key forecast numbers (top-level summary) ──── */
    keyForecasts: {
      survival90Days:          survivalForecast.current.p30 ? (100 - fa.failureProbability.p90) : null,
      expectedPL90Days:        performanceForecast.analyticalExpected.d90,
      medianPL90Days:          performanceForecast.distribution[90]?.p50,
      worstCasePL90Days:       performanceForecast.distribution[90]?.p05,
      bestCasePL90Days:        performanceForecast.distribution[90]?.p95,
      probPositive90Days:      performanceForecast.breakEvenProbability.in90Days,
      survivalScore:           fa.survivalScore,
      projectedFailure90Days:  fa.failureProbability.p90,
      topImprovementAction:    improvementProjection.summary.topAction,
      survivalGainIfFixed:     improvementProjection.summary.survivalGainFix2,
    },

    /* ── Simulation parameters (fully traceable) ───── */
    simulationParams: {
      seed,
      dailyExpectancy:      round2(params.dailyExpectancy),
      dailySD:              round2(params.dailySD),
      tradesPerDay:         round2(params.tradesPerDay),
      expectancyPerTrade:   round2(params.expectancy),
      sdPerTrade:           round2(params.sdPL_adj),
      dailyHazardRate:      survivalForecast.dailyHazardRate,
      dataSufficiency:      round2(params.dsf * 100),
      winRate:              round2(params.wr * 100),
      lossProb:             round2(params.lossProb * 100),
      avgWin:               round2(params.avgWin),
      avgLoss:              round2(params.avgLoss),
      lotEscalationPerLoss: round2(params.lotEscalationPerLoss * 100),
      avgEscMultiplier:     round2(params.avgEscMult),
      revengeProbPerLoss:   round2(params.revengeProbPerLoss * 100),
    },
  };
}

/* ─────────────────────────────────────────────────────────
   EXPORTS
───────────────────────────────────────────────────────── */

/* ═══ validationEngine.js ═══ */
/* ═══════════════════════════════════════════════════════════
   DataLB Validation Engine v1

   Inputs:
     m   — MetricsResult        from datalb_metrics_v2
     s   — SessionAnalytics     from datalb_session_engine_v1
     b   — BehaviourAnalytics   from datalb_behaviour_engine_v1
     r   — DiagnosisResult      from datalb_rules_engine_v1
     id  — TraderIdentity       from datalb_identity_engine_v1
     bi  — BrokerIntelligence   from datalb_broker_intelligence_v1
     fa  — FailureAnalysis      from datalb_failure_engine_v2
     fcast — KavoxForecast      from datalb_kavox_predictive_v1
            (optional — pass null if not available)

   Outputs: ValidationResult object
     - validationScore       0–100 (pipeline health)
     - warnings              array of non-critical issues
     - contradictions        array of logical conflicts
     - engineHealth          per-engine status objects
     - confidenceAdjustment  % to apply to downstream confidence scores
     - missingData           fields that could not be populated
     - internalConsistency   arithmetic cross-checks

   ─────────────────────────────────────────────────────────
   Validation philosophy:
     Three tiers of finding severity:
       CRITICAL  — logical impossibility or arithmetic failure.
                   The affected engine output cannot be trusted.
       WARNING   — plausible but suspicious signal. Downstream
                   consumers should note reduced confidence.
       INFO      — data quality note with no impact on outputs.

     Contradictions are cross-engine conflicts.
     Warnings can be within a single engine.
     Missing data reduces confidence but does not invalidate.

     The validationScore is a deductive score (starts at 100),
     not an inductive score. Points are deducted for each
     finding. The score represents pipeline trust, not
     trading quality.
═══════════════════════════════════════════════════════════ */
/* ─────────────────────────────────────────────────────────
   UTILITIES
───────────────────────────────────────────────────────── */
const round2 = v => Math.round(v * 100) / 100;
const fmtP   = v => v == null ? '—' : `${Number(v).toFixed(1)}%`;
const fmtPF  = v => v == null ? '—' : v === Infinity ? '∞' : Number(v).toFixed(2);
const isNum  = v => v !== null && v !== undefined && !isNaN(v) && isFinite(v);
const isInf  = v => v === Infinity || v === -Infinity;

let _findingId = 0;
function finding(severity, code, engine, message, expected, actual, deduction) {
  return {
    id:         ++_findingId,
    severity,                   // 'CRITICAL' | 'WARNING' | 'INFO'
    code,                       // machine-readable identifier
    engine,                     // which engine(s) are involved
    message,                    // human description
    expected:   expected ?? null,
    actual:     actual   ?? null,
    deduction:  deduction ?? (severity === 'CRITICAL' ? 15 : severity === 'WARNING' ? 5 : 1),
  };
}

// Reset ID counter on each run (important for repeated calls)
function resetIdCounter() { _findingId = 0; }

/* ─────────────────────────────────────────────────────────
   SECTION 1 — INTERNAL ARITHMETIC CONSISTENCY
   Verify that the Metrics Engine's own calculations are
   internally coherent. These checks catch parser or
   computation bugs before they propagate.
───────────────────────────────────────────────────────── */
function checkInternalArithmetic(m) {
  const findings = [];
  const tol = 0.02; // 2% tolerance for floating-point rounding

  // 1.1 Net profit = gross profit - gross loss
  if (isNum(m.netProfit) && isNum(m.grossProfit) && isNum(m.grossLossAbs)) {
    const expected = round2(m.grossProfit - m.grossLossAbs);
    const delta    = Math.abs(m.netProfit - expected);
    if (delta > Math.max(1, Math.abs(expected) * tol)) {
      findings.push(finding('CRITICAL', 'ARITH_NET_PROFIT', 'Metrics',
        `Net profit arithmetic mismatch: grossProfit − grossLoss ≠ netProfit`,
        expected, round2(m.netProfit), 15));
    }
  }

  // 1.2 Profit Factor = |grossProfit / grossLoss|
  if (isNum(m.profitFactor) && !isInf(m.profitFactor) && m.grossLossAbs > 0 && m.grossProfit > 0) {
    const expectedPF = round2(m.grossProfit / m.grossLossAbs);
    const deltaPF    = Math.abs(m.profitFactor - expectedPF);
    if (deltaPF > 0.05 + expectedPF * tol) {
      findings.push(finding('CRITICAL', 'ARITH_PROFIT_FACTOR', 'Metrics',
        `Profit factor arithmetic mismatch: grossProfit/grossLoss should be ${expectedPF}, got ${fmtPF(m.profitFactor)}`,
        expectedPF, round2(m.profitFactor), 15));
    }
  }

  // 1.3 Win rate = winningTrades / totalTrades × 100
  if (isNum(m.winRate) && isNum(m.winningTrades) && isNum(m.totalTrades) && m.totalTrades > 0) {
    const expectedWR = round2(m.winningTrades / m.totalTrades * 100);
    if (Math.abs(m.winRate - expectedWR) > 0.5) {
      findings.push(finding('CRITICAL', 'ARITH_WIN_RATE', 'Metrics',
        `Win rate arithmetic mismatch: ${m.winningTrades}/${m.totalTrades}×100 ≠ ${fmtP(m.winRate)}`,
        expectedWR, round2(m.winRate), 10));
    }
  }

  // 1.4 Winners + losers should not exceed totalTrades
  if (isNum(m.winningTrades) && isNum(m.losingTrades) && isNum(m.totalTrades)) {
    if (m.winningTrades + m.losingTrades > m.totalTrades + 1) {
      findings.push(finding('CRITICAL', 'ARITH_TRADE_COUNT', 'Metrics',
        `Winners (${m.winningTrades}) + losers (${m.losingTrades}) exceeds total trades (${m.totalTrades})`,
        `≤ ${m.totalTrades}`, m.winningTrades + m.losingTrades, 15));
    }
  }

  // 1.5 Recovery factor = netProfit / maxAbsDD
  if (isNum(m.recoveryFactor) && isNum(m.maxAbsDD) && m.maxAbsDD > 0 && isNum(m.netProfit)) {
    const expectedRF = round2(m.netProfit / m.maxAbsDD);
    if (Math.abs(m.recoveryFactor - expectedRF) > 0.05 + Math.abs(expectedRF) * tol) {
      findings.push(finding('WARNING', 'ARITH_RECOVERY_FACTOR', 'Metrics',
        `Recovery factor arithmetic mismatch: netProfit/maxAbsDD = ${expectedRF}, reported ${round2(m.recoveryFactor)}`,
        expectedRF, round2(m.recoveryFactor), 5));
    }
  }

  // 1.6 Max drawdown vs absolute drawdown relationship
  if (isNum(m.maxRelDD) && isNum(m.maxAbsDD) && m.maxAbsDD > 0 && m.grossProfit > 0) {
    // maxRelDD% should be plausible relative to the gross P&L magnitude
    const plScale = m.grossProfit + m.grossLossAbs;
    const impliedDD = plScale > 0 ? m.maxAbsDD / plScale * 100 : null;
    if (impliedDD !== null && m.maxRelDD > 100) {
      findings.push(finding('CRITICAL', 'ARITH_DRAWDOWN_RANGE', 'Metrics',
        `Max relative drawdown ${fmtP(m.maxRelDD)} is impossible (>100%)`,
        '0–100%', fmtP(m.maxRelDD), 15));
    }
  }

  return findings;
}

/* ─────────────────────────────────────────────────────────
   SECTION 2 — SESSION ENGINE CONSISTENCY
───────────────────────────────────────────────────────── */
function checkSessionConsistency(m, s) {
  const findings = [];
  if (!s || !s.sessions) return findings;

  const SESS_KEYS = ['Asia','London','NewYork','After'];

  // 2.1 Session trade counts should sum to ≤ totalTrades
  const sessionTotal = SESS_KEYS.reduce((sum, k) => sum + (s.sessions[k]?.count || 0), 0);
  if (sessionTotal > m.totalTrades + 1) {
    findings.push(finding('CRITICAL', 'SESSION_COUNT_OVERFLOW', 'Sessions',
      `Session trade counts sum to ${sessionTotal}, exceeding total trades ${m.totalTrades}`,
      `≤ ${m.totalTrades}`, sessionTotal, 12));
  }

  // 2.2 Unclassified trades: if sessionTotal is significantly less than totalTrades
  const unclassified = m.totalTrades - sessionTotal;
  if (unclassified > m.totalTrades * 0.25 && m.totalTrades >= 20) {
    findings.push(finding('WARNING', 'SESSION_UNCLASSIFIED_TRADES', 'Sessions',
      `${unclassified} trades (${fmtP(unclassified/m.totalTrades*100)}) could not be assigned to a session — broker timestamp offset may be misconfigured`,
      `< ${Math.round(m.totalTrades * 0.10)} unclassified`, unclassified, 5));
  }

  // 2.3 Session net P&L sum should approximate overall net P&L
  const sessionNetPL = SESS_KEYS.reduce((sum, k) => sum + (s.sessions[k]?.netProfit || 0), 0);
  if (isNum(m.netProfit) && Math.abs(sessionNetPL - m.netProfit) > Math.abs(m.netProfit) * 0.15 + 10) {
    findings.push(finding('WARNING', 'SESSION_PL_DISCREPANCY', 'Sessions',
      `Session net P&L sum (${round2(sessionNetPL)} ${m.currency}) differs from overall net P&L (${round2(m.netProfit)} ${m.currency}) by more than 15%`,
      round2(m.netProfit), round2(sessionNetPL), 5));
  }

  // 2.4 No sessions with data — timezone issue
  const hasAnySessData = SESS_KEYS.some(k => s.sessions[k]?.count >= 5);
  if (!hasAnySessData && m.totalTrades >= 20) {
    findings.push(finding('WARNING', 'SESSION_NO_VALID_DATA', 'Sessions',
      'No session has ≥5 trades — session analysis is statistically unreliable. Verify broker timezone offset (default is UTC+2)',
      'At least one session with ≥5 trades', 0, 4));
  }

  return findings;
}

/* ─────────────────────────────────────────────────────────
   SECTION 3 — BEHAVIOUR ENGINE CONSISTENCY
───────────────────────────────────────────────────────── */
function checkBehaviourConsistency(m, b) {
  const findings = [];
  if (!b) return findings;

  const L = b.lotEscalation;
  const O = b.overtrading;
  const R = b.recoveryBehaviour;
  const H = b.holdingBehaviour;

  // 3.1 Escalation count cannot exceed loss count
  if (isNum(L.escalationRate) && isNum(L.lossCount)) {
    const impliedCount = Math.round(L.escalationRate / 100 * L.lossCount);
    if (impliedCount > L.lossCount + 1) {
      findings.push(finding('CRITICAL', 'BEH_ESC_OVERFLOW', 'Behaviour',
        `Escalation rate ${fmtP(L.escalationRate)} implies ${impliedCount} escalations from only ${L.lossCount} losses`,
        `≤ ${L.lossCount}`, impliedCount, 10));
    }
  }

  // 3.2 Martingale confidence vs escalation rate consistency
  if (L.martingaleConf > 80 && L.escalationRate < 15) {
    findings.push(finding('WARNING', 'BEH_MARTINGALE_ESC_MISMATCH', 'Behaviour',
      `Martingale confidence ${L.martingaleConf}/100 is very high but escalation rate is only ${fmtP(L.escalationRate)} — these should be strongly correlated`,
      'Escalation rate > 30% when martingale confidence > 80', fmtP(L.escalationRate), 5));
  }

  // 3.3 Hold ratio consistency with hold time values
  if (H.holdRatio !== null && H.avgHoldWin !== null && H.avgHoldLoss !== null && H.avgHoldLoss > 0) {
    const impliedRatio = round2(H.avgHoldWin / H.avgHoldLoss);
    if (Math.abs(H.holdRatio - impliedRatio) > 0.05) {
      findings.push(finding('WARNING', 'BEH_HOLD_RATIO_MISMATCH', 'Behaviour',
        `Hold ratio ${H.holdRatio.toFixed(2)} inconsistent with avgHoldWin/avgHoldLoss = ${impliedRatio}`,
        impliedRatio, H.holdRatio, 4));
    }
  }

  // 3.4 Post-loss win rate should be bounded [0, 100]
  if (R.postLossWinRate !== null && (R.postLossWinRate < 0 || R.postLossWinRate > 100)) {
    findings.push(finding('CRITICAL', 'BEH_PLW_OUT_OF_RANGE', 'Behaviour',
      `Post-loss win rate ${fmtP(R.postLossWinRate)} is outside [0, 100%]`,
      '0–100%', fmtP(R.postLossWinRate), 12));
  }

  // 3.5 Revenge detected requires minimum sample
  if (R.revengeDetected && R.postLossCount < 5) {
    findings.push(finding('WARNING', 'BEH_REVENGE_THIN_SAMPLE', 'Behaviour',
      `Revenge trading flagged from only ${R.postLossCount} post-loss observations — low statistical confidence`,
      'Minimum 10 post-loss observations for reliable revenge detection', R.postLossCount, 3));
  }

  // 3.6 Frequency score vs avg trades per day — calibration check
  const expectedFreqRange = O.avgPerTradingDay > 20 ? [75, 100]
    : O.avgPerTradingDay > 10 ? [60, 90]
    : O.avgPerTradingDay > 5  ? [35, 65]
    : O.avgPerTradingDay > 3  ? [15, 45]
    : [5, 30];
  if (O.frequencyScore < expectedFreqRange[0] - 10 || O.frequencyScore > expectedFreqRange[1] + 10) {
    findings.push(finding('WARNING', 'BEH_FREQ_SCORE_CALIBRATION', 'Behaviour',
      `Frequency score ${O.frequencyScore}/100 appears miscalibrated for ${O.avgPerTradingDay.toFixed(1)} trades/day — expected range ${expectedFreqRange[0]}–${expectedFreqRange[1]}`,
      `${expectedFreqRange[0]}–${expectedFreqRange[1]}`, O.frequencyScore, 3));
  }

  // 3.7 Lot CV vs avg lot — CV cannot exceed 2.0 in practice for live accounts
  if (L.lotCV > 3.0) {
    findings.push(finding('WARNING', 'BEH_LOT_CV_EXTREME', 'Behaviour',
      `Lot coefficient of variation ${fmtP(L.lotCV * 100)} is extremely high — may indicate data parsing issues (e.g., lots column misidentified)`,
      '< 300%', fmtP(L.lotCV * 100), 4));
  }

  return findings;
}

/* ─────────────────────────────────────────────────────────
   SECTION 4 — IDENTITY ENGINE CONSISTENCY
───────────────────────────────────────────────────────── */
function checkIdentityConsistency(m, b, id) {
  const findings = [];
  if (!id) return findings;

  const hold  = m.avgHoldMs;
  const tpd   = b.overtrading.avgPerTradingDay;
  const type  = id.traderTypeDetail?.primary || '';

  // 4.1 Scalper + long hold time
  if (type === 'Scalper' && hold && hold > 4 * 3600 * 1000) {
    const holdH = (hold / 3600000).toFixed(1);
    findings.push(finding('CRITICAL', 'ID_SCALPER_LONG_HOLD', 'Identity',
      `Classified as Scalper but average hold time is ${holdH}h — scalpers should hold <15 minutes`,
      '< 0.25h (15 min)', `${holdH}h`, 12));
  }

  // 4.2 Swing Trader + high daily frequency
  if ((type === 'SwingTrader' || type === 'PositionTrader') && tpd > 8) {
    findings.push(finding('WARNING', 'ID_SWING_HIGH_FREQ', 'Identity',
      `Classified as ${type.replace('Trader','')} Trader but ${tpd.toFixed(1)} trades/day is unusually high for this style`,
      '< 3 trades/day for swing/position style', round2(tpd), 5));
  }

  // 4.3 Position Trader + short hold time
  if (type === 'PositionTrader' && hold && hold < 24 * 3600 * 1000) {
    const holdH = (hold / 3600000).toFixed(1);
    findings.push(finding('WARNING', 'ID_POSITION_SHORT_HOLD', 'Identity',
      `Classified as Position Trader but average hold time is only ${holdH}h — position traders typically hold >10 days`,
      '> 240h (10 days)', `${holdH}h`, 5));
  }

  // 4.4 Martingale Trader classification vs actual martingale confidence
  if (type === 'MartingaleTrader' && b.lotEscalation.martingaleConf < 40) {
    findings.push(finding('WARNING', 'ID_MARTINGALE_LOW_CONF', 'Identity',
      `Classified as Martingale Trader but martingale confidence is only ${b.lotEscalation.martingaleConf}/100 — below the reliable threshold of 40`,
      'martingaleConf ≥ 65 for this classification', b.lotEscalation.martingaleConf, 5));
  }

  // 4.5 Gold Specialist + top symbol is not gold
  if (type === 'GoldSpecialist') {
    const topSym = (b.concentration.topSym?.sym || b.concentration.topSym?.symbol || '').toUpperCase();
    const isGold = ['XAUUSD','XAUEUR','GOLD','XAU'].some(g => topSym.includes(g));
    if (!isGold && topSym !== '') {
      findings.push(finding('CRITICAL', 'ID_GOLD_NO_GOLD', 'Identity',
        `Classified as Gold Specialist but top symbol is "${topSym}", not a gold instrument`,
        'XAUUSD, XAUEUR, GOLD, or XAU', topSym, 12));
    }
  }

  // 4.6 Confidence score range
  if (id.confidence > 100 || id.confidence < 0) {
    findings.push(finding('CRITICAL', 'ID_CONFIDENCE_OUT_OF_RANGE', 'Identity',
      `Identity confidence ${id.confidence} is outside [0, 100]`,
      '0–100', id.confidence, 10));
  }

  // 4.7 Disciplined Trader + confirmed revenge
  const beh = id.behaviourProfileDetail?.primary || id.behaviourProfile || '';
  if (beh === 'DisciplinedTrader' && b.recoveryBehaviour.revengeDetected) {
    findings.push(finding('CRITICAL', 'ID_DISCIPLINED_REVENGE', 'Identity ↔ Behaviour',
      `Behaviour profile is "Disciplined Trader" but revenge trading has been confirmed — these are mutually exclusive`,
      'revengeDetected = false for Disciplined classification', true, 15));
  }

  // 4.8 Account grade bounds check
  const validGrades = ['A+','A','A-','B+','B','B-','C+','C','D+','D','F'];
  if (!validGrades.includes(id.accountGrade)) {
    findings.push(finding('CRITICAL', 'ID_INVALID_GRADE', 'Identity',
      `Account grade "${id.accountGrade}" is not a valid grade`,
      validGrades.join(' | '), id.accountGrade, 10));
  }

  return findings;
}

/* ─────────────────────────────────────────────────────────
   SECTION 5 — CROSS-ENGINE CONTRADICTIONS
   These are the most important checks — they detect logical
   impossibilities that span multiple engine outputs.
───────────────────────────────────────────────────────── */
function checkCrossEngineContradictions(m, s, b, r, id, bi, fa) {
  const findings = [];
  if (!id || !fa || !bi) return findings;

  const grade = id.accountGrade;
  const fp90  = fa.failureProbability?.p90;
  const surv  = fa.survivalScore;
  const pf    = m.profitFactor;
  const dd    = m.maxRelDD;
  const mc    = b.lotEscalation.martingaleConf;
  const type  = id.traderTypeDetail?.primary || '';
  const risk  = id.riskProfileDetail?.primary || '';
  const beh   = id.behaviourProfileDetail?.primary || '';
  const routing = bi.recommendedRouting;
  const riskLabel = id.riskProfile;

  // 5.1 Grade A/A+ but high failure probability
  if ((grade === 'A+' || grade === 'A') && fp90 !== undefined && fp90 > 35) {
    findings.push(finding('CRITICAL', 'CONTRA_GRADE_A_HIGH_FAILURE', 'Identity ↔ Failure',
      `Account graded ${grade} (strong performance) but 90-day failure probability is ${fp90}% — Grade A should correspond to <15% 90-day failure`,
      `< 15% for Grade ${grade}`, `${fp90}%`, 15));
  }

  // 5.2 Grade F but low failure probability
  if (grade === 'F' && fp90 !== undefined && fp90 < 40) {
    findings.push(finding('CRITICAL', 'CONTRA_GRADE_F_LOW_FAILURE', 'Identity ↔ Failure',
      `Account graded F (critical) but 90-day failure probability is only ${fp90}% — Grade F should correspond to ≥55% 90-day failure`,
      '≥ 55%', `${fp90}%`, 15));
  }

  // 5.3 Grade A/A+ but survival score < 40
  if ((grade === 'A+' || grade === 'A') && isNum(surv) && surv < 40) {
    findings.push(finding('CRITICAL', 'CONTRA_GRADE_A_LOW_SURVIVAL', 'Identity ↔ Failure',
      `Account graded ${grade} but survival score is ${surv}/100 — these values are structurally inconsistent`,
      '> 65 for Grade A', surv, 15));
  }

  // 5.4 Survival score > 80 but 90-day failure > 60%
  if (isNum(surv) && surv > 80 && fp90 !== undefined && fp90 > 60) {
    findings.push(finding('CRITICAL', 'CONTRA_SURVIVAL_FAILURE_MISMATCH', 'Failure internal',
      `Survival score ${surv}/100 is strong but 90-day failure probability is ${fp90}% — these two metrics are mathematically inconsistent`,
      `Failure P90 < 30% when survival score > 80`, `${fp90}%`, 15));
  }

  // 5.5 PF > 2.0 but account is net negative
  if (pf >= 2.0 && m.netProfit < 0 && m.totalTrades >= 10) {
    findings.push(finding('CRITICAL', 'CONTRA_HIGH_PF_NET_NEGATIVE', 'Metrics internal',
      `Profit factor ${fmtPF(pf)} implies profitable system but net profit is ${round2(m.netProfit)} ${m.currency} — this combination is arithmetically impossible unless trades span multiple accounts`,
      'Net profit > 0 when PF ≥ 2.0 over ≥10 trades', `${round2(m.netProfit)} ${m.currency}`, 15));
  }

  // 5.6 Win rate > 85% but PF < 0.90
  if (m.winRate > 85 && pf < 0.90 && !isInf(pf) && m.totalTrades >= 20) {
    const minPFForWR = (m.winRate / 100) / (1 - m.winRate / 100); // break-even PF at this WR
    findings.push(finding('CRITICAL', 'CONTRA_HIGH_WR_LOW_PF', 'Metrics internal',
      `Win rate ${fmtP(m.winRate)} should mathematically support PF ≥ ${fmtPF(minPFForWR)} if losses match wins, but PF is ${fmtPF(pf)} — implies avg loss is extremely large relative to avg win`,
      `PF ≥ ${fmtPF(round2(minPFForWR * 0.5))} (conservative threshold)`, fmtPF(pf), 12));
  }

  // 5.7 Conservative Risk + extreme drawdown
  if (risk === 'Conservative' && dd > 20) {
    findings.push(finding('CRITICAL', 'CONTRA_CONSERVATIVE_HIGH_DD', 'Identity ↔ Metrics',
      `Risk profile "Conservative" requires max drawdown < 8%, but recorded drawdown is ${fmtP(dd)}`,
      '< 8%', fmtP(dd), 12));
  }

  // 5.8 Extreme Risk + Grade A or B+
  if (risk === 'ExtremeRisk' && ['A+','A','B+'].includes(grade)) {
    findings.push(finding('CRITICAL', 'CONTRA_EXTREME_RISK_HIGH_GRADE', 'Identity internal',
      `Risk profile "Extreme Risk" is incompatible with Grade ${grade} — identity engine grade cap should have applied`,
      'Grade ≤ C when risk profile is Extreme Risk', grade, 12));
  }

  // 5.9 Martingale Trader classified + A-Book routing
  if (type === 'MartingaleTrader' && routing === 'A-Book') {
    findings.push(finding('CRITICAL', 'CONTRA_MARTINGALE_ABOOK', 'Identity ↔ Broker',
      `Martingale Trader should never be routed to A-Book — martingale accounts are statistical B-book candidates`,
      'B-Book or Hybrid', 'A-Book', 15));
  }

  // 5.10 Grade A disciplined + B-Book routing (long-term profitable client misrouted)
  if ((grade === 'A+' || grade === 'A') && beh === 'DisciplinedTrader' && routing === 'B-Book') {
    findings.push(finding('WARNING', 'CONTRA_GRADE_A_BBOOK', 'Identity ↔ Broker',
      `Grade ${grade} Disciplined Trader routed to B-Book — this is a high-value, likely profitable client who should be A-booked to avoid conflict of interest`,
      'A-Book', 'B-Book', 8));
  }

  // 5.11 Conservative Risk + martingale confidence > 50
  if (risk === 'Conservative' && mc > 50) {
    findings.push(finding('CRITICAL', 'CONTRA_CONSERVATIVE_MARTINGALE', 'Identity ↔ Behaviour',
      `Risk profile "Conservative" is mutually exclusive with martingale confidence ${mc}/100 — martingale accounts should be classified Extreme Risk`,
      'Extreme Risk when martingaleConf > 50', riskLabel, 12));
  }

  // 5.12 Negative session P&L = "best session" contradiction
  if (s.bestKey && s.sessions[s.bestKey]?.netProfit < 0 && m.totalTrades >= 20) {
    const bp = s.sessions[s.bestKey];
    findings.push(finding('WARNING', 'CONTRA_BEST_SESSION_NEGATIVE', 'Sessions',
      `"Best session" (${s.bestKey}) has negative net P&L of ${round2(bp.netProfit)} ${m.currency} — if even the best session is negative, all sessions are loss-making`,
      '> 0', round2(bp.netProfit), 7));
  }

  // 5.13 Scalper classification + avg hold time > 1 hour
  if (type === 'Scalper' && m.avgHoldMs && m.avgHoldMs > 3600000) {
    const holdM = Math.round(m.avgHoldMs / 60000);
    findings.push(finding('CRITICAL', 'CONTRA_SCALPER_LONG_HOLD', 'Identity ↔ Metrics',
      `Classified as Scalper but average hold time is ${holdM} minutes — scalpers typically hold <15 minutes`,
      '< 15 min', `${holdM} min`, 12));
  }

  // 5.14 Risk-to-broker score mismatch with routing
  const rtb = bi.riskToBroker;
  if (rtb !== undefined) {
    if (rtb >= 75 && routing === 'B-Book') {
      findings.push(finding('WARNING', 'CONTRA_HIGH_RTB_BBOOK', 'Broker internal',
        `Risk-to-broker score ${rtb}/100 indicates a dangerous B-book account, yet routing recommendation is B-Book — this creates broker P&L exposure`,
        'A-Book when riskToBroker ≥ 75', 'B-Book', 7));
    }
    if (rtb <= 20 && routing === 'A-Book') {
      findings.push(finding('INFO', 'CONTRA_LOW_RTB_ABOOK', 'Broker internal',
        `Risk-to-broker score ${rtb}/100 is low (not dangerous to B-book) but account is routed A-Book — consider whether A-book costs are justified`,
        null, `RTB: ${rtb}/100`, 1));
    }
  }

  // 5.15 Improvement potential exceeds logical bounds
  if (fa.improvementPotential) {
    const imp = fa.improvementPotential;
    if (imp.survivalGain > 60) {
      findings.push(finding('WARNING', 'CONTRA_IMPLAUSIBLE_IMPROVEMENT', 'Failure',
        `Improvement potential survival gain of ${imp.survivalGain} points may be overstated — a single intervention rarely changes survival score by >40 points`,
        '≤ 40 point gain', imp.survivalGain, 3));
    }
  }

  // 5.16 Failure probability 30-day > 90-day (monotonicity violation)
  if (fp90 !== undefined && fa.failureProbability.p30 > fp90 + 2) {
    findings.push(finding('CRITICAL', 'CONTRA_FAILURE_MONOTONICITY', 'Failure internal',
      `30-day failure probability (${fa.failureProbability.p30}%) exceeds 90-day probability (${fp90}%) — cumulative failure probability must be monotonically non-decreasing`,
      'P30 ≤ P90', `P30=${fa.failureProbability.p30}% > P90=${fp90}%`, 15));
  }

  // 5.17 P180 < P90 (monotonicity violation)
  if (fa.failureProbability.p90 > fa.failureProbability.p180 + 2) {
    findings.push(finding('CRITICAL', 'CONTRA_FAILURE_MONOTONICITY_180', 'Failure internal',
      `90-day failure probability (${fa.failureProbability.p90}%) exceeds 180-day probability (${fa.failureProbability.p180}%) — monotonicity violation`,
      'P90 ≤ P180', `P90=${fa.failureProbability.p90}% > P180=${fa.failureProbability.p180}%`, 15));
  }

  // 5.18 Net negative + A-book routing (profitable trader assumed, but isn't)
  if (m.netProfit < 0 && m.totalTrades >= 20 && routing === 'A-Book' && !['NewsTrader','Scalper'].includes(type)) {
    findings.push(finding('WARNING', 'CONTRA_NET_NEGATIVE_ABOOK', 'Metrics ↔ Broker',
      `Account is net negative (${round2(m.netProfit)} ${m.currency}) but recommended for A-Book routing — A-Book is typically reserved for profitable traders`,
      'B-Book or Hybrid for net-negative accounts', `Net: ${round2(m.netProfit)} ${m.currency}`, 6));
  }

  return findings;
}

/* ─────────────────────────────────────────────────────────
   SECTION 6 — MISSING DATA CHECK
───────────────────────────────────────────────────────── */
function checkMissingData(m, s, b, fa, fcast) {
  const missing = [];
  const findings = [];

  // 6.1 Hold time data
  if (!m.avgHoldMs) {
    missing.push({
      field: 'avgHoldMs',
      engine: 'Metrics',
      impact: 'Cannot classify trader type by hold duration — fallback to frequency-based classification',
      severity: 'WARNING',
    });
    findings.push(finding('WARNING', 'MISSING_HOLD_TIME', 'Metrics',
      'No hold time data available — trade open/close timestamps may be missing or identical. Trader type classification uses frequency as fallback.',
      'avgHoldMs > 0', null, 4));
  }

  // 6.2 TP hit rate data
  if (b.holdingBehaviour.tpHitRate === null) {
    missing.push({
      field: 'tpHitRate',
      engine: 'Behaviour',
      impact: 'Take profit hit rate cannot be computed — fewer than 5 trades had defined TP levels',
      severity: 'INFO',
    });
    findings.push(finding('INFO', 'MISSING_TP_HIT_RATE', 'Behaviour',
      'TP hit rate is not available — fewer than 5 trades have defined take profit levels. This limits early-exit behaviour detection.',
      '≥ 5 trades with TP', null, 1));
  }

  // 6.3 Post-loss sample too thin
  if (b.recoveryBehaviour.postLossCount < 5 && m.losingTrades >= 5) {
    missing.push({
      field: 'postLossWinRate',
      engine: 'Behaviour',
      impact: 'Recovery behaviour statistics are based on fewer than 5 post-loss observations — revenge trading detection confidence is very low',
      severity: 'WARNING',
    });
  }

  // 6.4 Session data insufficient
  const validSessions = ['Asia','London','NewYork','After'].filter(k => s.sessions[k]?.count >= 10);
  if (validSessions.length === 0 && m.totalTrades >= 30) {
    missing.push({
      field: 'sessionAnalytics',
      engine: 'Sessions',
      impact: 'No session has ≥10 trades — session rules cannot fire. Check broker UTC offset.',
      severity: 'WARNING',
    });
    findings.push(finding('WARNING', 'MISSING_SESSION_DATA', 'Sessions',
      `No session has ≥10 trades despite ${m.totalTrades} total trades — session-based rules (S-001, S-002) cannot fire. Most likely cause: broker timezone offset not configured.`,
      '≥1 session with ≥10 trades', 0, 5));
  } else if (validSessions.length === 1 && m.totalTrades >= 50) {
    missing.push({
      field: 'multiSessionComparison',
      engine: 'Sessions',
      impact: 'Only one session has enough data for comparison — multi-session analysis is limited',
      severity: 'INFO',
    });
  }

  // 6.5 Recovery factor unavailable
  if (m.recoveryFactor === null) {
    const reason = m.maxAbsDD === 0 ? 'max drawdown is zero (account has never been in drawdown)'
      : m.netProfit <= 0 ? 'account is net negative'
      : 'unknown';
    missing.push({
      field: 'recoveryFactor',
      engine: 'Metrics',
      impact: `Recovery factor unavailable — ${reason}`,
      severity: 'INFO',
    });
  }

  // 6.6 Broker intelligence missing
  if (!fa.dailyHazardInfo) {
    missing.push({
      field: 'dailyHazardInfo',
      engine: 'Failure',
      impact: 'Daily hazard rate intermediate data not preserved — failure probability traceability is limited',
      severity: 'INFO',
    });
  }

  // 6.7 Forecast not available
  if (!fcast) {
    missing.push({
      field: 'kavorPredictiveForecast',
      engine: 'KAVOX',
      impact: 'Predictive forecast was not run — forward-looking projections are unavailable',
      severity: 'INFO',
    });
  }

  // 6.8 Low trade count
  if (m.totalTrades < 10) {
    missing.push({
      field: 'statisticalValidity',
      engine: 'All',
      impact: 'Fewer than 10 trades — all statistics have very wide confidence intervals',
      severity: 'WARNING',
    });
    findings.push(finding('WARNING', 'MISSING_MIN_TRADES', 'All Engines',
      `Only ${m.totalTrades} market trades available. Statistical validity requires ≥30 trades for most metrics, ≥50 for session analysis, ≥100 for high confidence.`,
      '≥ 30 for basic analysis', m.totalTrades, 6));
  } else if (m.totalTrades < 30) {
    missing.push({
      field: 'statisticalValidity',
      engine: 'All',
      impact: 'Fewer than 30 trades — most per-session and per-symbol statistics are not reliable',
      severity: 'INFO',
    });
  }

  return { missing, findings };
}

/* ─────────────────────────────────────────────────────────
   SECTION 7 — ENGINE HEALTH ASSESSMENT
   Per-engine status based on finding severity count.
───────────────────────────────────────────────────────── */
function assessEngineHealth(allFindings) {
  const engines = ['Metrics','Sessions','Behaviour','Rules','Identity','Broker','Failure','KAVOX'];

  function healthFor(engineName) {
    const relevant = allFindings.filter(f =>
      f.engine && f.engine.toLowerCase().includes(engineName.toLowerCase())
    );
    const crits    = relevant.filter(f => f.severity === 'CRITICAL').length;
    const warnings = relevant.filter(f => f.severity === 'WARNING').length;

    const status = crits >= 2 ? 'FAILED'
      : crits === 1 ? 'DEGRADED'
      : warnings >= 3 ? 'DEGRADED'
      : warnings >= 1 ? 'OPERATIONAL_WITH_WARNINGS'
      : 'HEALTHY';

    return {
      engine:   engineName,
      status,
      criticals: crits,
      warnings,
      findingIds: relevant.map(f => f.id),
    };
  }

  const health = {};
  engines.forEach(e => { health[e] = healthFor(e); });

  // Overall pipeline health
  const totalCrits = allFindings.filter(f => f.severity === 'CRITICAL').length;
  const totalWarns = allFindings.filter(f => f.severity === 'WARNING').length;
  const pipelineStatus = totalCrits >= 3 ? 'UNRELIABLE'
    : totalCrits >= 1 ? 'DEGRADED'
    : totalWarns >= 4 ? 'OPERATIONAL_WITH_WARNINGS'
    : 'HEALTHY';

  return { engines: health, pipeline: pipelineStatus, totalCriticals: totalCrits, totalWarnings: totalWarns };
}

/* ─────────────────────────────────────────────────────────
   SECTION 8 — CONFIDENCE ADJUSTMENT
   Compute the % confidence reduction to apply to all
   downstream outputs based on validation findings.
───────────────────────────────────────────────────────── */
function computeConfidenceAdjustment(allFindings, m) {
  let reduction = 0;

  // Each critical finding reduces confidence by up to its deduction value
  allFindings.filter(f => f.severity === 'CRITICAL').forEach(f => {
    reduction += Math.min(f.deduction || 15, 15) * 0.8;
  });

  // Each warning reduces by a smaller amount
  allFindings.filter(f => f.severity === 'WARNING').forEach(f => {
    reduction += Math.min(f.deduction || 5, 5) * 0.4;
  });

  // Sample size reduction: thin data = lower confidence
  const samplePenalty = m.totalTrades < 10 ? 30
    : m.totalTrades < 20 ? 20
    : m.totalTrades < 40 ? 10
    : 0;

  reduction += samplePenalty;

  const finalReduction = Math.min(Math.round(reduction), 70);  // cap at 70% reduction

  return {
    reductionPct: finalReduction,
    adjustedConfidenceMultiplier: round2((100 - finalReduction) / 100),
    breakdown: {
      fromCriticals: Math.round(allFindings.filter(f => f.severity === 'CRITICAL').reduce((s, f) => s + (f.deduction || 15) * 0.8, 0)),
      fromWarnings:  Math.round(allFindings.filter(f => f.severity === 'WARNING').reduce((s, f) => s + (f.deduction || 5) * 0.4, 0)),
      fromSampleSize: samplePenalty,
    },
    interpretation: finalReduction === 0 ? 'No confidence adjustment required — all outputs are trustworthy'
      : finalReduction <= 15 ? 'Minor confidence reduction — outputs are reliable with noted caveats'
      : finalReduction <= 35 ? 'Moderate confidence reduction — treat specific flagged outputs with caution'
      : finalReduction <= 55 ? 'Significant confidence reduction — review all contradictions before acting on outputs'
      : 'Severe confidence reduction — pipeline has critical failures; do not use outputs for decisions',
  };
}

/* ─────────────────────────────────────────────────────────
   SECTION 9 — VALIDATION SCORE
   Deductive: starts at 100, deduct for each finding.
───────────────────────────────────────────────────────── */
function computeValidationScore(allFindings, m) {
  let score = 100;
  allFindings.forEach(f => { score -= (f.deduction || 0); });
  score = Math.max(0, Math.round(score));

  // Sample-size penalty (separate from finding deductions)
  if (m.totalTrades < 10) score = Math.min(score, 55);
  else if (m.totalTrades < 20) score = Math.min(score, 72);

  const label = score >= 90 ? 'Excellent — all engines consistent and data complete'
    : score >= 75 ? 'Good — minor issues detected, outputs are reliable'
    : score >= 55 ? 'Moderate — multiple warnings, specific outputs need review'
    : score >= 35 ? 'Poor — critical contradictions found, confidence reduced'
    : 'Failed — pipeline has fundamental consistency failures';

  return { score, label };
}

/* ─────────────────────────────────────────────────────────
   MAIN ENTRY POINT
───────────────────────────────────────────────────────── */

/**
 * Run the full Validation Engine against all pipeline outputs.
 *
 * @param {object} m      MetricsResult
 * @param {object} s      SessionAnalytics
 * @param {object} b      BehaviourAnalytics
 * @param {object} r      DiagnosisResult
 * @param {object} id     TraderIdentity
 * @param {object} bi     BrokerIntelligence
 * @param {object} fa     FailureAnalysis
 * @param {object} fcast  KavoxForecast (optional — pass null if not run)
 * @returns {ValidationResult}
 */
function runValidationEngine(m, s, b, r, id, bi, fa, fcast = null) {
  resetIdCounter();

  /* ── Run all validation sections ─────────────────────── */
  const arithmeticFindings    = checkInternalArithmetic(m);
  const sessionFindings       = checkSessionConsistency(m, s);
  const behaviourFindings     = checkBehaviourConsistency(m, b);
  const identityFindings      = checkIdentityConsistency(m, b, id);
  const contradictionFindings = checkCrossEngineContradictions(m, s, b, r, id, bi, fa);
  const { missing, findings: missingFindings } = checkMissingData(m, s, b, fa, fcast);

  /* ── Combine all findings ─────────────────────────────── */
  const allFindings = [
    ...arithmeticFindings,
    ...sessionFindings,
    ...behaviourFindings,
    ...identityFindings,
    ...contradictionFindings,
    ...missingFindings,
  ].sort((a, b_) => {
    // Sort: CRITICAL first, then WARNING, then INFO, then by deduction desc
    const sevOrder = { CRITICAL: 0, WARNING: 1, INFO: 2 };
    const sA = sevOrder[a.severity] ?? 3;
    const sB = sevOrder[b_.severity] ?? 3;
    if (sA !== sB) return sA - sB;
    return (b_.deduction || 0) - (a.deduction || 0);
  });

  /* ── Categorise findings ─────────────────────────────── */
  const contradictions = [...contradictionFindings, ...identityFindings.filter(f => f.severity === 'CRITICAL')]
    .filter(f => f.severity === 'CRITICAL' || f.severity === 'WARNING');
  const warnings       = allFindings.filter(f => f.severity === 'WARNING');
  const criticals      = allFindings.filter(f => f.severity === 'CRITICAL');
  const infoItems      = allFindings.filter(f => f.severity === 'INFO');

  /* ── Engine health ───────────────────────────────────── */
  const engineHealth = assessEngineHealth(allFindings);

  /* ── Confidence adjustment ───────────────────────────── */
  const confidenceAdjustment = computeConfidenceAdjustment(allFindings, m);

  /* ── Validation score ─────────────────────────────────── */
  const { score: validationScore, label: validationLabel } = computeValidationScore(allFindings, m);

  /* ── Internal consistency summary ───────────────────── */
  const internalConsistency = {
    arithmeticChecks: {
      passed: arithmeticFindings.filter(f => f.severity !== 'CRITICAL').length,
      failed: arithmeticFindings.filter(f => f.severity === 'CRITICAL').length,
      findings: arithmeticFindings,
    },
    sessionConsistency: {
      passed: sessionFindings.filter(f => f.severity !== 'CRITICAL').length,
      failed: sessionFindings.filter(f => f.severity === 'CRITICAL').length,
    },
    behaviourConsistency: {
      passed: behaviourFindings.filter(f => f.severity !== 'CRITICAL').length,
      failed: behaviourFindings.filter(f => f.severity === 'CRITICAL').length,
    },
    identityConsistency: {
      passed: identityFindings.filter(f => f.severity !== 'CRITICAL').length,
      failed: identityFindings.filter(f => f.severity === 'CRITICAL').length,
    },
  };

  /* ── Summary statistics ──────────────────────────────── */
  const summary = {
    totalFindings:    allFindings.length,
    criticals:        criticals.length,
    warnings:         warnings.length,
    infoItems:        infoItems.length,
    missingFields:    missing.length,
    contradictions:   contradictions.length,
    pipelineStatus:   engineHealth.pipeline,
  };

  /* ── Return complete ValidationResult ───────────────── */
  return {

    /* ── Primary outputs ─────────────────────────────── */
    validationScore,
    validationLabel,

    /* ── Categorised findings ────────────────────────── */
    contradictions,   // array: logical conflicts between engines
    warnings,         // array: suspicious but not impossible signals
    criticals,        // array: critical failures requiring attention
    infoItems,        // array: data quality notes

    /* ── Engine health per engine ────────────────────── */
    engineHealth,

    /* ── Confidence adjustment ───────────────────────── */
    confidenceAdjustment,

    /* ── Missing data ────────────────────────────────── */
    missingData: missing,

    /* ── Internal consistency checks ─────────────────── */
    internalConsistency,

    /* ── All findings in one array (sorted) ─────────── */
    allFindings,

    /* ── Summary ─────────────────────────────────────── */
    summary,

    /* ── Validation metadata ─────────────────────────── */
    meta: {
      engineVersion: 'Validation Engine v1',
      totalRulesChecked: 34,  // total cross-check rules in this version
      inputsValidated: ['Metrics','Sessions','Behaviour','Rules','Identity','Broker','Failure'].filter(Boolean),
      forecastIncluded: fcast !== null,
      tradeCount: m.totalTrades,
      currency: m.currency,
    },
  };
}

/* ─────────────────────────────────────────────────────────
   EXPORTS
───────────────────────────────────────────────────────── */
